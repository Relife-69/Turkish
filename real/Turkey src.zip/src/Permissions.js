const PERMISSIONS = {
  CAN_VIEW_SELL: "view_sell",
  //   CAN_VIEW_EXTRA: "view_extra",
};
export default PERMISSIONS;
