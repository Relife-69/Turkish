import styled from "styled-components";

export const MainHome = styled.div`
  background-color: #eef1f9;
`;
