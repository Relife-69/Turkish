import styled from "styled-components";

export const BannerContainer = styled.div`
  width: 100%;
  align-items: center;
  justify-content: center;
  background-color: red;
  color: white;
  font-size: 18px;
  font-weight: 400;
  text-align: center;
  padding: 10px 0px;
`;
