import React from 'react'

const Card = () => {
  return (
    <div>
      
    </div>
  )
}

export default Card

