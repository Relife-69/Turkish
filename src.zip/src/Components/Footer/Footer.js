import React from "react";
import {
  ContuctContainer,
  LogoContainer,
  MainContainer,
  Heading,
  Text,
  MapContainer,
  MapIframe,
  Text2,
  FooterContainer,
} from "./StyledFooter";
import Pic from "../Images/Logo.png";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <>
      <MainContainer>
        <LogoContainer src={Pic} />
        <ContuctContainer>
          <Heading>CONTACT US</Heading>
          <Text>We are in St. Petersburg, FL</Text>
          <Text>+1-727-346-6423</Text>
          <Text>support@appointmentreminders.bot</Text>
          <MapContainer>
            <MapIframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12422.904120464987!2d35.24441127147063!3d38.88450960062937!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x152b1e6055a09571%3A0x2ddd8337a07a4010!2sYemliha%2C%2038090%20Kocasinan%2FKayseri%2C%20T%C3%BCrkiye!5e0!3m2!1sen!2s!4v1717087062323!5m2!1sen!2s"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </MapContainer>
        </ContuctContainer>
        <FooterContainer>
          <Heading>GET STARTED</Heading>
          <Text2>
            <Link to="/faqs">FAQ’s</Link>
          </Text2>
          <Text2>
            <Link>Help Docs</Link>
          </Text2>
          <Text2>
            <Link>Blog</Link>
          </Text2>
          <Text2>
            <Link to="/addpatient">Dash</Link>
          </Text2>
        </FooterContainer>
        <FooterContainer>
          <Heading>Specialties and Industries</Heading>
          <Text2>
            <Link>Appointment Reminders for Accountants</Link>
          </Text2>
          <Text2>
            <Link>Appointment Reminders for Accountants</Link>
          </Text2>
          <Text2>
            <Link>Appointment Reminders for Accountants</Link>
          </Text2>
          <Text2>
            <Link>Appointment Reminders for Accountants</Link>
          </Text2>
          <Text2>
            <Link>Appointment Reminders for Accountants</Link>
          </Text2>
        </FooterContainer>
      </MainContainer>
    </>
  );
};

export default Footer;
