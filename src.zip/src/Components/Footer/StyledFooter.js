import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: start;
  justify-content: space-around;
  min-height: 250px;
  border: none;
  border-radius: 80px 80px 0px 0px;
  background-color: #023e8a;
  color: white;
  flex-wrap: wrap;
  padding-top: 50px;
  gap: 50px;
`;

export const LogoContainer = styled.img`
  width: 200px;
  height: 200px;
`;

export const ContuctContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 15px;
`;
export const FooterContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: start;
  flex-direction: column;
  gap: 15px;
`;
export const Heading = styled.h1`
  font-size: 22px;
  font-weight: 600;
  line-height: 26.63px;
  color: white;
  margin: 0%;
`;

export const Text = styled.p`
  font-size: 14px;
  font-weight: 400;
  line-height: 16.94px;
  color: white;
  margin: 0%;
`;
export const Text2 = styled.p`
  font-size: 14px;
  font-weight: 400;
  line-height: 16.94px;
  color: white;
  margin: 0%;

  a {
    color: white;
    text-decoration: none;
  }
`;
export const MapContainer = styled.div`
  width: 230px;
  height: 100px;
  overflow: hidden;
  border-radius: 10px;
`;
export const MapIframe = styled.iframe`
  width: 230px;
  height: 100px;
  border: none;
  border-radius: 10px;
`;
