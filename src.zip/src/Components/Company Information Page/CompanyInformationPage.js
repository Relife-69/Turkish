import React, { useState } from "react";
import axios from "axios";
import {
  ContextContainer,
  Heading,
  Input1, // Assuming Input1 is a styled component for radio inputs
  Input,
  Label,
  MainContainer,
  MainHeading,
  OptionContainer,
  QuestionContainer,
  SelectionContainer,
  SelectOption,
  ButtonContainer,
  SubmitButton,
  ClearButton,
} from "./StyledCompanyInformationPage";
import { useNavigate } from "react-router-dom";

const CompanyInformationPage = () => {
  const [businessType, setBusinessType] = useState("");
  const [timeZone, setTimeZone] = useState("");
  const [phoneCallReminders, setPhoneCallReminders] = useState("");
  const [textMessageReminders, setTextMessageReminders] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [textToCall, setTextToCall] = useState("");
  const [emailReminders, setEmailReminders] = useState("");
  const [messageByAppointmentType, setMessageByAppointmentType] = useState("");
  const [confirmAppointments, setConfirmAppointments] = useState("");
  const [cancelAppointments, setCancelAppointments] = useState("");
  const [rescheduleAppointments, setRescheduleAppointments] = useState("");
  const [scheduleAppointments, setScheduleAppointments] = useState("");
  const [reminderDaysBefore, setReminderDaysBefore] = useState("");
  const [followUpReminder, setFollowUpReminder] = useState("");
  const [otherText, setOtherText] = useState("");
  const [contactSetupHelp, setContactSetupHelp] = useState("");
  const navigate = useNavigate();

  const handleClear = () => {
    setBusinessType("");
    setTimeZone("");
    setPhoneCallReminders("");
    setTextMessageReminders("");
    setCompanyName("");
    setTextToCall("");
    setEmailReminders("");
    setMessageByAppointmentType("");
    setConfirmAppointments("");
    setCancelAppointments("");
    setRescheduleAppointments("");
    setScheduleAppointments("");
    setReminderDaysBefore("");
    setFollowUpReminder("");
    setOtherText("");
    setContactSetupHelp("");
  };

  const handleSubmit = async () => {
    const payload = {
      business_type: businessType,
      time_zone: timeZone,
      phone_call_reminders: phoneCallReminders,
      text_message_reminders: textMessageReminders,
      company_name_text_reminders: companyName,
      roll_to_call: textToCall,
      email_reminders: emailReminders,
      different_message_by_appt_type: messageByAppointmentType,
      allow_confirm_by_reply: confirmAppointments,
      allow_cancel_by_reply: cancelAppointments,
      allow_reschedule_by_reply: rescheduleAppointments,
      schedule_through_website: scheduleAppointments,
      days_before_appt_reminders: reminderDaysBefore,
      followup_reminder_day_before: followUpReminder,
      additional_questions: otherText,
      contact_to_help_setup: contactSetupHelp,
    };

    try {
      const response = await axios.post(
        "https://2036-103-26-82-46.ngrok-free.app/account-info/",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Response:", response.data);
      alert("Your Data has benn stored, ");
      // Optionally, you can navigate to another page upon successful submission
      navigate("/"); // Replace "/success" with your desired success route
    } catch (error) {
      console.error("Error posting data:", error);
    }
  };

  return (
    <MainContainer>
      <ContextContainer>
        <MainHeading>Welcome!</MainHeading>
        <Heading>
          HI! WE JUST NEED TO COLLECT A SMALL BIT OF INFORMATION SO WE CAN
          CUSTOMIZE YOUR ACCOUNT....WE WILL SET YOUR REMINDERS UP BASED ON{" "}
        </Heading>
        <QuestionContainer>
          <Label>What best describes your type of business:</Label>
          <SelectionContainer
            value={businessType}
            onChange={(e) => setBusinessType(e.target.value)}
          >
            <option value="">Select</option>
            {/* <option value="Anyone!">Anyone!</option> */}
            <option value="heating_ac">Heating Ac</option>
          </SelectionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>What Time Zone are you in:</Label>
          <SelectionContainer
            value={timeZone}
            onChange={(e) => setTimeZone(e.target.value)}
          >
            <option value="">Select</option>
            <option value="GMT+00:00">GMT+00:00</option>
            <option value="GMT+01:00">GMT+01:00</option>
            <option value="GMT+02:00">GMT+02:00</option>
            <option value="GMT+03:00">GMT+03:00</option>
            <option value="GMT+04:00">GMT+04:00</option>
            <option value="GMT+05:00">GMT+05:00</option>
            <option value="GMT+06:00">GMT+06:00</option>
            <option value="GMT+07:00">GMT+07:00</option>
            <option value="GMT+08:00">GMT+08:00</option>
            <option value="GMT+09:00">GMT+09:00</option>
            <option value="GMT+10:00">GMT+10:00</option>
            <option value="GMT+11:00">GMT+11:00</option>
            <option value="GMT-01:00">GMT-01:00</option>
            <option value="GMT-02:00">GMT-02:00</option>
            <option value="GMT-03:00">GMT-03:00</option>
            <option value="GMT-04:00">GMT-04:00</option>
            <option value="GMT-05:00">GMT-05:00</option>
            <option value="GMT-06:00">GMT-06:00</option>
            <option value="GMT-07:00">GMT-07:00</option>
            <option value="GMT-08:00">GMT-08:00</option>
            <option value="GMT-09:00">GMT-09:00</option>
            <option value="GMT-10:00">GMT-10:00</option>
            <option value="GMT-11:00">GMT-11:00</option>
          </SelectionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>Do you want to send phone call reminders?</Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="phoneCallReminders"
                value="YES"
                checked={phoneCallReminders === "YES"}
                onChange={(e) => setPhoneCallReminders(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="phoneCallReminders"
                value="NO"
                checked={phoneCallReminders === "NO"}
                onChange={(e) => setPhoneCallReminders(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>Do you want to send text message reminders?</Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="textMessageReminders"
                value="YES"
                checked={textMessageReminders === "YES"}
                onChange={(e) => setTextMessageReminders(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="textMessageReminders"
                value="NO"
                checked={textMessageReminders === "NO"}
                onChange={(e) => setTextMessageReminders(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            How do you want your company’s name to be worded in your text
            reminders? Shorter is better!
          </Label>
          <Input
            type="text"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
          />
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want your text messages to roll to a call if they fail?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="textToCall"
                value="YES"
                checked={textToCall === "YES"}
                onChange={(e) => setTextToCall(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="textToCall"
                value="NO"
                checked={textToCall === "NO"}
                onChange={(e) => setTextToCall(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>Do you want to send email reminders?</Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="emailReminders"
                value="YES"
                checked={emailReminders === "YES"}
                onChange={(e) => setEmailReminders(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="emailReminders"
                value="NO"
                checked={emailReminders === "NO"}
                onChange={(e) => setEmailReminders(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to send out a different message based on the appointment
            type?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="messageByAppointmentType"
                value="YES"
                checked={messageByAppointmentType === "YES"}
                onChange={(e) => setMessageByAppointmentType(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="messageByAppointmentType"
                value="NO"
                checked={messageByAppointmentType === "NO"}
                onChange={(e) => setMessageByAppointmentType(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to allow your customers to confirm appointments by
            replying to the text?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="confirmAppointments"
                value="YES"
                checked={confirmAppointments === "YES"}
                onChange={(e) => setConfirmAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="confirmAppointments"
                value="NO"
                checked={confirmAppointments === "NO"}
                onChange={(e) => setConfirmAppointments(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to allow your customers to cancel appointments by
            replying to the text?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="cancelAppointments"
                value="YES"
                checked={cancelAppointments === "YES"}
                onChange={(e) => setCancelAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="cancelAppointments"
                value="NO"
                checked={cancelAppointments === "NO"}
                onChange={(e) => setCancelAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>CALL</Label>
              <Input1
                type="radio"
                name="cancelAppointments"
                value="CALL"
                checked={cancelAppointments === "CALL"}
                onChange={(e) => setCancelAppointments(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to allow your customers to reschedule appointments by
            replying to the text?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="rescheduleAppointments"
                value="YES"
                checked={rescheduleAppointments === "YES"}
                onChange={(e) => setRescheduleAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="rescheduleAppointments"
                value="NO"
                checked={rescheduleAppointments === "NO"}
                onChange={(e) => setRescheduleAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>CALL</Label>
              <Input1
                type="radio"
                name="rescheduleAppointments"
                value="CALL"
                checked={rescheduleAppointments === "CALL"}
                onChange={(e) => setRescheduleAppointments(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to schedule appointments through your website?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>Yes</Label>
              <Input1
                type="radio"
                name="scheduleAppointments"
                value="Yes"
                checked={scheduleAppointments === "Yes"}
                onChange={(e) => setScheduleAppointments(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>No</Label>
              <Input1
                type="radio"
                name="scheduleAppointments"
                value="No"
                checked={scheduleAppointments === "NO"}
                onChange={(e) => setScheduleAppointments(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            How many days before the appointment do you want the reminder sent?
          </Label>
          <Input
            type="text"
            value={reminderDaysBefore}
            onChange={(e) => setReminderDaysBefore(e.target.value)}
          />
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you want to send a follow-up reminder the day before the
            appointment?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="followUpReminder"
                value="YES"
                checked={followUpReminder === "YES"}
                onChange={(e) => setFollowUpReminder(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="followUpReminder"
                value="NO"
                checked={followUpReminder === "NO"}
                onChange={(e) => setFollowUpReminder(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Do you have any additional questions or information for us?
          </Label>
          <Input
            type="text"
            value={otherText}
            onChange={(e) => setOtherText(e.target.value)}
          />
        </QuestionContainer>
        <QuestionContainer>
          <Label>
            Would you like someone to contact you to help set up your account?
          </Label>
          <OptionContainer>
            <SelectOption>
              <Label>YES</Label>
              <Input1
                type="radio"
                name="contactSetupHelp"
                value="YES"
                checked={contactSetupHelp === "YES"}
                onChange={(e) => setContactSetupHelp(e.target.value)}
              />
            </SelectOption>
            <SelectOption>
              <Label>NO</Label>
              <Input1
                type="radio"
                name="contactSetupHelp"
                value="NO"
                checked={contactSetupHelp === "NO"}
                onChange={(e) => setContactSetupHelp(e.target.value)}
              />
            </SelectOption>
          </OptionContainer>
        </QuestionContainer>
        <ButtonContainer>
          <ClearButton onClick={handleClear}>Clear</ClearButton>
          <SubmitButton onClick={handleSubmit}>Save and continue</SubmitButton>
        </ButtonContainer>
      </ContextContainer>
    </MainContainer>
  );
};

export default CompanyInformationPage;
