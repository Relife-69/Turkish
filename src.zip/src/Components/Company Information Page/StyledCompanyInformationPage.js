import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  padding: 30px 0px;
`;
export const ContextContainer = styled.div`
  width: 80%;
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 20px;
`;
export const MainHeading = styled.h1`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: start;
  margin: 20px 0px;
  font-size: 30px;
  font-weight: 700;
`;
export const Heading = styled.h1`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: start;
  border-bottom: 2px solid #1376f84d;
  padding: 20px 0px;
  font-size: 22px;
  font-weight: 600;
`;
export const QuestionContainer = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: start;
`;
export const Label = styled.label`
  font-size: 18px;
  font-weight: 500;
`;
export const SelectionContainer = styled.select`
  width: 100%;
  padding: 10px 30px;
  font-size: 18px;
  font-weight: 500;
  background-color: #1376f84d;
`;
export const OptionContainer = styled.div`
  width: 100%;
  padding: 10px 30px;
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 30px;
`;
export const SelectOption = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;
export const Input1 = styled.input`
  padding: 10px 30px;
  font-size: 18px;
  font-weight: 500;
`;
export const Input = styled.input`
  width: 90%;
  padding: 10px 30px;
  font-size: 18px;
  font-weight: 500;
`;

export const ButtonContainer = styled.div`
  width: 100%;
  padding: 10px 30px;
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 30px;
`;

export const SubmitButton = styled.button`
  width: 150px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #1376f8;
  color: white;
  font-size: 20px;
  font-weight: 500;
  &:hover {
    background-color: white;
    color: #1376f8;
    border: 1px solid #1376f8;
  }
`;
export const ClearButton = styled.button`
  width: 150px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: Silver;
  font-size: 20px;
  font-weight: 500;
  &:hover {
    background-color: white;
    color: silver;
    border: 1px solid silver;
  }
`;
