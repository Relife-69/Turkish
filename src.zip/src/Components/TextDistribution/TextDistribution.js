import React from "react";
import DashboardNavbar from "../../Dashboard/Navbar/DashboardNavbar";
import "./Text.css";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
} from "./StyledTextDistribution";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaMicrophone } from "react-icons/fa6";
import { PiArrowArcLeftBold } from "react-icons/pi";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiEdit } from "react-icons/ci";
import { useNavigate } from "react-router-dom";

const TextDistribution = () => {
  const navigate = useNavigate();
  const UserHelp = () => {
    navigate("/text_to_c&p_help");
  };

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Text Messages - To Distribution List</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Text Messages - To Distribution List</ChartHeading>
            <ChartText>
              This page will allow you to send a text message to everone in the
              chosen distribution list.
            </ChartText>
            <ChartText>
              To send a text message to a specific customer, go to the Customers
              Page and click on the 'SMS' button for that customer.
            </ChartText>
            <ChartText>
              It will create a Reminder Type with the name 'QuickText + Todays
              Date and Time' so you can view results in the Reminders Tab
            </ChartText>
            <select className="w-100 drop-1">
              <option value="1" hidden>
                City
              </option>
              <option value="2">Two</option>
              <option value="3">Three</option>
              <option value="4">Four</option>
              <option value="5">Five</option>
              <option value="6">Six</option>
              <option value="7">Seven</option>
              <option value="8">Eight</option>
            </select>

            <ChartText>
              This Area Shows All Text Messages That Have Gone Out To
              Distribution Lists With Appointment Dates Between Dates Selected
            </ChartText>
          </ChartHeadingContainer>

          <div>
            <label>Send a text message to City </label>
          </div>
          <textarea name="message" className="w-100 text"></textarea>
          <label>Start with a previous text? </label>
          <select className="w-100 drop-2">
            <option value="1" hidden>
              Previous Text Messages............
            </option>
            <option value="2">Two</option>
            <option value="3">Three</option>
            <option value="4">Four</option>
            <option value="5">Five</option>
            <option value="6">Six</option>
            <option value="7">Seven</option>
            <option value="8">Eight</option>
          </select>

          <div className="container mt-4">
            <div className="row">
              <div className="col-1">
                <button type="submit" className="submit">
                  Submit
                </button>
              </div>
              <div className="col-3">
                <button type="submit" className="clear">
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="container mt-4 ">
            <p>
              This area show all text messages that have gone out to
              customers/patients between dates selected
            </p>
            <div className="row " style={{ borderTop: "3px solid #1376f8" }}>
              <div className="col-6 mt-4">
                <p>Start Date</p>
                <input
                  type="date"
                  name="startDate"
                  id="startDate"
                  className="form-control"
                />
              </div>
              <div className="col-6 mt-4">
                <p>End Date</p>
                <input
                  type="date"
                  name="endDate"
                  id="endDate"
                  className="form-control"
                />
              </div>
            </div>
          </div>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Distribution List Name</StyledTableHeader>
                <StyledTableHeader>Quick Text Name</StyledTableHeader>
                <StyledTableHeader>Message Content</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>James</StyledTableCell>
                <StyledTableCell>Watt</StyledTableCell>
                <StyledTableCell>Sent</StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
          </StyledTable>

          <div className="container mt-4">
            <button type="submit" className="btn2">
              <PiArrowArcLeftBold />
              Back
            </button>
          </div>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default TextDistribution;
