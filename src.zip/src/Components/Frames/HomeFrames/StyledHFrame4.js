import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  flex-direction: column;
`;
export const MainHeading = styled.h1`
  font-size: 34px;
  font-weight: 600;
  margin: 0px 0px 30px 0px;
  width: 80%;
  gap: 10px;
  display: flex;
  align-items: center;
  justify-content: start;
  span {
    color: #1376f8;
  }
`;
export const ContextContainer = styled.div`
  width: 100%;
  min-height: 1500px;
  background-image: ${({ background }) => `url(${background})`};
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: start;
  align-items: start;
  flex-direction: column;
  @media (max-width: 700px) {
    display: none;
  }
`;
export const ContextContainer1 = styled.div`
  display: none;
  @media (max-width: 700px) {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    padding: 30px 0px;
    gap: 30px;
  }
`;
export const Textcontainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 400px;
  }
  @media (max-width: 900px) {
    width: 300px;
  }
`;
export const Textcontainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 400px;
  }
  @media (max-width: 900px) {
    width: 300px;
  }
`;
export const Textcontainer2 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 400px;
  }
  @media (max-width: 900px) {
    width: 300px;
  }
`;
export const Textcontainer3 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 400px;
  }
  @media (max-width: 900px) {
    width: 300px;
  }
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  position: relative;
  left: 9%;
  @media (max-width: 1100px) {
    width: 400px;
    left: 7%;
  }
  @media (max-width: 900px) {
    width: 300px;
    left: 3%;
    top: -15px;
  }
`;
export const TextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  top: 30px;
  position: relative;
  left: 55%;
  @media (max-width: 1100px) {
    width: 400px;
    left: 51%;
    top: 70px;
  }
  @media (max-width: 900px) {
    width: 300px;
    left: 60%;
    top: 20px;
  }
`;
export const TextContainer2 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  position: relative;
  top: 120px;
  left: 9%;
  @media (max-width: 1100px) {
    width: 400px;
    top: 200px;
    left: 7%;
  }
  @media (max-width: 900px) {
    width: 300px;
    top: 80px;
    left: 3%;
  }
`;
export const TextContainer3 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 600px;
  flex-direction: column;
  top: 200px;
  position: relative;
  left: 55%;
  @media (max-width: 1100px) {
    width: 400px;
    top: 300px;
    left: 51%;
  }
  @media (max-width: 1100px) {
    width: 300px;
    left: 60%;
    top: 130px;
  }
`;
export const Picture = styled.img`
  width: 100%;
  height: 1080px;
`;
export const Heading = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  color: #1376f8;
  @media (max-width: 1100px) {
    font-size: 24px;
  }
`;
export const List = styled.li`
  padding-left: 10px;
  margin: 0%;
  font-size: 18px;
  font-weight: 400;
  @media (max-width: 1100px) {
    font-size: 14px;
  }
`;
export const List1 = styled.li`
  margin: 0%;
  font-size: 18px;
  font-weight: 400;
  list-style: none;
  @media (max-width: 1100px) {
    font-size: 14px;
  }
`;
