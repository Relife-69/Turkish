import React from "react";
import {
  CardContainer,
  CardHoilder,
  CardImage,
  Heading,
  MainContainer,
  TextContainer,
  List,
} from "./StyledHFrame5";
import Pic1 from "../../Images/9.png";
import Pic2 from "../../Images/8.png";
import Pic3 from "../../Images/10.png";
const HFrame5 = () => {
  return (
    <>
      <MainContainer>
        <CardHoilder>
          <CardContainer>
            <TextContainer>
              <Heading>
                <span>Private & </span> Secure
              </Heading>
              <List>Strict Data No-Sharing Policy</List>
              <List>We are HIPAA Compliant </List>
              <List>Located in Denver, CO – Data housed in Phoenix, AZ </List>
              <List>
                Collect and store only the minimum data to send your appointment
                reminders
              </List>
              <List>Highest level of encryption</List>
              <List>Account & Historical data deleted upon cancellation</List>
            </TextContainer>
            <CardImage src={Pic1} />
          </CardContainer>
          <CardContainer>
            <CardImage src={Pic2} />
            <TextContainer>
              <Heading>
                Built in <span>the USA</span>
              </Heading>
              <List>
                We are a U.S. Based company headquartered in Denver, CO.
              </List>
              <List>
                Years of experience & a combined background in automated
                communication technologies including text messaging, automated
                calling, email campaigns, appointment reminder software, data
                integration, telecommunications, HIPAA Compliance, and customer
                support.
              </List>
              <List>
                Live, customer support for account setup and assistance free of
                charge.
              </List>
              <List>
                Our knowledgeable and helpful staff is available to answer any
                questions that you have via chat, email, call, and/or support
                tickets.
              </List>
            </TextContainer>
          </CardContainer>
          <CardContainer>
            <TextContainer>
              <Heading>
                Proven <span>& Trusted</span>
              </Heading>
              <List>
                Trusted by thousands of businesses across the United States and
                Canada.
              </List>
              <List>
                Our clients include large medical providers, including mental
                health, physical therapy, and family practitioners.
              </List>
              <List>
                We are also trusted by many small business owners ranging from
                small therapy practices, personal hygiene care, instructors,
                mechanics, exercise trainers, and more!
              </List>
              <List>
                No matter what your business is, we are sure that we will
                have an account suitable for your business needs.
              </List>
              <List>
                We are all about appointment reminders for businesses! If you
                own or work for a business that needs to send appointment
                reminders to customers or patients, you have come to the right
                place!
              </List>
            </TextContainer>
            <CardImage src={Pic3} />
          </CardContainer>
        </CardHoilder>
      </MainContainer>
    </>
  );
};

export default HFrame5;
