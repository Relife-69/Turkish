import React from "react";
import {
  ContextConatiner,
  MainContainer,
  PictureContainer,
  Heading,
  Text,
  ReviewContainer,
  TextContainer,
  ReviewHeading,
  ReviewText,
  StarReview,
  Heading1,
} from "./StyledHFrame1";
import Cel from "../../Images/Cel.png";
import { FaStar } from "react-icons/fa6";

const HFrame1 = () => {
  return (
    <>
      <MainContainer>
        <ContextConatiner>
          <Heading>
            <span>Appointment </span> Reminders for <span> Businesses</span>
          </Heading>
          <Text>
            Send Call, Text, or Email Appointment Reminders to your Patients or
            Customers Using our Automated Reminder System
          </Text>
          <ReviewContainer>
            <TextContainer>
              <ReviewHeading>100%</ReviewHeading>
              <ReviewText>HIPAA Compliant</ReviewText>
            </TextContainer>
            <TextContainer>
              <ReviewHeading>100%</ReviewHeading>
              <ReviewText>Private & Secure</ReviewText>
            </TextContainer>
            <TextContainer>
              <ReviewHeading>90%</ReviewHeading>
              <ReviewText>No Show Reduction</ReviewText>
            </TextContainer>
            <TextContainer>
              <ReviewHeading>11+</ReviewHeading>
              <ReviewText>Years In Business</ReviewText>
            </TextContainer>
          </ReviewContainer>
          <StarReview>
            <FaStar />
            <FaStar />
            <FaStar />
            <FaStar />
            <FaStar />
          </StarReview>
          <Heading1>
            Perfect For Every <span>Business</span>
          </Heading1>
        </ContextConatiner>
        <PictureContainer src={Cel} />
      </MainContainer>
    </>
  );
};

export default HFrame1;
