import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  background-image: ${({ background }) => `url(${background})`};
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  gap: 30px;
  align-items: center;
  flex-direction: column;
  @media (max-width: 1500px) {
  }
  @media (max-width: 1100px) {
  }
  @media (max-width: 800px) {
  }
  @media (max-width: 600px) {
  }
  @media (max-width: 400px) {
  }
`;
export const ContextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 30px;
  flex-wrap: wrap;
  @media (max-width: 790px) {
    align-items: center;
    justify-content: center;
  }
  @media (max-width: 600px) {
  }
`;
export const Picture = styled.img`
  width: 260px;
  height: 250px;
`;
export const TextContainer = styled.div`
  width: 700px;
  align-items: start;
  justify-content: start;
  gap: 5px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 600px;
  }
  @media (max-width: 800px) {
    width: 400px;
  }
  @media (max-width: 400px) {
    width: 300px;
  }
`;
export const Heading = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  color: #1376f8;
`;
export const Heading2 = styled.h2`
  font-size: 22px;
  font-weight: 500;
  margin: 0%;
`;
export const List = styled.li`
  padding-left: 10px;
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
