import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  margin-top: 10px;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  gap: 40px;
`;
export const Holder = styled.div`
  width: 80%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 100px;
  flex-wrap: wrap;
`;
export const CardContainer = styled.div`
  padding: 0px 10px;
  width: 400px;
  min-height: 350px;
  border-radius: 20px;
  border: 3px;
  box-shadow: 0px 1px 10px 1px rgba(0, 0, 0, 0.25);
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  text-align: start;
  @media (max-width: 400px) {
    width: 90%;
    padding: 10px;
  }
`;
export const CardContainer1 = styled.div`
  padding: 0px 10px;
  width: 400px;
  min-height: 350px;
  border-radius: 20px;
  border: 3px;
  box-shadow: 0px 1px 10px 1px rgba(0, 0, 0, 0.25);
  background-color: #1376f8;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  flex-direction: column;
  @media (max-width: 400px) {
    width: 90%;
  }
`;
export const Heading = styled.h1`
  width: 80%;
  align-items: start;
  font-size: 34px;
  font-weight: 600;
  line-height: 41.15px;
  span {
    color: #1376f8;
  }
`;
export const Icon = styled.img`
  height: 110px;
  width: 110px;
`;
export const CardHeading = styled.h1`
  font-size: 28px;
  font-weight: 600;
  line-height: 33.89px;
  margin: 0%;
  color: #1376f8;
  span {
    color: white;
  }
`;
export const CardText = styled.p`
  max-width: 300px;
  font-size: 14px;
  font-weight: 400;
  line-height: 16.94px;
`;
export const CardList1 = styled.li`
  font-size: 14px;
  font-weight: 400;
  margin: 0%;
`;
export const CardList2 = styled.li`
  font-size: 14px;
  font-weight: 400;
  margin: 0%;
  color: white;
`;

export const CardContext = styled.div`
  display: flex;
  width: 350px;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  @media (max-width: 400px) {
    width: 90%;
  }
`;
