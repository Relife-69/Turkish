import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin: 30px 0px;
`;
export const CardHoilder = styled.div`
  display: flex;
  width: 80%;
  align-items: center;
  justify-content: center;
  gap: 40px;
  flex-direction: column;
`;
export const CardContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 50px;
  @media (max-width: 800px) {
    flex-wrap: wrap;
  }
`;
export const CardImage = styled.img`
  width: 510px;
  min-height: 400px;
  @media (max-width: 1500px) {
    width: 450px;
    height: 350px;
  }
  @media (max-width: 1100px) {
    width: 380px;
    height: 380px;
  }
  @media (max-width: 800px) {
    width: 350px;
    height: 350px;
  }
  @media (max-width: 400px) {
    width: 280px;
    height: 280px;
  }
`;
export const TextContainer = styled.div`
  width: 700px;
  align-items: start;
  justify-content: start;
  display: flex;
  flex-direction: column;
  @media (max-width: 1500px) {
    width: 600px;
  }
  @media (max-width: 1100px) {
    width: 450px;
  }
  @media (max-width: 800px) {
    width: 350px;
  }
  @media (max-width: 400px) {
    width: 280px;
  }
`;
export const Heading = styled.h1`
  font-size: 34px;
  font-weight: 600;
  gap: 5px;
  margin: 0px 0px 15px 0px;
  span {
    color: #1376f8;
  }
`;
export const List = styled.li`
  font-size: 18px;
  margin: 0%;
  padding-left: 10px;
  font-weight: 400;
`;
