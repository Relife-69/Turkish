import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap-reverse;
  padding: 30px 0px;
`;
export const ContextConatiner = styled.div`
  display: flex;
  align-items: start;
  justify-content: center;
  gap: 30px;
  flex-direction: column;
`;
export const PictureContainer = styled.img`
  width: 700px;
  height: 600px;
  @media (max-width: 800px) {
    width: 600px;
    height: 500px;
  }
  @media (max-width: 500px) {
    width: 100%;
    height: 300px;
  }
`;
export const Heading = styled.h1`
  max-width: 420px;
  font-size: 34px;
  font-weight: 700;
  flex-wrap: wrap;
  display: flex;
  color: black;
  margin: 0%;
  gap: 5px;
  span {
    color: #1376f8;
  }
  @media (max-width: 500px) {
    width: 100%;
    font-size: 32px;
    font-weight: 600;
    text-align: center;
  }
`;
export const Text = styled.p`
  max-width: 570px;
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
  @media (max-width: 400px) {
    width: 100%;
    text-align: center;
  }
`;
export const ReviewContainer = styled.div`
  width: 580px;
  min-height: 90px;
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 25px;
  padding: 10px;
  background-color: #e6f6fe;
  flex-wrap: wrap;
  box-shadow: 0px 1px 10px 1px rgba(0, 0, 0, 0.25);
  @media (max-width: 600px) {
    width: 400px;
  }
  @media (max-width: 400px) {
    width: 90%;
  }
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 5px;
`;
export const ReviewHeading = styled.h1`
  font-size: 28px;
  font-weight: 600;
  line-height: 33.89px;
  margin: 0%;
  color: #1376f8;
`;
export const ReviewText = styled.p`
  font-size: 14px;
  font-weight: 400;
  line-height: 16.94px;
  margin: 0%;
`;
export const StarReview = styled.div`
  width: 580px;
  font-size: 60px;
  color: #ffa900;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  @media (max-width: 600px) {
    width: 400px;
  }
  @media (max-width: 400px) {
    width: 100%;
  }
`;
export const Heading1 = styled.h1`
  max-width: 420px;
  font-size: 34px;
  font-weight: 700;
  color: black;
  margin: 0%;
  padding-top: 60px;
  span {
    color: #1376f8;
    gap: 5px;
  }
  @media (max-width: 500px) {
    width: 100%;
    font-size: 32px;
    font-weight: 600;
    text-align: center;
  }
`;
