import React from "react";
import {
  ContextContainer,
  Heading,
  List,
  List1,
  MainContainer,
  MainHeading,
  Picture,
  TextContainer,
  TextContainer1,
  TextContainer2,
  TextContainer3,
  Textcontainer,
  Textcontainer1,
  Textcontainer2,
  Textcontainer3,
  ContextContainer1,
} from "./StyledHFrame4";
import Label from "../../Images/7.png";

const HFrame4 = () => {
  return (
    <>
      <MainContainer>
        <MainHeading>
          <span>04 </span> Simple Steps
        </MainHeading>
        <ContextContainer background={Label}>
          <TextContainer>
            <Heading>Step 1 – Create Your Appointment Reminders</Heading>
            <List>Select Outreach Type – Text Message, Call, Email</List>
            <List>Build Your Content</List>
            <List>Start With a Template</List>
            <List>
              Include Custom Fields Like Customer Name, Company Name, App Date &
              Time, Phone Numbers and More!
            </List>
            <List>
              Include Custom Text Such as Room Numbers, Amount Due, Physician
              Name, etc…
            </List>
            <List>Allow Responses Such as “1”, “Confirm”, etc…</List>
            <List>
              Create Multiple Templates For Different Appointment Types,
              Clinics, or Locations
            </List>
          </TextContainer>
          <TextContainer1>
            <Heading>Step 2 – Choose Source</Heading>
            <List1>Basic Integrations:</List1>
            <List>Schedule Through Our Web Interface</List>
            <List>
              Link Your Google Calendar – Send Appointment Reminders & Receive
              Replies in the Calendar
            </List>
            <List>
              Upload Excel or Text Files Easily and Securely Through Our Web
              Interface
            </List>
            <List1>Advanced Integrations:</List1>
            <List>
              Use Our Integration Service With Any Software That Can Export
              Appointment Information.
            </List>
            <List>
              We Can Create and Manage Your Data Extract or Integrate Directly
              Into Your EMR or Scheduling software.
            </List>
          </TextContainer1>
          <TextContainer2>
            <Heading>Step 3 – Schedule Your Reminders </Heading>
            <List>
              Send Appointment Reminders Immediately or Sent Relative to
              Appointment Date
            </List>
            <List>Roll Failed Text Reminders to Calls</List>
            <List>
              Set Up Alerts Via Text or Email When Responses are Received
            </List>
            <List>
              Send Multiple Reminders for an Appointment. Week Before, Day
              Before, Day Of, etc…
            </List>
            <List>
              Send Messages After the Appointment to Solicit Feedback from your
              Customers
            </List>
            <List>
              Leverage Google’s built-in Calendar features such as Recurring
              Appointments
            </List>
          </TextContainer2>
          <TextContainer3>
            <Heading>Step 4 – View Results</Heading>
            <List>
              View & Download Appointment Reminder Delivery Status and Replies
              Through Our Web Interface
            </List>
            <List>Receive Nightly Emailed Reports</List>
            <List>
              Link Google Calendar & See Replies and/or Change Event Colors On
              Your Calendar 
            </List>
            <List>Download Reports To Your Desktop Automatically</List>
            <List>
              With our service it’s super easy to stay on top of your customer’s
              replies and confirmations!
            </List>
          </TextContainer3>
        </ContextContainer>
        <ContextContainer1>
          <Textcontainer>
            <Heading>Step 1 – Create Your Appointment Reminders</Heading>
            <List>Select Outreach Type – Text Message, Call, Email</List>
            <List>Build Your Content</List>
            <List>Start With a Template</List>
            <List>
              Include Custom Fields Like Customer Name, Company Name, App Date &
              Time, Phone Numbers and More!
            </List>
            <List>
              Include Custom Text Such as Room Numbers, Amount Due, Physician
              Name, etc…
            </List>
            <List>Allow Responses Such as “1”, “Confirm”, etc…</List>
            <List>
              Create Multiple Templates For Different Appointment Types,
              Clinics, or Locations
            </List>
          </Textcontainer>
          <Textcontainer1>
            <Heading>Step 2 – Choose Source</Heading>
            <List1>Basic Integrations:</List1>
            <List>Schedule Through Our Web Interface</List>
            <List>
              Link Your Google Calendar – Send Appointment Reminders & Receive
              Replies in the Calendar
            </List>
            <List>
              Upload Excel or Text Files Easily and Securely Through Our Web
              Interface
            </List>
            <List1>Advanced Integrations:</List1>
            <List>
              Use Our Integration Service With Any Software That Can Export
              Appointment Information.
            </List>
            <List>
              We Can Create and Manage Your Data Extract or Integrate Directly
              Into Your EMR or Scheduling software.
            </List>
          </Textcontainer1>
          <Textcontainer2>
            <Heading>Step 3 – Schedule Your Reminders </Heading>
            <List>
              Send Appointment Reminders Immediately or Sent Relative to
              Appointment Date
            </List>
            <List>Roll Failed Text Reminders to Calls</List>
            <List>
              Set Up Alerts Via Text or Email When Responses are Received
            </List>
            <List>
              Send Multiple Reminders for an Appointment. Week Before, Day
              Before, Day Of, etc…
            </List>
            <List>
              Send Messages After the Appointment to Solicit Feedback from your
              Customers
            </List>
            <List>
              Leverage Google’s built-in Calendar features such as Recurring
              Appointments
            </List>
          </Textcontainer2>
          <Textcontainer3>
            <Heading>Step 4 – View Results</Heading>
            <List>
              View & Download Appointment Reminder Delivery Status and Replies
              Through Our Web Interface
            </List>
            <List>Receive Nightly Emailed Reports</List>
            <List>
              Link Google Calendar & See Replies and/or Change Event Colors On
              Your Calendar 
            </List>
            <List>Download Reports To Your Desktop Automatically</List>
            <List>
              With our service it’s super easy to stay on top of your customer’s
              replies and confirmations!
            </List>
          </Textcontainer3>
        </ContextContainer1>
      </MainContainer>
    </>
  );
};

export default HFrame4;
