import React from "react";
import {
  ContextContainer,
  Heading,
  MainContainer,
  Picture,
  TextContainer,
  List,
  Heading2,
} from "./StyledHFrame3";
import Back from "../../Images/Back.png";
import Msg from "../../Images/4.png";
import Call from "../../Images/5.png";
import Mail from "../../Images/6.png";

const HFrame3 = () => {
  return (
    <>
      <MainContainer background={Back} className="pb- pt-5">
        <ContextContainer>
          <Picture src={Msg} />
          <TextContainer>
            <Heading>Text Message Appointment Reminders (SMS)</Heading>
            <Heading2>Text messages – Simple & Easy!</Heading2>
            <List>Complete customization of your text message content</List>
            <List>
              Accept customized responses such as “1” or “C” or “Confirm”, etc…
            </List>
            <List>
              Include dynamic fields such as Customer/Patient name, Appt Date &
              Time
            </List>
            <List>
              Include custom text such as room numbers, amounts due, location
              names
            </List>
            <List>Roll failed text messages to calls automatically</List>
            <List>Unlimited appointment reminder templates</List>
          </TextContainer>
        </ContextContainer>
        <ContextContainer>
          <TextContainer>
            <Heading>Phone Call Appointment Reminders</Heading>
            <Heading2>Phone Call Reminders – Clear & Reliable!</Heading2>
            <List>Send call reminders from your verified office Caller ID</List>
            <List>
              Build your phone call appointment reminders from an in-house
              library of over 150 per-recorded voice files
            </List>
            <List>
              Record voice files over the phone for no additional charge
            </List>
            <List>Highest quality text-to-speech</List>
          </TextContainer>
          <Picture src={Call} />
        </ContextContainer>
        <ContextContainer className="pb-5">
          <Picture src={Mail} />
          <TextContainer className="pb-5">
            <Heading>Email Appointment Reminders</Heading>
            <Heading2>Email Reminders – Professional Look & Feel!</Heading2>
            <List>
              Add logo, branding colors, company name, number and other custom
              fields 
            </List>
            <List>
              Allow customers to confirm by pressing buttons in the email
            </List>
            <List>
              Emails are readable in most email programs & configured to avoid
              spam filters
            </List>
            <List>
              Allow customers to easily unsubscribe from the appointment
              reminders
            </List>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
    </>
  );
};

export default HFrame3;
