import React from "react";
import {
  CardContainer,
  CardContainer1,
  Heading,
  Holder,
  MainContainer,
  Icon,
  CardHeading,
  CardText,
  CardList1,
  CardList2,
  CardContext,
} from "./StyledHFrame2";
import Business from "../../Images/1.png";
import Doctor from "../../Images/2.png";
import Building from "../../Images/3.png";

const HFrame2 = () => {
  return (
    <>
      <MainContainer>
        <Holder>
          <CardContainer>
            <Icon src={Business} />
            <CardContext>
              <CardHeading>SMALL BUSINESS</CardHeading>
              <CardText>
                Our small business package gives you all the functionality you
                need to send automated appointment reminders to your customers.
              </CardText>
              <CardList1>Upload Files</CardList1>
              <CardList1>Link Your Google Calendar</CardList1>
              <CardList1>Discounts for Non-Profits</CardList1>
              <CardList1>More! </CardList1>
            </CardContext>
          </CardContainer>
          <CardContainer1>
            <Icon src={Doctor} />
            <CardContext>
              <CardHeading>
                <span>Medical & Dental</span>
              </CardHeading>
              <CardList2>
                We Specialize in HIPAA Compliant Appointment Reminders
              </CardList2>
              <CardList2>Full HIPAA Compliant Data Storage</CardList2>
              <CardList2>Decrease Patient No Show Rate by Over 90% </CardList2>
              <CardList2>Link your Scheduler or EMR to Our System.</CardList2>
              <CardList2>Send different Reminders Based on Appt Type</CardList2>
              <CardList2>Include Dr’s Name & Facility Info</CardList2>
              <CardList2>Professional & Experienced </CardList2>
            </CardContext>
          </CardContainer1>
          <CardContainer>
            <Icon src={Building} />
            <CardContext>
              <CardHeading>LARGE BUSINESS </CardHeading>
              <CardList1>Multi-Site Configurations</CardList1>
              <CardList1>
                Configure Appt Reminders Across Multiple Facilities With
                Different Names, Addresses, Etc…
              </CardList1>
              <CardList1>Detailed Invoicing With Facility Breakdowns</CardList1>
              <CardList1>
                Separate or Shared Accounts Across Locations
              </CardList1>
              <CardList1>Volume Discounts</CardList1>
              <CardList1>Private & Secure</CardList1>
              <CardList1>No Long-Term Contracts!</CardList1>
            </CardContext>
          </CardContainer>
        </Holder>
        <Heading>
          <span>Text, Call, & Email </span> Appointment Reminders
        </Heading>
      </MainContainer>
    </>
  );
};

export default HFrame2;
