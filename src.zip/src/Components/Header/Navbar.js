import React, { useState } from "react";
import {
  HelpInfoContainer,
  LogoContainer,
  MainContainer,
  Menu,
  Menu1,
  Menu2,
  MenuContainer,
  NavList,
  NavMenu,
  NavbarContainer,
  SignInButton,
  HumburgerCont,
  ButtonContainer,
} from "./StyledNavbar";
import { Link, useNavigate } from "react-router-dom";
import { IoIosArrowDown } from "react-icons/io";
import Pic from "../Images/Name.png";
import { GiHamburgerMenu } from "react-icons/gi";

const Navbar = () => {
  const navigate = useNavigate();

  const Sign_In = () => {
    navigate("/signin");
  };

  const [openMenu, setOpenMenu] = useState(null);
  const [shownav, setshownav] = useState(false);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const togglenav = () => {
    setshownav(!shownav);
  };

  return (
    <MainContainer>
      <NavbarContainer>
        <Link to="/">
          <LogoContainer src={Pic} alt="Logo" />
        </Link>
        <MenuContainer>
          <NavMenu shownav={shownav}>
            <NavList>
              <Link to="/">Home</Link>
            </NavList>
            <NavList onClick={() => toggleMenu("Services")}>
              <Link>Reminder & Services</Link>
              <IoIosArrowDown />
            </NavList>
            <HelpInfoContainer>
              <Menu2 showMenu={openMenu === "Services"}>
                <NavList>
                  <Link to="/medicalpatient">Medical Patient Reminders</Link>
                </NavList>
                <NavList>
                  <Link to="/businessreminder">Business Reminders</Link>
                </NavList>
                <NavList>
                  <Link to="/disaccounts">Free & Discounted Accounts</Link>
                </NavList>
                <NavList>
                  <Link to="/callreminder">Call Reminder</Link>
                </NavList>
                <NavList>
                  <Link to="/msgreminder">Text Reminder</Link>
                </NavList>
                <NavList>
                  <Link to="/emailreminder">Email Reminder</Link>
                </NavList>
              </Menu2>
            </HelpInfoContainer>
            <NavList>
              <Link to="/pricing">Pricing</Link>
            </NavList>
            <NavList onClick={() => toggleMenu("Help")}>
              <Link>Help & Info</Link>
              <IoIosArrowDown />
            </NavList>
            <HelpInfoContainer>
              <Menu showMenu={openMenu === "Help"}>
                <NavList>
                  <Link to="/help_home">Help Docs</Link>
                </NavList>
                <NavList>
                  <Link to="/faqs">FAQ’s</Link>
                </NavList>
                <NavList>
                  <Link to="/rules">Privacy Policy</Link>
                </NavList>
                <NavList>
                  <Link to="/singleblog">Blog</Link>
                </NavList>
              </Menu>
            </HelpInfoContainer>
            <NavList onClick={() => toggleMenu("Inte")}>
              <Link>Integrations</Link>
              <IoIosArrowDown />
            </NavList>
            <HelpInfoContainer>
              <Menu1 showMenu={openMenu === "Inte"}>
                <NavList>
                  <Link to="/basic">Basic Integration</Link>
                </NavList>
                <NavList>
                  <Link to="/advance">Advanced Integration</Link>
                </NavList>
              </Menu1>
            </HelpInfoContainer>
            <NavList>
              <Link to="/aboutus">About Us</Link>
            </NavList>
            <NavList>
              <Link to="/contactus">Contact Us</Link>
            </NavList>
          </NavMenu>
        </MenuContainer>
        <ButtonContainer>
          <SignInButton onClick={Sign_In}>Sign-In</SignInButton>
          <HumburgerCont onClick={togglenav}>
            <GiHamburgerMenu />
          </HumburgerCont>
        </ButtonContainer>
      </NavbarContainer>
    </MainContainer>
  );
};

export default Navbar;
