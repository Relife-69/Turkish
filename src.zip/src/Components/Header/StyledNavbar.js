import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  align-items: center;
  justify-content: center;
  background-color: white;
`;

export const NavbarContainer = styled.nav`
  height: 90px;
  width: 90%;
  margin: 3% 5%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  background-color: #e6f6fe;
  color: black;
  border-radius: 20px;
  box-shadow: 0px 1px 10px 1px rgba(0, 0, 0, 0.25);
`;

export const LogoContainer = styled.img`
  width: 150px;
  height: 70px;
`;

export const SignInButton = styled.button`
  width: 110px;
  height: 45px;
  border-radius: 6px;
  background-color: #1376f8;
  color: white;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  font-weight: 500;
  line-height: 21.78px;
  cursor: pointer;

  &:hover {
    background-color: white;
    color: #1376f8;
    border: 2px solid #1376f8;
  }
`;

export const MenuContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const NavMenu = styled.ul`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  padding: 0%;
  margin: 0%;
  @media (max-width: 1100px) {
    flex-direction: ${({ shownav }) => (shownav ? "column" : "row")};
    display: ${({ shownav }) => (shownav ? "flex" : "none")};
    position: absolute;
    right: 50px;
    align-items: center;
    justify-content: center;
    background: #1376f8;
    color: white;
    padding: 40px;
    top: 115px;
    z-index: 9999;
    border-radius: 15px;
    border: 2px solid white;
    gap: 15px;
    margin: 0%;
  }

  @media (max-width: 600px) {
    padding: 10px;
    right: 20px;
    top: 100px;
  }
`;

export const HumburgerCont = styled.div`
  display: none;

  @media (max-width: 1100px) {
    display: flex;
    font-size: 50px;
    color: #1376f8;
  }
`;
export const NavList = styled.li`
  font-size: 18px;
  font-weight: 600;
  list-style: none;
  display: flex;
  gap: 4px;
  align-items: center;
  cursor: pointer;
  justify-content: center;
  @media (max-width: 600px) {
    font-size: 14px;
    font-weight: 300;
  }

  a {
    color: black;
    text-decoration: none;
    @media (max-width: 1100px) {
      color: white;
    }

    &:hover {
      color: #1376f8;
      @media (max-width: 1100px) {
        color: white;
      }
    }
  }
`;

export const HelpInfoContainer = styled.div``;

const MenuStyles = styled.ul`
  width: 300px;
  flex-wrap: wrap;
  min-height: 100px;
  align-items: start;
  justify-content: start;
  display: ${({ showMenu }) => (showMenu ? "flex" : "none")};
  padding: 20px;
  position: absolute;
  flex-direction: column;
  background-color: #1376f8;
  color: white;
  border-radius: 8px;
  z-index: 9999;
  border: 2px solid white;
  gap: 20px;

  a {
    color: white;
    flex-direction: column;
    text-decoration: none;

    &:hover {
      color: #e6f6fe;
    }
  }

  @media (max-width: 600px) {
    padding: 10px;
    width: 150px;
  }
`;

export const Menu = styled(MenuStyles)`
  top: 150px;
  right: 40%;
  @media (max-width: 1100px) {
    top: 200px;
    right: 100%;
  }
  @media (max-width: 600px) {
    top: 150px;
  }
`;

export const Menu1 = styled(MenuStyles)`
  top: 150px;
  right: 30%;
  @media (max-width: 600px) {
    top: 200px;
  }
`;

export const Menu2 = styled(MenuStyles)`
  top: 150px;
  right: 55%;
  @media (max-width: 1100px) {
    top: 120px;
    right: 100%;
  }
  @media (max-width: 600px) {
    top: 50px;
  }
`;

export const Menu3 = styled(MenuStyles)`
  top: 300px;
  right: 100%;
`;

export const ButtonContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
`;
