import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import Pic from "../../Components/Images/Background.png";
import Pic1 from "../../Components/Images/21.png";
import {
  ContextContainer,
  Description,
  Heading,
  Image1,
  Image3,
  List,
  ListContainer,
  LowerContainer,
  MainContainer,
  MainHeading,
  PictureContainer,
  TextContainer,
  TextContainer1,
  UpperContainer,
} from "./StyledCompanyPRules";

const CompanyPRules = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <UpperContainer>
          <ContextContainer>
            <MainHeading>
              <span>Privacy Policy </span> & Terms of Use
            </MainHeading>
            <TextContainer>
              <Heading>Our Commitment To Privacy and Security</Heading>
              <Description>
                We take your company and your customers privacy very seriously.
                We do not share any information across sites and only store
                enough information to make your reminders. Please read our
                Privacy Policy and Terms of Use for details.
              </Description>
            </TextContainer>
            <TextContainer>
              <Heading>APPOINTMENTREMINDERS.COM, LLC PRIVACY POLICY</Heading>
              <Description>
                Welcome to AppointmentReminders.com. If you visit, upload
                content to, or otherwise use the AppointmentReminders.com
                website (the “Website”), you are accepting this Privacy Policy,
                which constitutes a legally binding agreement between you and
                AppointmentReminders.com, LLC, a Colorado limited liability
                company (“AppointmentReminders.com” sometimes referred to in
                herein as “we,” “us,” or “our”). Please read this Privacy Policy
                carefully. If you do not agree with or do not accept this
                Privacy Policy, please exit the Website immediately and refrain
                from any further access and use of the Website.
              </Description>
            </TextContainer>
          </ContextContainer>
          <PictureContainer>
            <Image1 src={Pic} alt="Background" />
            <Image3 src={Pic1} alt="21" />
          </PictureContainer>
        </UpperContainer>
        <LowerContainer>
          <TextContainer1>
            <Heading>I. Collection of Information</Heading>
            <Description>
              1. Personally Identifiable Information. This statement applies to
              personally identifiable information collected from our users. When
              this Privacy Policy uses the term “personally identifiable
              information,” we mean information that identifies a particular
              individual, such as the individual’s name, postal address, e-mail
              address, credit card number, and telephone number. When other
              information, such as, for example, consumer product preferences,
              or number of children, is directly associated with personally
              identifiable information, this other information also becomes
              personally identifiable information for purposes of this Privacy
              Policy. Personally identifiable information is sometimes referred
              to in this Privacy Policy as “personal information.”
            </Description>
            <Description>
              2. Access. Users can access limited features of the Website
              without disclosing personal information. In order to access the
              entire Website, users must register for an account, which will
              provide the registrant with full access to the Website, including
              access to the Website’s forums and message boards.
            </Description>
            <Description>
              3. Information Sought During Registration. During the account
              registration process, you will be asked to submit the following
              personal information, including your name and at least one active
              email address. At this time, you will also have the opportunity to
              subscribe to reports, information about our services and special
              offers or events. You can unsubscribe from receiving any
              information from us at any time by updating your registration
              account information online.
            </Description>
            <Description>
              4. Information for Reminder Calls. Unless additional information
              is voluntarily provided to us, we will only collect and store the
              following information regarding the persons who will be receiving
              reminder calls:
            </Description>
            <ListContainer>
              <List>Customer First Lame</List>
              <List>Customer Last Lame</List>
              <List>Primary Phone Number</List>
              <List>Appointment Date</List>
              <List>Appointment Time</List>
            </ListContainer>
            <Description>
              The additional information you may choose to share with us
              includes:
            </Description>
            <ListContainer>
              <List>Customer ID </List>
              <List>Appointment Type</List>
              <List>Secondary Phone Number</List>
              <List>Email Address</List>
              <List>Outreach Preference (Call, Text, Email)</List>
            </ListContainer>
            <Description>
              5. Automatically Collected Information. Information concerning
              your computer hardware and software is automatically collected and
              may be shared with our affiliates and partners. This information
              may include: your IP address, browser type, domain names, access
              times and referring website addresses. We use this information to
              maintain the quality of our service and to provide general
              statistics about Website visitors.  
            </Description>
            <Description>
              6. Storage and Transfer of Personally Identifiable Information. We
              may store and process Personally Identifiable Information in the
              United States or any other country in which
              AppointmentReminders.com or its affiliates, subsidiaries, or
              agents maintain facilities. By using the Website, you consent to
              any such transfer of information outside of your country.  
            </Description>
            <Description>
              7. Credit Card Information. We will not store your credit card
              information on our website. Credit card processing and information
              will be handled exclusively by a qualified third party service
              provider.
            </Description>
          </TextContainer1>
          <TextContainer1>
            <Heading>II. Use and Sharing of Information</Heading>
            <Description>
              1. Collection of Information. We collect and use your personal
              information in order to operate the Website and to provide its
              online and electronic services. The collection of your email
              address, name and address during account registration enables us
              to send you any requested reports or offers. Information
              concerning your geographical location is used to determine if we
              should provide regionalized information to our customers. Except
              as otherwise stated below, the personal information you provide on
              the Website will not be shared with any third-parties, although we
              reserve the right to share such information with our affiliates
              and subsidiaries without your permission.
            </Description>
            <Description>
              2. Sharing Information with Service Providers. We sometimes hire
              other companies to provide limited services on our behalf, such as
              sending information, providing customer service, and performing
              statistical analysis of our services. We will only provide those
              companies with the information that they need to provide us with
              such services, and we prohibit them from using that information
              for any other purpose.
            </Description>
            <Description>
              3. Sharing Information Required by Law. We reserve the right to
              disclose your personal information, without notice, if required to
              do so by law or in the good faith belief that such action is
              necessary to (a) conform to the edicts of the law or comply with
              legal process served on us; (b) protect and defend our rights or
              property and, (c) act under exigent circumstances to protect the
              personal safety of our users, other websites, or the public.
            </Description>
            <Description>
              4. Our Use of Your Personal Information. We provide links to send
              email messages to us for your convenience and your email address
              is used so that we may reply to your inquiry. We track the pages
              on the Website that our customers visit in order to determine
              which areas of the Website are the most popular. This data is used
              to deliver customized content and advertising within the Website
              to customers whose behavior indicates that they are interested in
              a particular subject area.
            </Description>
            <Description>
              5. Retention of Personal Information. We will only retain personal
              information as long as necessary for us to provide the services
              you have requested.
            </Description>
          </TextContainer1>
          <TextContainer1>
            <Heading>III. Information from Other Sources</Heading>
            <Description>
              We sometimes supplement the information that we receive that has
              been outlined in this Privacy Policy with information from other
              sources and companies. Such outside information includes updated
              delivery and address information from carriers or third parties,
              which enables us to correct our records and deliver future
              communications more easily; account information, purchase or
              redemption information, and page-view information from some
              merchants with which we operate co-branded businesses or for which
              we provide technical, fulfillment, advertising, or other services;
              search term and search result information from some searches
              conducted through web search features; search results and links,
              including paid listings (such as sponsored links); and credit
              history information from credit bureaus, which we use to help
              prevent and detect fraud and to offer certain credit or financial
              services to some customers.  
            </Description>
          </TextContainer1>
        </LowerContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default CompanyPRules;
