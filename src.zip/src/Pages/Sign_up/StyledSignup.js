import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 90px;
  flex-direction: column;
  padding: 30px 0px;
  flex-wrap: wrap;
`;
export const UpperContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 150px;
  position: relative;
  flex-wrap: wrap;
  @media (max-width: 1000px) {
    margin: 50px 0px;
  }
  @media (max-width: 700px) {
    margin: 50px 0px;
    gap: 50px;
  }
`;
export const PictureContainer = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: center;
  justify-content: start;
  @media (max-width: 1000px) {
    width: 400px;
    height: 400px;
  }
  @media (max-width: 500px) {
    width: 350px;
    height: 350px;
  }
  @media (max-width: 400px) {
    width: 280px;
    height: 280px;
  }
`;
export const Image1 = styled.img`
  width: 600px;
  height: 600px;
  border-radius: 50%;
  border: none;
  position: absolute;
  @media (max-width: 1000px) {
    width: 500px;
    height: 500px;
  }
  @media (max-width: 500px) {
    width: 350px;
    height: 350px;
  }
  @media (max-width: 400px) {
    width: 280px;
    height: 280px;
  }
`;
export const Image2 = styled.img`
  width: 600px;
  height: 600px;
  border-radius: 50%;
  border: none;
  top: 60px;
  position: relative;
  right: 60px;
  @media (max-width: 1000px) {
    width: 500px;
    height: 500px;
    right: 40px;
    top: 40px;
  }
  @media (max-width: 500px) {
    width: 350px;
    height: 350px;
    right: 30px;
    top: 30px;
  }
  @media (max-width: 400px) {
    width: 280px;
    height: 280px;
  }
`;
export const SignupContainer = styled.div`
  width: 380px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 40px;
  flex-direction: column;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const LogoContainer = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 50%;
`;
export const InputFieldContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 35px;
  flex-direction: column;
  @media (max-width: 400px) {
    align-items: center;
    justify-content: center;
  }
`;
export const InputContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 8px;
  flex-direction: column;
`;
export const Heading = styled.h1`
  width: 380px;
  font-size: 28px;
  font-weight: 700;
  text-align: left;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Label = styled.label`
  font-size: 14px;
  font-weight: 400;
`;
export const InputField = styled.input`
  width: 350px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid silver;
  padding: 5px 15px;
  font-size: 12px;
  font-weight: 400;
  &:focus {
    outline: none;
  }
  &:active {
    outline: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const NameInputContainer = styled.div`
  width: 380px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 30px;
  flex-wrap: wrap;
  @media (max-width: 400px) {
    width: 250px;
    gap: 10px;
  }
`;
export const NameInput = styled.div`
  width: 175px;
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 10px;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const NameInputField = styled.input`
  width: 150px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid silver;
  padding: 5px 15px;
  font-size: 12px;
  font-weight: 400;
  &:focus {
    outline: none;
  }
  &:active {
    outline: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const AccountInput = styled.select`
  width: 380px;
  height: 40px;
  border-radius: 4px;
  border: 1px solid silver;
  font-size: 12px;
  background-color: aliceblue;
  font-weight: 400;
  &:focus {
    outline: none;
  }
  &:active {
    outline: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const CheckBox = styled.div`
  width: 380px;
  display: flex;
  align-items: center;
  justify-content: start;
  gap: 10px;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const CheckBoxInput = styled.input`
  width: 15px;
  height: 15px;
`;
export const CheckBoxLabel = styled.label`
  display: flex;
  align-items: start;
  justify-content: start;
  font-family: Inter;
  font-size: 15px;
  font-weight: 300;
`;
export const ButtonContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  flex-wrap: wrap;
`;
export const Button1 = styled.button`
  width: 180px;
  background-color: #1376f8;
  color: white;
  height: 40px;
  font-size: 18px;
  font-weight: 400;
  border: none;
  border-radius: 8px;
  &:hover {
    background-color: white;
    color: #1376f8;
    border: 1px solid #1376f8;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Button2 = styled.button`
  width: 180px;
  background-color: #ced4da;
  color: white;
  height: 40px;
  font-size: 18px;
  font-weight: 400;
  border: none;
  border-radius: 8px;
  &:hover {
    border: 1px solid #ced4da;
    background-color: white;
    color: #ced4da;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const LowerContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-around;
  position: relative;
  width: 100%;
  z-index: 9999;
`;
export const CardHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 50px;
  position: relative;
  z-index: 9999;
  flex-wrap: wrap;
`;
export const CardContainer = styled.div`
  width: 350px;
  height: 390px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 1px 0px 7px 1px rgba(0, 0, 0, 0.25);
  flex-direction: column;
  gap: 30px;
  position: relative;
  z-index: 9999;
  @media (max-width: 400px) {
    width: 250px;
    padding: 0px 15px;
  }
`;
export const CardHeading = styled.h1`
  width: 350px;
  height: 60px;
  align-items: center;
  justify-content: center;
  text-align: center;
  border-bottom: 2px solid #1376f8;
  font-family: Inter;
  font-size: 24px;
  font-weight: 500;
  line-height: 29.05px;
  @media (max-width: 400px) {
    width: 250px;
  }
`;

export const InnerCardContainer = styled.div`
  width: 270px;
  min-height: 198px;
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: center;
  gap: 30px;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const CardText1 = styled.p`
  font-family: Inter;
  font-size: 18px;
  font-weight: 700;
  line-height: 21.78px;
  text-align: left;
  margin: 0%;
  @media (max-width: 400px) {
    font-size: 14px;
    font-weight: 300;
  }
`;
export const CardText2 = styled.p`
  font-family: Inter;
  font-size: 18px;
  font-weight: 400;
  line-height: 21.78px;
  text-align: left;
  margin: 0%;
  @media (max-width: 400px) {
    font-size: 14px;
    font-weight: 300;
  }
`;
export const ImageContainer = styled.img`
  position: absolute;
  right: 0px;
  bottom: 0px;
  z-index: 9999;
`;

export const CheckBoxContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 5px;
`;
export const CheckBox1 = styled.input`
  width: 15px;
  height: 15px;
`;
