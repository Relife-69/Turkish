import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  MainContainer,
  UpperContainer,
  InputContainer,
  PictureContainer,
  Image1,
  Image2,
  LogoContainer,
  InputFieldContainer,
  Heading,
  Label,
  InputField,
  ButtonContainer,
  Button1,
  Button2,
  NameInputContainer,
  SignupContainer,
  NameInput,
  NameInputField,
  AccountInput,
  LowerContainer,
  CardHeading,
  CardContainer,
  InnerCardContainer,
  CardText1,
  CardText2,
  ImageContainer,
  CardHolder,
  CheckBoxContainer,
  CheckBox1,
} from "./StyledSignup";
import Pic1 from "../../Components/Images/Background.png";
import Pic2 from "../../Components/Images/Logo.png";
import { Link } from "react-router-dom";
import Pic3 from "../../Components/Images/Poster.png";

const Signup = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [userName, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [companyPhone, setCompanyPhone] = useState("");
  const [contactFirstName, setContactFirstName] = useState("");
  const [contactSecondName, setContactSecondName] = useState("");
  const [contractPhone, setContractPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [accountType, setAccountType] = useState("");
  const [acceptAgreement, setAcceptAgreement] = useState(false);

  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    const user = {
      first_name: firstName,
      last_name: lastName,
      username: userName,
      email,
      company_name: companyName,
      company_phone: companyPhone,
      password,
      confirm_password: confirmPassword,
      contact_first_name: contactFirstName,
      contact_last_name: contactSecondName,
      contact_phone: contractPhone,
      agree_to_terms: acceptAgreement,
      account_type: accountType,
    };

    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/signup/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("User signed up successfully:", result.data);
      navigate("/signin");
    } catch (error) {
      console.error("Error signing up:", error);
      setError(error.response ? error.response.data : "Error signing up");
    }
  };

  return (
    <>
      <MainContainer>
        <UpperContainer>
          <SignupContainer>
            <LogoContainer src={Pic2}></LogoContainer>
            <InputFieldContainer>
              <Heading>Welcome!</Heading>
              <form onSubmit={handleSubmit}>
                <InputContainer>
                  <NameInputContainer>
                    <NameInput>
                      <Label>First Name</Label>
                      <NameInputField
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="First Name"
                      />
                    </NameInput>
                    <NameInput>
                      <Label>Last Name</Label>
                      <NameInputField
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="Last Name"
                      />
                    </NameInput>
                  </NameInputContainer>
                  <Label>Username</Label>
                  <InputField
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Username"
                  />
                  <Label>Password</Label>
                  <InputField
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                  />
                  <Label>Confirm Password</Label>
                  <InputField
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm Password"
                  />
                  <Label>Company Name</Label>
                  <InputField
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Company Name"
                  />
                  <Label>Company Phone No</Label>
                  <InputField
                    type="tel"
                    value={companyPhone}
                    onChange={(e) => setCompanyPhone(e.target.value)}
                    placeholder="Company Phone Number"
                  />
                  <Label>Contact First Name</Label>
                  <InputField
                    type="text"
                    value={contactFirstName}
                    onChange={(e) => setContactFirstName(e.target.value)}
                    placeholder="Contact First Name"
                  />
                  <Label>Contact Last Name</Label>
                  <InputField
                    type="text"
                    value={contactSecondName}
                    onChange={(e) => setContactSecondName(e.target.value)}
                    placeholder="Contact Last Name"
                  />
                  <Label>Contact Primary Phone No</Label>
                  <InputField
                    type="tel"
                    value={contractPhone}
                    onChange={(e) => setContractPhone(e.target.value)}
                    placeholder="Contact Primary Phone Number"
                  />
                  <Label>Email</Label>
                  <InputField
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                  />
                  <Label>Account Type</Label>
                  <AccountInput
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value)}
                  >
                    <option>Select An Option</option>
                    <option value="personal">Personal</option>
                    <option value="smallbusiness">Business</option>
                    <option value="premium">Premium</option>
                  </AccountInput>
                  <CheckBoxContainer>
                    <CheckBox1
                      type="checkbox"
                      id="checkAccept"
                      name="accept_agreement"
                      checked={acceptAgreement}
                      onChange={(e) => setAcceptAgreement(e.target.checked)}
                    />
                    <Label>
                      <Link to="/agreements">Accept the Agree</Link>
                    </Label>
                  </CheckBoxContainer>
                  <ButtonContainer>
                    <Button1 type="submit">Submit</Button1>
                    <Button2 type="reset">Clear</Button2>
                  </ButtonContainer>
                </InputContainer>
              </form>
            </InputFieldContainer>
          </SignupContainer>
          <PictureContainer>
            <Image1 src={Pic1} />
            <Image2 src={Pic2} />
          </PictureContainer>
        </UpperContainer>
        <LowerContainer>
          <ImageContainer src={Pic3} />
          <CardHolder>
            <CardContainer>
              <CardHeading>PERSONAL</CardHeading>
              <InnerCardContainer>
                <CardText1>
                  Allows you to link a calendar or upload files on a budget!
                </CardText1>
                <CardText2>Monthly Cost: $29.95</CardText2>
                <CardText2>Num of Reminders Included: 400</CardText2>
                <CardText2>Cost of Additional 100 Reminders: $7.50</CardText2>
              </InnerCardContainer>
            </CardContainer>
            <CardContainer>
              <CardHeading>PERSONAL</CardHeading>
              <InnerCardContainer>
                <CardText1>
                  Allows you to link a calendar or upload files on a budget!
                </CardText1>
                <CardText2>Monthly Cost: $29.95</CardText2>
                <CardText2>Num of Reminders Included: 400</CardText2>
                <CardText2>Cost of Additional 100 Reminders: $7.50</CardText2>
              </InnerCardContainer>
            </CardContainer>
            <CardContainer>
              <CardHeading>PERSONAL</CardHeading>
              <InnerCardContainer>
                <CardText1>
                  Allows you to link a calendar or upload files on a budget!
                </CardText1>
                <CardText2>Monthly Cost: $29.95</CardText2>
                <CardText2>Num of Reminders Included: 400</CardText2>
                <CardText2>Cost of Additional 100 Reminders: $7.50</CardText2>
              </InnerCardContainer>
            </CardContainer>
          </CardHolder>
        </LowerContainer>
      </MainContainer>
    </>
  );
};

export default Signup;
