import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  CardContainer,
  Container,
  Container1,
  ContextContainer,
  ContextContainer1,
  Description,
  Description1,
  Heading,
  Heading1,
  Heading2,
  Image1,
  Image2,
  Image3,
  Image4,
  ListContainer,
  MainContainer,
  PictureContainer,
  PictureContainer2,
  TextContainer,
  List,
} from "./StyledBasicIntegration";
import Back from "../../Components/Images/Background.png";
import Pic from "../../Components/Images/22.png";
import Pic1 from "../../Components/Images/23.png";
import Pic2 from "../../Components/Images/24.png";
import Pic3 from "../../Components/Images/25.png";

const BasicIntegration = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <Container>
          <ContextContainer>
            <Heading>Simple & Easy Data Integration</Heading>
            <Description>
              Welcome to the Basic Integration page for
              AppointmentReminders.com! This is the first step toward
              simplifying and automating your appointment reminder process.
            </Description>
            <Description>Whether you're looking to</Description>
            <Description>
              {" "}
              1. Schedule Appointments Through our Web Interface…
            </Description>
            <Description>
              {" "}
              2. Connect Seamlessly with Google Calendar…or
            </Description>
            <Description>
              {" "}
              3. Upload Appointments directly via Excel or CSV files…
            </Description>
            <Description>
              This page provides the essential information to get started.
            </Description>
            <Description>
              Tailored for ease of use and efficiency, our integration solutions
              are designed to fit a variety of needs, ensuring your appointments
              are always on track.
            </Description>
            <Description>
              The basic integrations offered by AppointmentReminders.com are
              best suited for scenarios where businesses need to automate and
              streamline their appointment scheduling and reminder processes.
              For example,a beauty salon using Google Calendar integration for
              seamless booking and reminder setup, or a consulting firmutilizing
              Excel uploads for bulk scheduling of client meetings. These
              integrations help in reducing no-shows, saving administrative
              time, and enhancing client communication and satisfaction.
            </Description>
            <Description>
              {" "}
              Also, visit our advanced integration page for info on integrating
              with electronic health records (EHR) to automatically send
              appointment reminders to patients.
            </Description>
          </ContextContainer>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic} />
          </PictureContainer>
        </Container>
        <Container>
          <CardContainer>
            <PictureContainer2>
              <Image3 src={Back} />
              <Image4 src={Pic1} />
            </PictureContainer2>
            <TextContainer>
              <Heading1>Web Interface</Heading1>
              <Description1>
                Use our online portal to schedule reminders and check replies in
                real-time
              </Description1>
            </TextContainer>
          </CardContainer>
          <CardContainer>
            <PictureContainer2>
              <Image3 src={Back} />
              <Image4 src={Pic2} />
            </PictureContainer2>
            <TextContainer>
              <Heading1>GOOGLE CALENDAR</Heading1>
              <Description1>
                Link your Google Calendar and automatically send reminders for
                your appointments
              </Description1>
            </TextContainer>
          </CardContainer>
          <CardContainer>
            <PictureContainer2>
              <Image3 src={Back} />
              <Image4 src={Pic3} />
            </PictureContainer2>
            <TextContainer>
              <Heading1>UPLOAD FILES</Heading1>
              <Description1>
                Upload simple excel or csv files with appointment info and send
                out scheduled reminders
              </Description1>
            </TextContainer>
          </CardContainer>
        </Container>
        <Container1>
          <ContextContainer1>
            <Heading1>Web Interface</Heading1>
            <Heading2>Full Feature Online Interface!</Heading2>
            <Description>
              Our web interface includes user-friendly scheduling tools,
              customization options for reminders (SMS, email, calls), calendar
              integration, client management features, automated reminder
              scheduling, real-time notifications, reporting tools for tracking
              no-shows and engagement, and secure data handling to protect
              client information. These features collectively aim to streamline
              the appointment management process, enhance client communication,
              and improve service efficiency.
            </Description>
            <ListContainer>
              <List>
                User Account Management: Secure login, password recovery, and
                customizable profiles.
              </List>
              <List>
                Dashboard: Overview of upcoming appointments, reminders sent,
                and response rates.
              </List>
              <List>
                Appointment Scheduling: Easy booking, rescheduling, and
                cancellation functionalities.
              </List>
              <List>
                Automated Reminders: Configurable reminders via SMS, email, and
                voice calls, with personalized messages.
              </List>
              <List>
                Client Database: Secure storage and management of client contact
                details and preferences.
              </List>
              <List>
                Customization Options: Tailoring reminder frequency, timing, and
                messaging.
              </List>
              <List>
                Reporting Tools: Analytics on appointment outcomes, no-show
                rates, and engagement metrics.
              </List>
              <List>
                Feedback Collection: Automated post-appointment feedback
                requests to gather client insights.
              </List>
              <List>
                Multi-User Access: Different access levels for staff to manage
                appointments and reminders.
              </List>
              <List>
                Data Security: Encryption and compliance measures to protect
                sensitive information.
              </List>
              <List>
                Technical Support: Easy access to help resources and customer
                support.
              </List>
            </ListContainer>
            <Description>
              There is much more you can do in with the Web Interface.  Browse
              our help files for more information.
            </Description>
            <Description>
              Everything is accessible online and there is no software to
              install or maintain.
            </Description>
          </ContextContainer1>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic2} />
          </PictureContainer>
        </Container1>
        <Container1>
          <ContextContainer1>
            <Heading1>Link Your Google Calendar</Heading1>
            <Heading2>Seamless Google Calendar Integration</Heading2>
            <Description>
              Linking Google Calendar allows for seamless synchronization of
              appointments, allowing automatic updates and reminders for
              appointments directly in your calendar, reducing manual entry and
              ensuring accuracy.
            </Description>
            <Description>
              It streamlines scheduling, provides real-time visibility of
              appointments, and enhances the efficiency of sending out
              reminders, offering a more integrated and automated approach to
              managing appointments.
            </Description>
            <Description>
              Once you set up the linking, everything is done through your
              Google Calendar.
            </Description>
            <Heading2>
              Google Calendar Appointment Reminder Sync Features
            </Heading2>
            <ListContainer>
              <List>
                Automatic Synchronization: Appointments added to Google Calendar
                automatically sync with the reminder service.
              </List>
              <List>
                Real-time Updates: Changes or cancellations in Google Calendar
                reflect immediately in the reminder system.
              </List>
              <List>
                Customizable Reminders: Set up personalized reminder messages
                and timing preferences.
              </List>
              <List>
                Multi-channel Notifications: Choose between SMS, email, or
                voice call reminders.
              </List>
              <List>
                Direct Management: Add, edit, or delete appointments directly
                from Google Calendar.
              </List>
              <List>
                Visibility and Sharing: Share appointment schedules with team
                members or clients through Google Calendar.
              </List>
              <List>
                Event Details Import: Automatically import and use event details
                from Google Calendar for reminders.
              </List>
              <List>
                Time Zone Support: Adjust reminders based on the time zone
                settings of Google Calendar events.
              </List>
              <List>
                Color Coding: Change event colors based on confirmation status.
              </List>
            </ListContainer>
          </ContextContainer1>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic1} />
          </PictureContainer>
        </Container1>
        <Container1>
          <ContextContainer1>
            <Heading1>Upload Files</Heading1>
            <Heading2>
              One of the simplest ways of integrating to our appointment
              reminder service is to upload files
            </Heading2>
            <Heading1>Upload File Features</Heading1>
            <ListContainer>
              <List>
                Upload excel or csv files with just some basic information.
              </List>
              <List>
                The only info we need is name, phone number, and appointment
                date/time.  
              </List>
              <List>
                Send additional fields such as reminder type, preferred
                language, and custom fields.
              </List>
              <List>
                Files are very simple to create and upload: We also provide
                templates for you.
              </List>
              <List>
                Bulk Appointment Import: Quickly upload multiple appointments at
                once.
              </List>
              <List>
                Error Detection: Identifies and highlights import errors or
                inconsistencies.
              </List>
              <List>
                Custom Reminder Scheduling: Set specific reminder times for each
                appointment.
              </List>
              <List>
                Data Mapping: Map Excel/CSV columns to appointment details.
              </List>
              <List>
                Flexible File Formats: Support for various Excel and CSV file
                structures.
              </List>
              <List>
                Automated Reminder Setup: Automatically configure reminders
                based on imported data.
              </List>
              <List>
                Update and Sync: Option to update existing appointments through
                re-upload.
              </List>
              <List>
                Secure Data Handling: Ensures data privacy and security during
                upload.
              </List>
            </ListContainer>
          </ContextContainer1>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic3} />
          </PictureContainer>
        </Container1>
      </MainContainer>
      <Footer />
    </>
  );
};

export default BasicIntegration;
