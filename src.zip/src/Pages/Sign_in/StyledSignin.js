import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  margin: 50px 0px;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap-reverse;
  @media (max-width: 1000px) {
    gap: 50px;
  }
`;
export const PictureContainer = styled.div`
  display: flex;
  width: 500px;
  height: 500px;
  align-items: center;
  justify-content: start;
  @media (max-width: 1000px) {
    width: 400px;
    height: 400px;
  }
  @media (max-width: 500px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 250px;
    height: 250px;
  }
`;
export const Image1 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  position: absolute;
  @media (max-width: 1000px) {
    width: 400px;
    height: 400px;
  }
  @media (max-width: 500px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 250px;
    height: 250px;
  }
`;
export const Image2 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 40px;
  position: relative;
  left: 30px;
  @media (max-width: 1000px) {
    width: 400px;
    height: 400px;
  }
  @media (max-width: 500px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 250px;
    height: 250px;
  }
`;
export const SigninContainer = styled.div`
  width: 380px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 40px;
  flex-direction: column;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const LogoContainer = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
`;
export const InputFieldContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 35px;
  flex-direction: column;
  @media (max-width: 400px) {
    align-items: center;
    justify-content: center;
  }
`;
export const InputContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 10px;
  flex-direction: column;
`;
export const Heading = styled.h1`
  width: 380px;
  font-size: 28px;
  font-weight: 700;
  text-align: left;
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Label = styled.label`
  font-family: Inter;
  font-size: 14px;
  font-weight: 400;
  line-height: 16.94px;
  text-align: left;
`;
export const InputField = styled.input`
  width: 350px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid silver;
  padding: 5px 15px;
  font-size: 12px;
  font-weight: 400;
  &:focus {
    outline: none;
  }
  &:active {
    outline: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Button = styled.button`
  width: 380px;
  background-color: #1376f8;
  color: white;
  height: 40px;
  font-size: 18px;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  &:hover {
    background-color: white;
    color: #1376f8;
    border: 1px solid #1376f8;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Text = styled.p`
  font-size: 12px;
  width: 380px;
  font-weight: 500;
  text-align: center;
  display: flex;
  margin: 0%;
  a {
    align-items: center;
    justify-content: center;
    margin: 0%;
    font-size: 12px;
    width: 380px;
    font-weight: 500;
    text-align: center;
    display: flex;
    color: #1376f8;
    text-decoration: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
export const Text1 = styled.p`
  width: 380px;
  margin: 0%;
  border-top: 1px solid silver;
  padding-top: 20px;
  font-size: 12px;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  a {
    color: #1376f8;
    text-decoration: none;
  }
  @media (max-width: 400px) {
    width: 250px;
  }
`;
