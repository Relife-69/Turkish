import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  MainContainer,
  PictureContainer,
  Image1,
  Image2,
  SigninContainer,
  LogoContainer,
  InputFieldContainer,
  Heading,
  Label,
  InputField,
  Button,
  Text,
  Text1,
  InputContainer,
} from "./StyledSignin";
import { Link } from "react-router-dom";
import Pic1 from "../../Components/Images/Background.png";
import Pic2 from "../../Components/Images/Logo.png";

const Signin = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const [msg, setMsg] = useState("");

  const handleLogin = async (event) => {
    event.preventDefault();

    try {
      const user = {
        username,
        password,
      };

      console.log("Submitting user:", user);

      const loginResponse = await axios.post(
        "https://api.appointmentreminder.bot/api/login/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log("API Login Response:", loginResponse.data);

      const token = loginResponse.data.access;
      const companyname = loginResponse.data.company_name;
      const user_name = loginResponse.data.username;
      if (token && companyname && user_name) {
        localStorage.setItem("access-token", token);
        localStorage.setItem("company_name", companyname);
        localStorage.setItem("user_name", user_name);
        setMsg("Login success.");
        alert("Login Successful");
        navigate("/dashhome");
      }
    } catch (error) {
      console.error("Login error:", error);
      setMsg("Login failed. Please try again.");
    }
  };

  return (
    <>
      <MainContainer>
        <PictureContainer>
          <Image1 src={Pic1} />
          <Image2 src={Pic2} />
        </PictureContainer>
        <SigninContainer>
          <LogoContainer src={Pic2} />
          <InputFieldContainer>
            <Heading>Welcome Back!</Heading>
            <InputContainer>
              <Label>Username</Label>
              <InputField
                type="text"
                name="username"
                placeholder="Enter Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <Label>Password</Label>
              <InputField
                type="password"
                name="password"
                placeholder="Enter Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </InputContainer>
            <Button onClick={handleLogin}>Continue</Button>
            <Text>
              <Link to="/forgot-password">Forget Password?</Link>
            </Text>
            <Text1>
              Don’t have an account? <Link to="/signup">Sign up</Link>
            </Text1>
          </InputFieldContainer>
        </SigninContainer>
      </MainContainer>
    </>
  );
};

export default Signin;
