import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import HFrame1 from "../../Components/Frames/HomeFrames/HFrame1";
import HFrame2 from "../../Components/Frames/HomeFrames/HFrame2";
import HFrame3 from "../../Components/Frames/HomeFrames/HFrame3";
import HFrame4 from "../../Components/Frames/HomeFrames/HFrame4";
import HFrame5 from "../../Components/Frames/HomeFrames/HFrame5";

const Home = () => {
  return (
    <>
      <Navbar />
      <HFrame1 />
      <HFrame2 />
      <HFrame3 />
      <HFrame4 />
      <HFrame5 />
      <Footer />
    </>
  );
};

export default Home;
