import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: start;
  padding: 40px 0px;
  justify-content: center;
  gap: 40px;
  flex-wrap: wrap-reverse;
`;

export const PictureContainer = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: start;
  justify-content: end;
`;
export const Image1 = styled.img`
  width: 410px;
  height: 410px;
  border-radius: 50%;
  border: none;
  position: absolute;
`;
export const Image3 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 50px;
  position: relative;
  right: 30px;
`;

export const ContextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  max-width: 700px;
  gap: 30px;
`;

export const Heading = styled.h1`
  font-size: 34px;
  font-weight: 700;
  margin: 0%;
  color: #1376f8;
`;
export const Heading2 = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  color: #023e8a;
`;
export const Description = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
export const FAQContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: center;
  gap: 10px;
  flex-direction: column;
`;
export const SingleFAQ = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  padding: 10px;
  gap: 6px;
  flex-direction: column;
  cursor: pointer;
  border: 1px solid black;
  border-radius: 6px;
`;
export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  width: 680px;
  justify-content: space-between;
`;
export const FAQHeading = styled.h3`
  font-size: 16px;
  font-weight: 500;
  margin: 0%;
`;
export const FAQIcon = styled.div`
  font-size: 18px;
  font-weight: 500;
  margin: 0%;
  color: #1376f8;
`;
export const Answer = styled.p`
  font-size: 14px;
  font-weight: 500;
  margin: 0%;
  display: ${({ showMenu }) => (showMenu ? "flex" : "none")};
`;
