import React, { useState } from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  Answer,
  ContextContainer,
  Description,
  FAQContainer,
  FAQHeading,
  FAQIcon,
  Heading,
  Heading2,
  HeadingContainer,
  Image1,
  Image3,
  MainContainer,
  PictureContainer,
  SingleFAQ,
} from "./StyledFAQ";
import { Link } from "react-router-dom";
import Pic1 from "../../Components/Images/Background.png";
import Pic2 from "../../Components/Images/20.png";
import { MdOutlineArrowDropDown } from "react-icons/md";

const FAQ = () => {
  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <Heading>Frequently Asked Questions</Heading>
          <Heading2>
            Welcome to the Frequently Asked Questions (FAQ) Page!
          </Heading2>
          <Description>
            Here you will find some of the frequently asked questions about our
            services.  However, if you don’t see what you are looking for you
            can <Link to="/contuctus">contact us</Link> here.
          </Description>
          <FAQContainer>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  How do I Sign Up for AppointmentReminders.com
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Can I Use my own Appointment Scheduling Software?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  What types of appointment reminders do you offer?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  What types of payment do you accept and how am I charged?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Can I use my company's branding in my appointment reminders?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Do you offer appointment reminder services outside the United
                  States?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>Do I need to sign a contract?</FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>Do you integrate with smartphones?</FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Can I import my contact list into your appointment reminder
                  service?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Do you provide appointment scheduling software?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>Can I send bulk appointment reminders?</FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>Do you provide a programming API?</FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  What kinds of businesses do you support?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>Are you HIPAA compliant?</FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
            <SingleFAQ onClick={() => toggleMenu("About")}>
              <HeadingContainer>
                <FAQHeading>
                  Where can I Find Pricing for AppointmentReminders.com?
                </FAQHeading>
                <FAQIcon>
                  <MdOutlineArrowDropDown />
                </FAQIcon>
              </HeadingContainer>
              <Answer showMenu={openMenu === "About"}>
                AppointmentReminders.com is an automated cloud based appointment
                reminder service that businesses can use to send reminders to
                customers or patients via SMS (Text Message), email,
                or automated voice calls.
              </Answer>
            </SingleFAQ>
          </FAQContainer>
        </ContextContainer>
        <PictureContainer>
          <Image1 src={Pic1} />
          <Image3 src={Pic2} />
        </PictureContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default FAQ;
