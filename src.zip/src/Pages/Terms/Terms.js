import React from "react";

const Terms = () => {
  return <div>This is Terms And Condition Page</div>;
};

export default Terms;
