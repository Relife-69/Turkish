import React, { useState } from "react";
import {
  MainConatiner,
  Frame,
  Container,
  BlueHeading,
  Frame1,
  ContextCointer,
  BlueHeading1,
  Paragraph,
  Menu,
  List,
  ImageContainer,
  PicBackGroundContainer,
  PicSizeContainer,
  Image,
  Frame2,
  Frame3,
  TextContainer,
  TextContainer1,
  WhiteHeading,
  WhiteParagraph,
  TextContainer2,
  WhiteMenu,
  WhiteList,
  WhiteImage,
  Frame4,
  Frame4Container,
  TextContainer3,
  WhiteList1,
  Frame5,
  Frame5Container,
  Frame6,
  Frame6Container,
  Frame6Image,
  List1,
  BlackHeading,
  InputFields,
  Frame6InputConatiner,
  Frame7,
  InputLabel,
  NameContainer,
  InputContainer,
  InputFields1,
  Button,
} from "./StyledDiscountAccounts";
import Pic from "../../Components/Images/43.png";
import Pic1 from "../../Components/Images/44.png";
import Pic2 from "../../Components/Images/45.png";
import Pic3 from "../../Components/Images/46.png";
import Pic4 from "../../Components/Images/47.png";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import axios from "axios";

const DiscountAccounts = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [organizationName, setOrganizationName] = useState("");
  const [organizationPhone, setOrganizationPhone] = useState("");
  const [organizationAddress, setOrganizationAddress] = useState("");
  const [about, setAbout] = useState("");
  const [comments, setComments] = useState("");
  const [upload_file, setUpload_file] = useState("");
  const [error, setError] = useState(null);
  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    const user = {
      first_name: firstName,
      last_name: lastName,
      email,
      organization_name: organizationName,
      organization_phone: organizationPhone,
      organizatio_address: organizationAddress,
      about: about,
      comments: comments,
    };

    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/submit-mission/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const submitmissionId = result.data.id;
      const formData = new FormData();
      for (let i = 0; i < upload_file.length; i++) {
        formData.append("Upload_File", upload_file[i]);
      }
      await axios.post(
        `https://api.appointmentreminder.bot/api/submit-mission/${submitmissionId}/upload-file/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("Api response:", result.data);
    } catch (error) {
      console.error("Request Error", error);
      setError(error.response ? error.response.data : "Request Error");
    }
  };
  return (
    <>
      <Navbar />
      <MainConatiner>
        <Frame>
          <Container>
            <BlueHeading>
              FREE & DISCOUNTED APPIONTMENT REMINDER FOR NON-PROFITS{" "}
            </BlueHeading>
          </Container>
        </Frame>
        <Frame1>
          <ContextCointer>
            <BlueHeading1>
              Free & Discounted Appointment Reminders for Non-Profits
            </BlueHeading1>
            <Paragraph>
              Our appointment reminders for therapists suits therapists of all
              types. We have independent therapists as well as large,
              multi-location therapy practices.
            </Paragraph>
            <BlueHeading1>Why Free Appointment Reminders?</BlueHeading1>
            <Paragraph>
              Non-profit organizations work to make a difference in the lives of
              others. We understand the challenges you face – juggling
              schedules, managing appointments, and ensuring that every
              opportunity to create positive impact is maximized. That’s why we
              are excited to offer discounted and free appointment reminder
              software specifically for non-profit agencies.
              <Menu>
                <List>Access to our Free Appointment Reminder App</List>
                <List>Free Text Reminders</List>
                <List>Free Call Reminders</List>
                <List>Discounted Google Calendar Reminders</List>
                <List>Discounted EMR Integration</List>
                <List>Discounted File uploads and downloads</List>
              </Menu>
            </Paragraph>
            <Paragraph>
              Our goal is to empower non-profit organizations with the tools
              they need to streamline their operations and focus on what truly
              matters: helping communities thrive. We recognize the unique
              challenges you encounter, and our commitment is to provide a
              reliable and user-friendly solution that ensures no appointment is
              missed, no opportunity is lost, and your valuable time is
              optimized for maximum impact.
            </Paragraph>
          </ContextCointer>
          <ImageContainer>
            <PicSizeContainer>
              <PicBackGroundContainer>
                <Image src={Pic} alt=""></Image>
              </PicBackGroundContainer>
            </PicSizeContainer>
          </ImageContainer>
        </Frame1>
        <Frame2>
          <TextContainer>
            <Paragraph>
              Through our innovative platform, you can access a range of
              features tailored to the specific needs of non-profits. From
              automatic appointment reminders that reduce no-show rates to
              customizable communication options, we are here to support your
              organization in achieving its goals. Our aim is simple – to make
              technology work for you, so you can devote more energy to your
              mission.
            </Paragraph>
          </TextContainer>
        </Frame2>
        <Frame2>
          <TextContainer>
            <Paragraph>
              We offer flexible options to accommodate various organizational
              sizes and needs, ensuring that every non-profit agency, regardless
              of scale, can benefit from enhanced efficiency and impactful
              engagement.
            </Paragraph>
          </TextContainer>
        </Frame2>
        <Frame2>
          <TextContainer>
            <Paragraph>
              It’s an honor to play a role in amplifying your efforts through a
              reliable, accessible, and cost-reduced or free appointment
              reminder app. Together, we can create a world where non-profit
              organizations flourish, communities thrive, and positive change is
              a constant reality.
            </Paragraph>
          </TextContainer>
        </Frame2>
        <Frame3>
          <TextContainer1>
            <WhiteHeading>
              How Do I Qualify For a Free Appointment Reminder Account?
            </WhiteHeading>
            <WhiteParagraph>
              Applying for your discounted or free appointment reminders account
              is straightforward:
            </WhiteParagraph>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteList>
                  Complete the Form Below: Provide us with your non-profit’s
                  name and a brief description of your mission. We’re excited to
                  learn about the incredible work you do!
                </WhiteList>
                <WhiteList>
                  Approval Process: Our team is committed to ensuring that our
                  resources benefit genuine non-profit organizations. We’ll
                  review the information you submit to verify your eligibility.
                </WhiteList>
                <WhiteList>
                  Proof of Non-Profit Status: To expedite the process, kindly
                  include proof of your non-profit status. This can be in the
                  form of official documentation, such as your 501(c)(3)
                  determination letter in the U.S. or equivalent documentation
                  in Canada.
                </WhiteList>
              </WhiteMenu>
              <WhiteParagraph>
                Once approved, your organization will gain access to our 
                discounted or free appointment reminder app, carefully tailored
                to meet the unique needs of non-profits. Seamlessly manage
                appointments, reduce no-shows, and optimize your valuable time –
                all while focusing on your mission to make a difference. 
              </WhiteParagraph>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <WhiteImage src={Pic1} alt=""></WhiteImage>
          </TextContainer2>
        </Frame3>
        <Frame4>
          <Frame4Container>
            <BlueHeading>FREE VS DISCOUNTED ACCOUNTS </BlueHeading>
            <BlueHeading1>Free Appointment Reminders</BlueHeading1>
            <Paragraph>
              Express Accounts for Small Non-Profits: For small non-profit
              agencies that typically send fewer than 100 reminders per month,
              we are thrilled to offer completely free appointment reminders
              utilizing our Express Accounts. These accounts will allow you to
              send up to 100 free text message reminders, free call reminders or
              free email reminders per month. We recognize the importance of
              these reminders in ensuring appointments are honored, and we want
              to ensure that even the smallest non-profits can benefit from our
              services without financial burden.
            </Paragraph>
            <BlueHeading1>Discounted Appointment Reminders</BlueHeading1>
            <Paragraph>
              Discounted Accounts for Larger Organizations: For larger
              non-profit organizations that manage a higher volume of
              appointments, we offer a practical solution that still ensures
              affordability. Our Personal, Small Business, or Premium Accounts,
              which come with an array of advanced features, can be availed at a
              discounted rate. We generally provide a 10% discount on these
              accounts, enabling you to access top-tier services while
              optimizing your budget.
            </Paragraph>
            <Paragraph>
              These measures enable us to continue offering high-quality
              services to non-profits while also covering our operational costs.
              Our commitment remains rooted in empowering you to focus on your
              mission, eliminate appointment no-shows, and make the most of your
              time.
            </Paragraph>
          </Frame4Container>
        </Frame4>
        <Frame3>
          <TextContainer1>
            <WhiteHeading>What is included in the Free Accounts?</WhiteHeading>
            <WhiteParagraph>
              Our Free Express accounts for non-profits include all of the
              following features:
            </WhiteParagraph>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteList1>
                  Up to 100 Free Appointment Reminders Per Month
                </WhiteList1>
                <WhiteList1>Private and Secure</WhiteList1>
                <WhiteList1>Free Text Message Reminders</WhiteList1>
                <WhiteList1>Free Automated Call Reminders</WhiteList1>
                <WhiteList1>Free Email Reminders</WhiteList1>
                <WhiteList1>Record Your Own Voicefiles</WhiteList1>
                <WhiteList1>
                  Access to In-House Voicefile Library w/ 140+ Files
                </WhiteList1>
                <WhiteList1>Email Branding (Logo, Colors, WebURL)</WhiteList1>
                <WhiteList1>
                  Schedule Reminders and Check Results Through our Website
                </WhiteList1>
                <WhiteList1>Free Live Assistance with Account Setup</WhiteList1>
              </WhiteMenu>
              <WhiteParagraph>
                Once approved, your organization will gain access to our 
                discounted or free appointment reminder app, carefully tailored
                to meet the unique needs of non-profits. Seamlessly manage
                appointments, reduce no-shows, and optimize your valuable time –
                all while focusing on your mission to make a difference. 
              </WhiteParagraph>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <WhiteImage src={Pic2} alt=""></WhiteImage>
          </TextContainer2>
        </Frame3>
        <Frame3>
          <TextContainer3>
            <WhiteParagraph>Here’s how it works:</WhiteParagraph>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteList>
                  Under 100 Reminders: If you are a non-profit that sends fewer
                  than 100 appointment reminders per month, you can qualify for
                  our free account tier.
                </WhiteList>
                <WhiteList>
                  Comprehensive Communication Options: Despite being a free
                  account, you’ll have access to our full range of reminder
                  communication methods. This means you can utilize calls, text
                  messages, and emails to ensure your clients, patients, or
                  participants receive timely notifications about their
                  appointments.{" "}
                </WhiteList>
                <WhiteList>
                  Maximize Engagement: Whether it’s a friendly reminder call, a
                  convenient text message, or a professional email, you can
                  customize the type of communication that best suits your
                  audience. This flexibility allows you to engage with your
                  clients on their preferred communication channels.
                </WhiteList>
                <WhiteList>
                  Savings Without Compromise: We understand the value of
                  cost-effective solutions, especially for organizations with
                  lower monthly reminder needs. With our free account, you can
                  enjoy the benefits of our platform without any financial
                  commitment.
                </WhiteList>
                <WhiteList>
                  Upgrade as You Grow: If your needs expand beyond 100 reminders
                  per month, we offer additional packages with additional
                  features at a discounted rate. This way, you can continue
                  benefiting from our platform’s capabilities as your
                  organization evolves.
                </WhiteList>
              </WhiteMenu>
              <WhiteParagraph>
                By offering a free account with access to free call reminders,
                free sms reminders, and free email appointment reminders for
                users with under 100 reminders per month, we aim to empower
                smaller organizations to enhance their appointment management,
                reduce no-show rates, and provide outstanding client
                experiences. It’s all about providing you with the tools you
                need to succeed, while ensuring that our services align with
                your specific usage demands.
              </WhiteParagraph>
            </WhiteParagraph>
          </TextContainer3>
        </Frame3>
        <Frame3>
          <TextContainer1>
            <WhiteHeading>
              What is included in the Discounted Accounts?
            </WhiteHeading>
            <WhiteParagraph>
              Our Discounted Personal and Small Business accounts for
              non-profits include all of the features found in the
              Free Appointment Reminder Accounts with the addition of:
              <WhiteMenu>
                <WhiteList1>Originate Calls from Your Caller ID </WhiteList1>
                <WhiteList1>
                  Upload Excel or CSV Files with Appointment Info
                </WhiteList1>
                <WhiteList1>
                  Link Unlimited Google Calendars (Schedule appointment
                  reminders and check results directly through your calendar)
                </WhiteList1>
                <WhiteList1>Receive Automated Email Reports</WhiteList1>
                <WhiteList1>Access to Custom Voice Recordings</WhiteList1>
              </WhiteMenu>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <WhiteImage src={Pic3} alt=""></WhiteImage>
          </TextContainer2>
        </Frame3>
        <Frame5>
          <Frame5Container>
            <WhiteParagraph>
              Our Discounted Premium Accounts also include the following:
              <WhiteMenu>
                <WhiteList1>Optional HIPAA Compliance</WhiteList1>
                <WhiteList1>
                  Access to our Programming API to upload and download files
                  automatically
                </WhiteList1>
                <WhiteList1>
                  Optional Integration Service (*May have additional charge) to
                  fully integrate your reminders
                </WhiteList1>
              </WhiteMenu>
            </WhiteParagraph>
          </Frame5Container>
        </Frame5>
        <Frame5>
          <Frame5Container>
            {" "}
            <WhiteParagraph>Here’s how it works:</WhiteParagraph>
            <WhiteMenu>
              <WhiteList>
                Over 100 Reminders Per Month: If you are a non-profit that sends
                more than 100 appointment reminders per month, you can qualify
                for one of our higher account tiers at a discounted rate.
              </WhiteList>
              <WhiteList>
                Comprehensive Communication Options: You’ll have access to our
                full range of reminder communication methods. This means you can
                utilize calls, text messages, and emails to ensure your clients,
                patients, or participants receive timely notifications about
                their appointments.
              </WhiteList>
              <WhiteList>
                Maximize Engagement: Whether it’s a automated reminder call, a
                text message reminder, or an email, you can customize the type
                of communication that best suits your audience. This flexibility
                allows you to engage with your clients on their preferred
                communication channels.
              </WhiteList>
              <WhiteList>
                Savings Without Compromise: We understand the value of
                cost-effective solutions, especially for organizations with
                lower monthly reminder needs. With our free account, you can
                enjoy the benefits of our platform without any financial
                commitment.
              </WhiteList>
            </WhiteMenu>
          </Frame5Container>
        </Frame5>
        <Frame6>
          <Frame6Container>
            <BlueHeading>HOW DO I GET STARTED?</BlueHeading>
            <Frame6Image src={Pic4} alt=""></Frame6Image>
          </Frame6Container>
          <Frame5Container>
            <Paragraph>
              For non-profit agencies seeking to harness the benefits of
              AppointmentReminders.com, we have a tailored process in place to
              accommodate your status and needs. Here’s how it works:
            </Paragraph>
            <Paragraph>Non-Profit Partnership Process:</Paragraph>
            <Menu>
              <List1>
                Submit Your Information: As a non-profit agency, you can begin
                the process by submitting a form to us. This form will help us
                understand your needs and how we can best support your efforts.
              </List1>
              <List1>
                Certificate of Non-Profit Status: To verify your non-profit
                status, we request that you provide us with a copy of your
                official certificate or documentation confirming your agency’s
                non-profit status. This ensures that we can appropriately tailor
                our support to organizations that are dedicated to making a
                positive impact.
              </List1>
              <List1>
                Review and Evaluation: Once we receive your form and certificate
                of non-profit status, our team will review the information
                provided. We take this step to ensure that we understand your
                unique requirements and can tailor our collaboration to align
                with your goals.
              </List1>
              <List1>
                Personalized Assistance: Our team will evaluate how our services
                can best assist your non-profit agency in achieving its mission.
                We’ll assess your needs, the scale of your operations, and the
                ways in which our platform can be integrated to streamline your
                appointment communications. We can also help you determine
                whether a free appointment reminders account or a discounted one
                is best suited for your needs.
              </List1>
              <List1>
                Communication and Support: Following our review, we’ll reach out
                to you to let you know if you qualify and to help you get
                started.
              </List1>
            </Menu>
            <Paragraph>
              By engaging in this process for non-profit agencies, we ensure
              that our collaboration is meaningful, effective, and aligned with
              your mission. We value the contributions of non-profit
              organizations in making the world a better place, and we’re
              committed to playing our part by supporting your endeavors.
              Through this process, we aim to create a partnership that fosters
              efficiency, compassion, and positive change.
            </Paragraph>
            <Paragraph>
              At AppointmentReminders.com, we recognize the importance of your
              non-profit status and the exceptional work you do. By submitting
              the necessary information and your certificate of non-profit
              status, we can begin a journey of collaboration that harnesses the
              power of technology to amplify your impact. We eagerly await the
              opportunity to work hand-in-hand with you to achieve your
              organization’s goals.
            </Paragraph>
          </Frame5Container>
        </Frame6>
        <Frame6>
          <Frame6Container>
            <BlueHeading>Tell Us About Your Mission!</BlueHeading>
            <BlackHeading>
              Please Fill Out This Form to Get Started!
            </BlackHeading>
          </Frame6Container>
        </Frame6>
        <Frame7>
          <Frame6InputConatiner>
            <NameContainer>
              <InputLabel>First Name</InputLabel>
              <InputFields
                required
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="Enter Here"
              ></InputFields>
            </NameContainer>

            <NameContainer>
              <InputLabel>Last Name</InputLabel>
              <InputFields
                required
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Enter Here"
              ></InputFields>
            </NameContainer>
          </Frame6InputConatiner>
          <InputContainer>
            <InputLabel>E-mail</InputLabel>
            <InputFields1
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>Phone no</InputLabel>
            <InputFields1
              required
              type="tel"
              value={organizationPhone}
              onChange={(e) => setOrganizationPhone(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>Organization Name</InputLabel>
            <InputFields1
              required
              type="text"
              value={organizationName}
              onChange={(e) => setOrganizationName(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>Organization Location</InputLabel>
            <InputFields1
              required
              type="text"
              value={organizationAddress}
              onChange={(e) => setOrganizationAddress(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>About Your Organization</InputLabel>
            <InputFields1
              required
              type="text"
              value={about}
              onChange={(e) => setAbout(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>Additional Comments or Questions</InputLabel>
            <InputFields1
              required
              type="text"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Enter Here"
            ></InputFields1>
          </InputContainer>
          <InputContainer>
            <InputLabel>Non-Profit Certification</InputLabel>
            <InputFields1
              type="file"
              required
              value={upload_file}
              onChange={(e) => setUpload_file(e.target.value)}
            ></InputFields1>
          </InputContainer>

          <Button onClick={handleSubmit}>Send</Button>
        </Frame7>
      </MainConatiner>
      <Footer />
    </>
  );
};

export default DiscountAccounts;
