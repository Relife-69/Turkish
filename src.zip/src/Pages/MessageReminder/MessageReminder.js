import React from "react";
import {
  MainConatiner,
  BlueHeading,
  Section1,
  ContextCointer,
  BlueHeading1,
  Paragraph,
  ImageContainer,
  PicSizeContainer,
  PicBackGroundContainer,
  Image,
  Menu,
  ListDot,
  Section2,
  TextContainer,
  Section3,
  TextContainer1,
  WhiteHeading1,
  WhiteHeading,
  WhiteParagraph,
  TextContainer2,
  WhiteImage,
  Section4,
  Section4Container1,
  PicWhiteSizeContainer,
  PicWhiteBackGroundContainer,
  WhiteImage1,
  WhiteListDot,
  TextImage,
  TextContainer4,
} from "./StyledMessageReminder";
import Pic from "../../Components/Images/4.png";
import Pic1 from "../../Components/Images/4.png";
import Pic2 from "../../Components/Images/4.png";
import Pic3 from "../../Components/Images/4.png";
import Pic4 from "../../Components/Images/4.png";
import Pic5 from "../../Components/Images/4.png";
import Pic6 from "../../Components/Images/4.png";
import Pic7 from "../../Components/Images/4.png";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";

const MessageReminder = () => {
  return (
    <>
      <Navbar />
      <MainConatiner>
        <Section1>
          <ContextCointer>
            <BlueHeading>TEXT REMINDERS</BlueHeading>
            <BlueHeading1>What are Text (SMS) Reminders?</BlueHeading1>
            <BlueHeading1>Text Messages or SMS Technology</BlueHeading1>
            <Paragraph>
              The first text message was sent on December 3, 1992. It was sent
              by Neil Papworth, a software programmer, who transmitted the
              message from his computer to Richard Jarvis, an executive at
              Vodafone, on a bulky Orbitel 901 mobile phone. The message simply
              read “Merry Christmas.” This event marked the beginning of what
              would become a global phenomenon, fundamentally changing the way
              people communicate.
            </Paragraph>
            <Paragraph>
              To this day it remains one of the most popular, efficient, and
              preferred methods of communication.
            </Paragraph>
            <BlueHeading1>Text Message Statistics</BlueHeading1>
            <Paragraph>
              Text reminders, also known as text message reminders,
              or SMS reminders, are one of the most efficient ways to remind
              your customers of their appointments.
            </Paragraph>
            <Paragraph>
              <Menu>
                <ListDot>
                  Consumer Preferences for Business Texts: Most consumers prefer
                  receiving texts from businesses once every other week, with a
                  significant portion open to texts from 4-6 businesses. The
                  industries leading in SMS contacts are e-commerce/retail and
                  healthcare​​.
                </ListDot>
              </Menu>
            </Paragraph>
          </ContextCointer>

          <ImageContainer>
            <PicSizeContainer>
              <PicBackGroundContainer>
                {<Image src={Pic} alt=""></Image>}
              </PicBackGroundContainer>
            </PicSizeContainer>
          </ImageContainer>
        </Section1>

        <Section2>
          <TextContainer>
            <Paragraph>
              <Menu>
                <ListDot>
                  Global Texting Trends: Nearly six billion people worldwide are
                  expected to send and receive text messages by 2025,
                  highlighting the continued growth of SMS as a key
                  communication channel. Furthermore, 90% of customers prefer
                  text messages over phone calls for communication​​.
                </ListDot>
                <ListDot>
                  Texting Engagement: Text messages boast a 98% open rate, and
                  85% of people check a text within 5 minutes of receiving it.
                  This high engagement rate makes SMS marketing highly
                  attractive for businesses across different industries​​.
                </ListDot>
                <ListDot>
                  SMS Marketing Effectiveness: Text message marketing is one of
                  the top mobile marketing tactics, with 53% of marketers
                  currently utilizing mobile messaging. Texting is preferred for
                  various interactions, including scheduling, customer support,
                  and marketing, with an average person sending about 13 SMS
                  messages per day​​.
                </ListDot>
                <ListDot>
                  SMS Marketing Statistics: Appointment reminders are considered
                  the most valuable texts received from businesses.
                  Additionally, the average clickthrough rate (CTR) for SMS
                  marketing efforts is reported at 19.3%, significantly higher
                  than other marketing channels​​.
                </ListDot>
              </Menu>
            </Paragraph>
            <BlueHeading1>160 Character Limit?</BlueHeading1>
            <Paragraph>
              The standard length of a text message (SMS) is up to 160
              characters, including spaces and punctuation. This limitation was
              set due to the constraints of early mobile network protocols and
              has remained a standard for compatibility and simplicity across
              mobile networks globally.
            </Paragraph>
            <Paragraph>
              However, most modern cell phones and mobile network operators
              support concatenated SMS, allowing longer messages to be sent in
              multiple parts but appear as a single message to the recipient.
              When a message exceeds 160 characters, it is split into multiple
              segments, each up to 160 characters long, and reassembled upon
              arrival. 
            </Paragraph>
            <Paragraph>
              Most appointment reminder
              companies (including appointmentreminders.com count each segment
              separately for billing purposes, depending on the carrier’s
              policy.
            </Paragraph>
          </TextContainer>
        </Section2>

        <Section3>
          <TextContainer1>
            <WhiteHeading>When to use Text Reminders</WhiteHeading>
            <WhiteHeading1>Best Use Case for Text Reminders</WhiteHeading1>
            <WhiteParagraph>
              In some cases reminder calls are simply the best choice based on
              the demographic and the type of appointment it is. For example, if
              you are reminding someone of a specialized procedure with lots of
              specific instructions, it just makes more sense to put that in a
              call (or maybe an email reminder)  rather than a text
              message. Text message reminders are excellent for short messages
              with just basic information. Also, if you are attempting to reach
              an older demographic, many times a call may be a better choice
              simply because many people either prefer calls, or do not have
              texting capabilities.
            </WhiteParagraph>
            <WhiteParagraph>
              You will need to consider your specific use-case when deciding
              whether to use call reminders. As for which outreach method is
              more effective in reducing no shows, our experience as well
              as study data on texts vs calls show that they have very similar
              outcomes.
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <WhiteImage src={Pic1} alt=""></WhiteImage>
          </TextContainer2>
        </Section3>

        <Section4>
          <Section4Container1>
            <BlueHeading>
              SENDING TEXT MESSAGE (SMS) REMINDERS WITH
              APPOINTMENTREMENDIERS.COM
            </BlueHeading>
            <Paragraph>
              <Menu>
                <ListDot>
                  AppointmentReminders.com specializes in sending text message
                  appointment reminders! 
                </ListDot>
              </Menu>
              <Menu>
                <ListDot>
                  When you send text message reminders with us, you can expect
                  all of these features and more! 
                </ListDot>
              </Menu>
              <menu>
                <ListDot>
                  Personalization: Ability to customize messages with client
                  names, appointment details, and other personal information.
                </ListDot>
                <ListDot>
                  Scheduling: Options to schedule reminders in advance based on
                  appointment dates and times.
                </ListDot>
                <ListDot>
                  Two-Way Messaging: Capability for recipients to reply to
                  messages for confirmations, cancellations, or rescheduling.
                </ListDot>
                <ListDot>
                  Extended Text Conversations: Reply back to a reminder to
                  continue the conversation directly through our interface.
                </ListDot>
                <ListDot>
                  Multiple Reminders: Options to send multiple
                  reminders (including email and call) for an appointment.
                </ListDot>
                <ListDot>
                  Integration: Ability to integrate with Google
                  Calendar and other scheduling software to automate the
                  reminder process.
                </ListDot>
                <ListDot>
                  Compliance: Adherence to legal requirements and industry
                  standards for text messaging and privacy.
                </ListDot>
                <ListDot>
                  Reporting and Analytics: Tools to track message delivery,
                  responses, and engagement metrics.
                </ListDot>
                <ListDot>
                  Customizable Templates: Pre-built and customizable message
                  templates for various types of appointments and industries.
                </ListDot>
                <ListDot>
                  Language Options: Support for English & Spanish to accommodate
                  diverse client bases.
                </ListDot>
                <ListDot>
                  Group Messages: Capability to send blast reminders to groups &
                  distribution lists useful for events or group appointments.
                </ListDot>
                <ListDot>
                  Customizable Frequency: Ability to set how often reminders are
                  sent (e.g., a week before, a day before, an hour before).
                </ListDot>
                <ListDot>
                  Opt-Out Management: Automated handling of opt-out requests to
                  ensure compliance with messaging regulations.
                </ListDot>
                <ListDot>
                  Mobile Optimization: Ensuring messages are optimized for
                  display on mobile devices.
                </ListDot>
                <ListDot>
                  Confirmation Tracking: Ability to track and record responses
                  such as confirmations, cancellations, or requests to
                  reschedule.
                </ListDot>
                <ListDot>
                  Automated Follow-ups: Sending follow-up messages
                  post-appointment for feedback or next steps.
                </ListDot>
                <ListDot>
                  Data Security: Ensuring that personal information is securely
                  handled and stored.
                </ListDot>
                <ListDot>
                  User-Friendly Dashboard: A dashboard for managing
                  appointments, messages, and analytics in one place.
                </ListDot>
                <ListDot>
                  Appointment History: Ability to view past appointment
                  reminders and responses for each client.
                </ListDot>
                <ListDot>
                  Dynamic Fields: Use of dynamic fields in messages that
                  automatically fill with specific data (like appointment date,
                  time, doctor’s name).
                </ListDot>
                <ListDot>
                  Feedback Collection: Integrating a way to collect feedback on
                  services post-appointment through the reminder system.
                </ListDot>
              </menu>
            </Paragraph>
          </Section4Container1>
        </Section4>

        <Section3>
          <TextContainer1>
            <WhiteHeading>
              Customize your Text Message Appointment Reminders
            </WhiteHeading>
            <WhiteParagraph>
              Completely Customize Your Text Reminders!
            </WhiteParagraph>
            <WhiteParagraph>
              <Menu>
                <WhiteListDot>
                  Open Text Fields: Create your own custom blocks of text to add
                  to your text reminders.
                </WhiteListDot>
                <WhiteListDot>
                  Dynamic Fields: These are things like appointment date,
                  appointment time, patients name, company name, phone number,
                  and address. Add them to your reminder where and when you need
                  them.
                </WhiteListDot>
                <WhiteListDot>
                  Custom Content: Add custom content specific to each reminder.
                </WhiteListDot>
                <WhiteListDot>
                  Appointment Windows: For companies that offer windows instead
                  of appointment times.
                </WhiteListDot>
                <WhiteListDot>
                  Different Text for Different Appointment Types: you can have
                  several different templates (or reminder types) that you can
                  use to send out reminders. In this way, you can send different
                  messages for different locations, or different appointment
                  types. There is no limit to the number of Reminder Types that
                  you can have.
                </WhiteListDot>
                <WhiteListDot>
                  Automatic Scheduling: Our system also allows you to decide
                  when to send your text reminders. You can automatically
                  schedule them to go out a couple days before the appointment
                  (days are configurable).  
                </WhiteListDot>
                <WhiteListDot>
                  Multiple Reminders: You can also set up triggers to send
                  multiple reminders  (maybe one a week before and another a day
                  before). Or send different follow-up reminders based on
                  certain responses to the initial reminder.
                </WhiteListDot>
              </Menu>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic2} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
        </Section3>

        <Section3>
          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic3} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
          <TextContainer1>
            <WhiteHeading>
              Roll Failed Texts to Calls Automatically
            </WhiteHeading>
            <WhiteParagraph>
              You can set up your text message reminders to automatically roll
              to calls if they fail due to a non-mobile number or some other
              reason. It is also very simple and easy to set up call reminders
              that play the same information as the text message reminder. Any
              info or fields that you pass into one reminder type will
              automatically flow through to the next.
            </WhiteParagraph>
          </TextContainer1>
        </Section3>

        <Section3>
          <TextContainer1>
            <WhiteHeading>Easily Find Failed Text Reminders</WhiteHeading>
            <WhiteParagraph>
              You will be able to see which phone numbers were able to receive
              an SMS and which failed.  
            </WhiteParagraph>
            <WhiteParagraph>
              This way you can follow up with your customers to update their
              phone records in the future. 
            </WhiteParagraph>
            <WhiteParagraph>
              In addition, you can download the results to a csv file which you
              can open in excel. 
            </WhiteParagraph>
            <WhiteParagraph>
              Sort them by “delivery status” and further streamline your
              delivery methods.
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic5} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
        </Section3>

        <Section3>
          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic4} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
          <TextContainer1>
            <WhiteHeading>No Charge for Failed Text Reminders</WhiteHeading>
            <WhiteParagraph>
              You will never pay for failed reminders. Failed reminders are
              common. Especially text reminders. You will often find home phone
              numbers or non-cell numbers in your customer database.  
            </WhiteParagraph>
            <WhiteParagraph>
              In this case, you will not be able to send them an SMS message and
              must communicate with them another way. {" "}
            </WhiteParagraph>
            <WhiteParagraph>
              Our system makes it very easy to roll them over to a reminder
              call or a reminder email. You only get charged for the reminders
              that were sent successfully.  
            </WhiteParagraph>
            <WhiteParagraph>
              This way you can set up your account to send a text first to all
              your customers (regardless of what type of phone numbers you
              have), and then choose an alternative secondary method.
            </WhiteParagraph>
          </TextContainer1>
        </Section3>

        <Section3>
          <TextContainer1>
            <WhiteHeading>
              Allow People to Reply to Your Text Message Reminders
            </WhiteHeading>
            <WhiteParagraph>
              Allow your patients or customers to confirm the appointment by
              replying back with a digit or keyword! In fact, we allow you to
              add up to 3 reply digits or keywords to each reminder. 
            </WhiteParagraph>
            <WhiteParagraph>
              For example, a typical scenario may be where you would allow your
              customer to either “confirm”, “cancel”, or “reschedule” the
              appointment by replying with 1,2, or 3 to the text reminder. 
            </WhiteParagraph>
            <WhiteParagraph>
              Which keywords you choose is entirely up to you.  You may want
              them to text back a word such as “confirm” or perhaps “C”. Maybe
              you do not want to include the ability to reply at all. With our
              text reminders, you can include whichever replies are necessary
              for your specific case.
            </WhiteParagraph>
            <WhiteParagraph>
              In addition, you can send another text message to your customer
              automatically after they reply.
            </WhiteParagraph>
            <WhiteParagraph>
              Take the following automated conversation as an example:
            </WhiteParagraph>
            <WhiteParagraph>
              “Hi Joe, you have an upcoming appointment with Sun Prairie Dental
              on Saturday, July 5th, at 10:00 AM. Please reply “C” to confirm
              this appointment.
            </WhiteParagraph>
            <WhiteParagraph>"C"</WhiteParagraph>
            <WhiteParagraph>
              “Thank you! Your appointment has been confirmed. We look forward
              to seeing you!”
            </WhiteParagraph>
            <WhiteParagraph>
              This is just an example.  You can text back any message you want
              after they reply to your reminders.
            </WhiteParagraph>
            <WhiteParagraph></WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic5} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
        </Section3>

        <Section3>
          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic4} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
          <TextContainer1>
            <WhiteHeading>
              Check Replies to your Text Reminders or Respond in Real-Time
            </WhiteHeading>
            <WhiteParagraph>
              You will be able to see replies to your text reminders immediately
              in the “Reminders” screen.  You can also go in and text back in
              real time if you need to.  
            </WhiteParagraph>
            <TextImage src={Pic6} alt=""></TextImage>
          </TextContainer1>
        </Section3>

        <Section3>
          <TextContainer1>
            <WhiteHeading>
              Detailed Reporting on Your Text Reminders
            </WhiteHeading>
            <WhiteParagraph>
              You can also set up reports that will email you the results
              nightly or download them into a csv file directly from the
              interface. 
            </WhiteParagraph>
            <WhiteParagraph>
              This allows you to follow up with any patients or customers who
              either have questions about the appointment or need to cancel or
              reschedule. 
            </WhiteParagraph>
            <TextImage src={Pic7} alt=""></TextImage>
          </TextContainer1>

          <TextContainer4>
            <WhiteHeading>Send Alerts to Your Phone or Email</WhiteHeading>
            <WhiteParagraph>
              You can also add alerts or “Triggers” that can notify you via text
              or email when someone responds a certain way to your text
              reminders.
            </WhiteParagraph>
            <WhiteParagraph>
              For example, you could set up a trigger so that if someone cancels
              an appointment, it will notify you immediately via text message.
              This way you can follow up almost immediately without needing to
              log in and check the replies.
            </WhiteParagraph>
            <WhiteParagraph>
              Alternatively, you can have alerts sent to a shared email box, or
              a distribution list.  That way, whoever is monitoring the email
              can follow up almost immediately with your customers!
            </WhiteParagraph>
          </TextContainer4>
        </Section3>
      </MainConatiner>
      <Footer />
    </>
  );
};

export default MessageReminder;
