import styled from "styled-components";

export const MainConatiner = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  padding: 50px 0px;
`;
export const Section = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
`;
export const Container = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 800px;
`;
export const BlueHeading = styled.h1`
  font-size: 34px;
  color: #1376f8;
  align-items: center;
  font-weight: 700;
`;
export const Section1 = styled.div`
  display: flex;
  align-items: center;
  width: 80%;
`;
export const ContextCointer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 800px;
`;
export const BlueHeading1 = styled.h3`
  font-size: 23px;
  color: #023e8a;
  align-items: center;
  font-weight: 700;
`;
export const Paragraph = styled.p`
  font-size: 20px;
  align-items: center;
  font-weight: 400;
  margin: 0%;
`;
export const ImageContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 800px;
`;
export const PicSizeContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 800px;
  margin-bottom: 100px;
  justify-content: end;
  align-items: end;
`;
export const PicBackGroundContainer = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 650px;
  height: 650px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Image = styled.img`
  width: 700px;
  height: 700px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Menu = styled.ul`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
`;
export const ListDot = styled.li`
  font-size: 20px;
  align-items: center;
  font-weight: 400;
`;
export const Section2 = styled.div`
  display: flex;
  width: 80%;
`;
export const TextContainer = styled.div`
  align-items: start;
  justify-content: start;
  width: 80%;
`;

export const Section3 = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #1376f8;
  width: 100%;
  gap: 100px;
`;
export const TextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 50%;
  margin: 1%;
  flex-direction: column;
`;
export const WhiteHeading = styled.h1`
  font-size: 34px;
  color: white;
  font-weight: 700;
`;
export const TextContainer2 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  width: 500px;
  margin: 1%;
`;
export const WhiteParagraph = styled.p`
  font-size: 20px;
  align-items: center;
  font-weight: 400;
  color: white;
`;
export const WhiteMenu = styled.ul`
  font-size: 14px;
  font-weight: 500;
`;
export const WhiteList = styled.li`
  font-size: 20px;
  align-items: center;
  font-weight: 400;
  list-style: decimal;
  color: white;
`;
export const WhiteImage = styled.img`
  width: 450px;
  height: 450px;
  border: none;
`;
export const WhiteHeading1 = styled.h4`
  font-size: 34px;
  color: white;
  font-weight: 700;
`;
export const Section4 = styled.div`
  display: flex;
  justify-content: start;
  align-items: start;
  margin: 60px;
  width: 80%;
`;
export const Section4Container1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 80%;
`;
export const PicWhiteBackGroundContainer = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 410px;
  height: 410px;
  background-color: white;
  border-radius: 50%;
`;
export const PicWhiteSizeContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 450px;
  height: 450px;
  margin-bottom: 100px;
  justify-content: end;
  align-items: end;
`;
export const WhiteImage1 = styled.img`
  width: 450px;
  height: 450px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const WhiteListDot = styled.li`
  font-size: 20px;
  align-items: center;
  font-weight: 400;
  color: white;
`;
export const TextImage = styled.img`
  width: 767px;
  height: 215px;
  border: none;
  position: relative;
`;
export const TextContainer4 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: start;
  width: 500px;
  margin: 1%;
`;
