import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  ContextContainer,
  ContextContainer1,
  ContextContainer2,
  ContextContainer3,
  Description,
  Description1,
  Heading,
  Heading1,
  Heading2,
  Image1,
  Image2,
  List,
  List1,
  MainContainer,
  MainContainer1,
  MenuContainer,
  PictureContainer,
  TextContainer,
  TextContainer1,
  TextContainer2,
} from "./StyledEmialReminder";
import Back from "../../Components/Images/Background.png";
import Back1 from "../../Components/Images/Background1.png";
import Pic from "../../Components/Images/38.png";
import Pic1 from "../../Components/Images/39.png";
import Pic2 from "../../Components/Images/40.png";
import Pic3 from "../../Components/Images/41.png";
import Pic4 from "../../Components/Images/42.png";

const EmailReminder = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <TextContainer>
            <Heading>Email Appointment Reminders</Heading>
            <Heading1>What are Email Reminders?</Heading1>
            <Heading1>Why Email Reminders?</Heading1>
            <TextContainer1>
              <Description>
                Sending email reminders over text reminders or call
                reminders offers several advantages in certain contexts:
              </Description>
              <MenuContainer>
                <List>
                  Detailed Information: Email allows for the inclusion of
                  detailed information, attachments, and links. This can be
                  beneficial when the reminder contains complex details,
                  instructions, or additional resources that are better conveyed
                  through text and visuals.
                </List>
                <List>
                  Professionalism: Email appointment reminders are often
                  perceived as more formal and professional compared to text
                  message reminders. This can be important in business or
                  professional settings where a more formal tone is preferred.
                </List>
                <List>
                  Less Intrusive: While both email reminders and text message
                  reminders are non-intrusive compared to phone call reminders,
                  a reminder email may be perceived as less urgent, allowing
                  recipients to check and respond at their convenience without
                  feeling pressured to respond immediately.
                </List>
                <List>
                  Cross-Platform Accessibility: Emails can be accessed on a
                  variety of devices, including smartphones, tablets, and
                  computers. This cross-platform accessibility ensures that
                  recipients can view reminders regardless of the device they
                  are using.
                </List>
                <List>
                  Customization: Email reminders allow for greater customization
                  and personalization through the use of personalized greetings,
                  tailored content, and specific details relevant to the
                  recipient. This personal touch can enhance engagement.
                </List>
                <List>
                  Easier Forwarding and Sharing: Email reminders can be easily
                  forwarded and shared with others, making it simple for
                  recipients to pass along important information to colleagues,
                  friends, or family members.
                </List>
              </MenuContainer>
            </TextContainer1>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer1>
          <Heading1>Part of a Larger Strategy</Heading1>
          <TextContainer1>
            <Description>
              Sending email reminders is a key component of a comprehensive
              reminder strategy that encompasses multiple communication channels
              to maximize reach and effectiveness. 
            </Description>
            <Description>
              The goal is to ensure that recipients are adequately reminded of
              their appointments, obligations, or events in a manner that is
              most likely to prompt action or attendance. Here’s how email
              reminders fit into a larger reminder strategy:
            </Description>
            <MenuContainer>
              <List>
                Multi-Channel Communication: A robust reminder strategy
                leverages multiple communication channels to cater to different
                preferences and ensure messages are received. Alongside email
                reminders, businesses often use SMS/text messages, phone calls,
                and even postal mail for reminders. This multi-channel approach
                ensures that if one method fails to catch the recipient’s
                attention, another method might succeed.
              </List>
              <List>
                Rolling failed text reminders seamlessly to call or email
                reminders ensures that all of your customers or patients will
                have a much greater chance of receiving the reminders.
              </List>
              <List>
                A survey of nearly 14,000 patients revealed that while 48% of
                respondents prefer text message reminders for appointments, 21%
                still prefer email reminders, and 29% prefer phone calls. This
                preference for text message reminders spans across various age
                groups, indicating a general trend towards digital communication
                methods, although a significant portion of the population still
                values the benefits that email reminders provide.
              </List>
            </MenuContainer>
          </TextContainer1>
        </ContextContainer1>
        <ContextContainer1>
          <Heading>
            Sending Email Reminders With AppointmentReminders.com
          </Heading>
          <Description>
            AppointmentReminders.com specializes in sending email appointment
            reminders! 
          </Description>
          <Description>
            When you send email reminders with us, you can expect all of these
            features and more!
          </Description>
          <MenuContainer>
            <List>
              Automated Scheduling: Automatically send reminders based on
              predefined schedules.
            </List>
            <List>
              Personalization: Customize emails with recipient’s name,
              appointment details, and more.
            </List>
            <List>
              Customizable Templates: Ready-to-use and editable email
              templates for various reminder needs.
            </List>
            <List>
              Google Calendar Integration: Link your Google Calendar and
              automatically send reminders.
            </List>
            <List>
              Integration with Calendars: Allow recipients to add appointments
              to their personal calendars directly from the email.
            </List>
            <List>
              Multiple Reminders: Capability to send more than one reminder,
              such as a week before and then a day before the event.
            </List>
            <List>
              Link Support: Ability to include links with reminders for
              additional information.
            </List>
            <List>
              Analytics and Reporting: Insights on delivery rates and overall
              engagement with the reminders.
            </List>
            <List>
              Blast Emails: Manage and segment email lists to target specific
              groups or distribution lists.
            </List>
            <List>
              Global Reach: No restrictions on international emails, allowing
              for global communication without additional costs.
            </List>
            <List>
              Responsive Design: Emails optimized for viewing on both desktop
              and mobile devices.
            </List>
            <List>
              Security and Compliance: Ensure privacy and compliance with data
              protection regulations.
            </List>
            <List>
              Reply Management: Collect and manage responses directly through
              the service.
            </List>
            <List>
              Unsubscribe Options: Allow recipients to easily opt-out of
              receiving future reminders to comply with email marketing laws.
            </List>
            <List>
              Branding Options: Customize emails with your organization’s logo,
              colors, and branding.
            </List>
            <List>
              Scalability: Ability to handle large volumes of emails without
              degradation in performance.
            </List>
            <List>
              Failover Mechanisms: Options to send reminders through alternative
              channels (e.g., SMS) if the email fails.
            </List>
            <List>
              Easy to Use Interface: A user-friendly dashboard for creating,
              scheduling, and managing email reminders.
            </List>
          </MenuContainer>
        </ContextContainer1>
      </MainContainer>
      <ContextContainer2>
        <ContextContainer>
          <TextContainer>
            <Heading2>Customize your Email Reminders</Heading2>
            <TextContainer1>
              <Description1>With our email reminders, you can:</Description1>
              <MenuContainer>
                <List1>
                  Include your logo, branding colors, and more. Customize the
                  look and feel of your email reminders by adding a border and
                  your logo. This ensures that the email looks authentic and
                  professional.
                </List1>
                <List1>
                  Add up to 3 customizable buttons to your email reminders, such
                  as “confirm”, “cancel”, “reschedule”.
                </List1>
                <List1>
                  Our email reminders allow you to include all of you own
                  content as well as custom fields such as appointment date &
                  time, customer name, company name, address, and phone number.
                </List1>
                <List1>
                  Schedule your reminder emails to go out on your schedule (e.g.
                  Day before appt, week before appt, etc…)
                </List1>
                <List1>
                  See replies to email reminders in real-time through our online
                  reporting screen.
                </List1>
              </MenuContainer>
            </TextContainer1>
            <TextContainer1>
              <Description1>
                Not only does this increase your brand recognition, but it also
                adds to the customer experience by looking more professional and
                authentic.
              </Description1>
              <Description1>
                Your patients or customers will feel confident that the email
                reminder is originating from your office and will be more likely
                to open it and reply to it.
              </Description1>
            </TextContainer1>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Back1} />
            <Image2 src={Pic2} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer>
          <PictureContainer>
            <Image1 src={Back1} />
            <Image2 src={Pic1} />
          </PictureContainer>
          <TextContainer>
            <Heading2>
              Send your Email Reminder at the appropriate time
            </Heading2>
            <TextContainer1>
              <Description1>
                Our email reminders allow you to schedule them at the
                appropriate time or trigger them to be sent multiple times. You
                can also trigger them when an event happens such as a text
                message failure or call failure.
              </Description1>
              <Description1>
                For example, you can send an email reminder a week ahead of the
                appointment and then another on the day before the appointment. 
                You can also change the email reminder content based on the
                customer or patients reply to the initial reminder.  
              </Description1>
              <Description1>
                Say the customer or patient confirms the appointment using the
                reminder you send out one week prior. In this case, you may want
                to just give them a friendly reminder the day before, rather
                than asking for another confirmation.
              </Description1>
            </TextContainer1>
          </TextContainer>
        </ContextContainer>
        <ContextContainer>
          <TextContainer>
            <Heading2>Keeping out of the Spam Folder</Heading2>
            <TextContainer1>
              <Description1>
                Our email reminders are sent using the latest technology in
                order to keep them out of the Spam folder and in your customers
                inbox.
              </Description1>
              <Description1>
                We follow all standard protocols and guidelines when sending
                email reminders including a verified domain name and DNS.
              </Description1>
              <Description1>We also comply with the CAN-SPAM ACT.</Description1>
            </TextContainer1>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Back1} />
            <Image2 src={Pic4} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer>
          <PictureContainer>
            <Image1 src={Back1} />
            <Image2 src={Pic3} />
          </PictureContainer>
          <TextContainer>
            <Heading2>Universal Formatting</Heading2>
            <Description1>
              To ensure a high-rate of delivery, our email reminders are
              formatted to look good in most email client programs and mobile
              devices. As well, we always include an option to view the reminder
              in a web browser. This ensures a high-rate of customer
              satisfaction.
            </Description1>
          </TextContainer>
        </ContextContainer>
      </ContextContainer2>
      <MainContainer>
        <ContextContainer1>
          <Heading>Appointment Reminder Email Templates</Heading>
          <Description>
            By using different styles of email reminders, you can optimize the
            effectiveness of your communication and enhance the chances of the
            recipients taking the desired actions. Consider the following when
            crafting your reminder email:
          </Description>
          <MenuContainer>
            <List>
              Nature of the Message: The content of the email reminder may
              dictate the appropriate style. For instance, a formal and
              professional tone may be suitable for business-related reminders,
              while a more casual and friendly style may work well for social or
              informal events.
            </List>
            <List>
              Urgency and Importance: The level of urgency and importance
              associated with the email reminder can influence the tone and
              style of the email. Urgent reminders may require a more direct and
              concise approach, emphasizing the time-sensitive nature of the
              message.
            </List>
            <List>
              Relationship with the Recipient: Your relationship with the
              recipient plays a role in determining the appropriate style. For
              established and professional relationships, a more formal tone may
              be suitable. In contrast, for personal or informal relationships,
              a casual and friendly style may be more effective.
            </List>
            <List>
              Type of Reminder: The type of reminder, whether it’s related to
              appointments, payments, events, or other matters, can influence
              the style. For example, a payment reminder may benefit from a
              professional and formal tone, while an event reminder may be more
              engaging with a casual and inviting style.
            </List>
            <List>
              Brand Image: If you’re sending reminders on behalf of a brand or
              organization, it’s essential to maintain consistency with the
              brand image. Aligning the email style with the established brand
              voice helps reinforce brand identity and recognition.
            </List>
            <List>
              Emphasis on Action: Some reminders may require a stronger emphasis
              on prompting action. In such cases, a clear and direct style that
              highlights the necessary steps or actions can be more effective in
              driving the desired response.
            </List>
          </MenuContainer>
        </ContextContainer1>
      </MainContainer>
      <ContextContainer2>
        <MainContainer1>
          <Heading2>Email Reminder Examples</Heading2>
          <Description1>
            Professional Email Reminder for an Upcoming Doctor's Appointment
          </Description1>
          <ContextContainer3>
            <TextContainer2>
              <TextContainer1>
                <Description>
                  Subject Line: Your Upcoming Appointment with Dr. Smith
                </Description>
                <Description>Email Body:</Description>
                <Description>Dear [Patient Name],</Description>
                <Description>
                  This is a friendly reminder from [Clinic/Hospital Name] about
                  your upcoming appointment with Dr. [Doctor’s Last Name]. We
                  are looking forward to seeing you on [Appointment Date] at
                  [Appointment Time].
                </Description>
                <Description>Appointment Details:</Description>
                <MenuContainer>
                  <List>Date: [Appointment Date]</List>
                  <List>Time: [Appointment Time]</List>
                  <List>
                    Location: [Clinic/Hospital Address, Floor/Room if
                    applicable]
                  </List>
                  <List>Doctor: Dr. [Doctor’s Last Name]</List>
                </MenuContainer>
                <Description>
                  To ensure the best possible care, please remember to bring any
                  relevant medical records or documents with you. If you have
                  had any recent tests or have been to another specialist,
                  please bring those results as well.
                </Description>
                <Description>Preparation for Your Visit:</Description>
                <MenuContainer>
                  <List>
                    List any symptoms or concerns you wish to discuss.
                  </List>
                  <List>
                    Bring a list of all medications you are currently taking,
                    including over-the-counter drugs and supplements.
                  </List>
                  <List>
                    Consider bringing a family member or friend if you need
                    support.
                  </List>
                </MenuContainer>
                <Description>Cancellation Policy:</Description>
                <Description>
                  We understand that plans can change. If you need to reschedule
                  or cancel your appointment, please let us know at least 24
                  hours in advance to avoid any cancellation fees and to help us
                  offer your slot to another patient in need
                </Description>
                <Description>Contact Us:</Description>
                <Description>
                  Should you have any questions or need further assistance,
                  please do not hesitate to contact our office at [Contact
                  Information]. Our team is here to support you.
                </Description>
                <Description>
                  Thank you for choosing [Clinic/Hospital Name] for your
                  healthcare needs. We are committed to providing you with the
                  highest quality care and support.
                </Description>
                <Description>Warm regards,</Description>
                <Description>[Your Name]</Description>
                <Description>[Your Position]</Description>
                <Description>[Clinic/Hospital Name]</Description>
                <Description>[Contact Information]</Description>
              </TextContainer1>
            </TextContainer2>
            <TextContainer>
              <PictureContainer>
                <Image1 src={Back1} />
                <Image2 src={Pic} />
              </PictureContainer>
              <TextContainer1>
                <Description1>Explanation</Description1>
                <Description1>Professional Tone</Description1>
                <Description1>
                  The email is polite and respectful, using formal language
                  appropriate for a healthcare setting. It addresses the patient
                  directly and personally, fostering a sense of care and
                  attention.
                </Description1>
                <Description1>Detailed and Informative</Description1>
                <Description1>
                  It provides all necessary details about the appointment,
                  including date, time, location, and preparation instructions.
                  This comprehensive approach helps patients feel informed and
                  prepared, reducing anxiety and improving the efficiency of the
                  visit.
                </Description1>
                <Description1>Considerate of Patient Needs</Description1>
                <Description1>
                  By including a section on preparation for the visit and
                  highlighting the cancellation policy, the email shows
                  consideration for the patient’s time and wellbeing. It
                  encourages patients to be proactive in their care while also
                  respecting the clinic’s time.
                </Description1>
                <Description1>Use Cases</Description1>
                <Description1>
                  This template is ideal for medical clinics, hospitals, dental
                  offices, specialist practices, and any healthcare provider
                  that schedules appointments with patients. It helps streamline
                  communication, ensure patients are well-prepared for their
                  visits, and manage scheduling efficiently.
                </Description1>
              </TextContainer1>
            </TextContainer>
          </ContextContainer3>
        </MainContainer1>
      </ContextContainer2>
      <Footer />
    </>
  );
};

export default EmailReminder;
