import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 30px;
  padding: 50px 0px;
  width: 100%;
`;
export const MainContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 20px;
  padding: 30px 0px;
  width: 80%;
`;

export const ContextContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
  flex-wrap: wrap;
`;
export const ContextContainer3 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
`;
export const ContextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 80%;
  gap: 20px;
`;
export const ContextContainer2 = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  gap: 20px;
  background-color: #1376f8;
  margin: 50px 0px;
  padding: 50px 0px;
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 20px;
  max-width: 600px;
`;
export const TextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
`;
export const TextContainer2 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 20px;
  width: 700px;
  padding: 20px;
  border: none;
  border-radius: 10px;
  background-color: white;
  color: black;
`;
export const MenuContainer = styled.ul`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
`;
export const Heading = styled.h1`
  font-size: 34px;
  font-weight: 700;
  margin: 0%;
  color: #1376f8;
`;
export const Heading1 = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  color: #023e8a;
`;
export const Heading2 = styled.h1`
  font-size: 34px;
  font-weight: 600;
  margin: 0%;
  color: white;
`;
export const Description = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
export const Description1 = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
  color: white;
`;
export const List = styled.li`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
export const List1 = styled.li`
  font-size: 18px;
  font-weight: 400;
  color: white;
  margin: 0%;
`;
export const PictureContainer = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: start;
  justify-content: end;
`;
export const Image1 = styled.img`
  width: 410px;
  height: 410px;
  border-radius: 50%;
  border: none;
  position: absolute;
`;
export const Image2 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 30px;
  position: relative;
  right: 20px;
`;
