import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 50px;
  padding: 30px 0px;
`;
export const Logo = styled.img`
  width: 150px;
  height: 150px;
  align-items: start;
  display: flex;
`;
export const SubscriptionContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 50px;
`;
export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;
export const Heading = styled.h1`
  font-family: Inter;
  font-size: 28px;
  font-weight: 700;
  color: #1376f8;
  margin: 0%;
`;
export const Description = styled.p`
  font-family: Inter;
  font-size: 28px;
  font-weight: 500;
  line-height: 33.89px;
  margin: 0%;
`;
export const SubscriptionHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 30px;
`;
export const Subscription1 = styled.div`
  width: 400px;
  height: 850px;
  border-radius: 15px;
  gap: 15px;
  border: none;
  box-shadow: 1px 0px 7px 1px rgba(0, 0, 0, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;
export const Subscription2 = styled.div`
  width: 400px;
  height: 1000px;
  background-color: #1376f8;
  color: white;
  border-radius: 15px;
  gap: 15px;
  border: none;
  box-shadow: 1px 0px 7px 1px rgba(0, 0, 0, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;
export const Subscription3 = styled.div`
  width: 400px;
  height: 850px;
  border-radius: 15px;
  gap: 15px;
  border: none;
  box-shadow: 1px 0px 7px 1px rgba(0, 0, 0, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;
export const SubscriptionHeading = styled.h1`
  font-size: 22px;
  font-weight: 800;
  line-height: 30.05px;
  color: #1376f8;
  margin: 0%;
  span {
    display: flex;
    gap: 10px;
    align-items: center;
    color: white;
  }
`;
export const ListContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 280px;
`;
export const Icon = styled.div`
  font-size: 20px;
  color: #1376f8;
`;
export const List1 = styled.p`
  font-family: Manrope;
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
  line-height: 24.59px;
  width: 240px;
`;
export const Icon2 = styled.div`
  font-size: 20px;
  color: white;
`;
export const List2 = styled.p`
  font-family: Manrope;
  font-size: 18px;
  font-weight: 400;
  line-height: 24.59px;
  color: white;
  margin: 0%;
  width: 240px;
`;
export const Button1 = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 250px;
  height: 50px;
  border-radius: 5px;
  font-family: Manrope;
  font-size: 22px;
  font-weight: 800;
  line-height: 30.05px;
  background-color: #1376f8;
  color: white;
  &:hover {
    background-color: white;
    color: #1376f8;
    border: 2px solid #1376f8;
  }
`;
export const Button2 = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 250px;
  height: 50px;
  border-radius: 5px;
  opacity: 0px;
  font-family: Manrope;
  font-size: 22px;
  font-weight: 800;
  line-height: 30.05px;
  background-color: white;
  color: #1376f8;
  &:hover {
    background-color: #1376f8;
    color: white;
    border: 2px solid white;
  }
`;
