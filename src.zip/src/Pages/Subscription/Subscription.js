import React from "react";
import { BsPatchCheckFill } from "react-icons/bs";
import {
  MainContainer,
  Logo,
  SubscriptionContainer,
  HeadingContainer,
  Heading,
  Description,
  SubscriptionHolder,
  Subscription1,
  Subscription2,
  Subscription3,
  SubscriptionHeading,
  ListContainer,
  Icon,
  List1,
  Icon2,
  List2,
  Button1,
  Button2,
} from "./StyledSubscription";
// import Pic2 from "../../Components/Images/Logo.png";
import { FaCrown } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const Subscription = () => {
  const navigate = useNavigate();

  const Buy = () => {
    navigate("/buypage");
  };
  return (
    <>
      <MainContainer>
        {/* <Logo src={Pic2} /> */}
        <SubscriptionContainer>
          <HeadingContainer>
            <Heading>Subscription Plans</Heading>
            <Description>
              Choose the plan that best suits your needs:
            </Description>
          </HeadingContainer>
          <SubscriptionHolder>
            <Subscription1>
              <SubscriptionHeading>PERSONAL PLAN </SubscriptionHeading>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Reminders Per Month Included</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Private and Secure</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Call, Text and Email</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Record Your Own Voicefiles</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>
                  Access to In-House Voicefile Library w/ 140+ Files
                </List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Email Branding (Logo, Colors, WebURL)</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Live Assistance with Account Setup</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Originate Calls From Your Caller ID(s)</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Link Unlimited Google Calendars</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Upload Excel or CSV Files</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Nightly or Weekly Emailed Reports</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Custom Voice File Recording</List1>
              </ListContainer>
              <Button1 onClick={Buy}>PURCHASE</Button1>
            </Subscription1>
            <Subscription2>
              <SubscriptionHeading>
                <span>
                  Premium Plan
                  <FaCrown />
                </span>
              </SubscriptionHeading>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Reminders Per Month Included</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Private and Secure</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Call, Text and Email</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Record Your Own Voicefiles</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>
                  Access to In-House Voicefile Library w/ 140+ Files
                </List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Email Branding (Logo, Colors, WebURL)</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Live Assistance with Account Setup</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Originate Calls From Your Caller ID(s)</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Link Unlimited Google Calendars</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Upload Excel or CSV Files</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Nightly or Weekly Emailed Reports</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Custom Voice File Recording</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>
                  Programming API (Upload & Download Files Programatically)
                </List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>Optional HIPAA Compliance</List2>
              </ListContainer>
              <ListContainer>
                <Icon2>
                  <BsPatchCheckFill />
                </Icon2>
                <List2>
                  Integration Service - Automatic Uploads From Your EMR.
                  *+Charge
                </List2>
              </ListContainer>
              <Button2 onClick={Buy}>PURCHASE</Button2>
            </Subscription2>
            <Subscription3>
              <SubscriptionHeading>SMALL Plan</SubscriptionHeading>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Reminders Per Month Included</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Private and Secure</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Call, Text and Email</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Record Your Own Voicefiles</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>
                  Access to In-House Voicefile Library w/ 140+ Files
                </List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Email Branding (Logo, Colors, WebURL)</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Live Assistance with Account Setup</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Originate Calls From Your Caller ID(s)</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Link Unlimited Google Calendars</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Upload Excel or CSV Files</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Nightly or Weekly Emailed Reports</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>Custom Voice File Recording</List1>
              </ListContainer>
              <ListContainer>
                <Icon>
                  <BsPatchCheckFill />
                </Icon>
                <List1>
                  Programming API (Upload & Download Files Programatically)
                </List1>
              </ListContainer>
              <Button1 onClick={Buy}>PURCHASE</Button1>
            </Subscription3>
          </SubscriptionHolder>
        </SubscriptionContainer>
      </MainContainer>
    </>
  );
};

export default Subscription;
