import React from "react";
import {
  MainContainer,
  Frame,
  Container,
  Heading,
  NormalHeading,
  Frame1,
  CardContainer,
  Heading1,
  Container1,
  Image,
  Container3,
  Container4,
  Container5,
  Frame2,
  PicContainer,
  PicContainer1,
  Image1,
  Paragraph,
  Image2,
  Frame3,
  Frame4,
  Frame5,
  PictureContainer,
  ContextContainer,
  TextContainer,
  Image4,
  Menu,
  List,
  Frame6,
  ContextContainer3,
  ContextContainer4,
  Menu1,
  Paragraph1,
  Frame7,
  TableContainer,
  Paragraph2,
  PicContainer2,
  PicHeading,
  PicContainer3,
  Paragraph3,
  PicList,
} from "./StyledBusinessReminder";
import Pic from "../../Components/Images/48.png";
import Pic1 from "../../Components/Images/49.png";
import Pic2 from "../../Components/Images/50.png";
import Pic3 from "../../Components/Images/51.png";
import Pic4 from "../../Components/Images/52.png";
import Pic5 from "../../Components/Images/53.png";
import Pic6 from "../../Components/Images/54.png";
import Pic7 from "../../Components/Images/55.png";
import Pic8 from "../../Components/Images/56.png";
import Pic9 from "../../Components/Images/54.png";
import Pic10 from "../../Components/Images/55.png";
import Pic11 from "../../Components/Images/56.png";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";

const BusinessReminder = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <Container>
          <Heading>APPOINMENT REMINDERS FOR BUSINESSES</Heading>
          <NormalHeading>Appointment Reminders for Anyone! </NormalHeading>
        </Container>
        <Frame2>
          <Frame1>
            <Container1>
              <CardContainer>
                <Heading1>THERAPISTS</Heading1>
                <PicContainer>
                  <PicContainer1>
                    <Image1 src={Pic1}></Image1>
                  </PicContainer1>
                </PicContainer>
                <Paragraph>
                  Our appointment reminders for therapists suits therapists of
                  all types. We have independent therapists as well as large,
                  multi-location therapy practices.
                </Paragraph>
              </CardContainer>

              <CardContainer>
                <Heading1>ACCOUNTANTS</Heading1>
                <PicContainer>
                  <PicContainer1>
                    <Image2 src={Pic2}></Image2>
                  </PicContainer1>
                </PicContainer>
                <Paragraph>
                  Our appointment reminders for therapists suits therapists of
                  all types. We have independent therapists as well as large,
                  multi-location therapy practices.
                </Paragraph>
              </CardContainer>

              <CardContainer>
                <Heading1>LAWN CARE</Heading1>
                <PicContainer>
                  <PicContainer1>
                    <Image1 src={Pic}></Image1>
                  </PicContainer1>
                </PicContainer>
                <Paragraph>
                  Our appointment reminders for therapists suits therapists of
                  all types. We have independent therapists as well as large,
                  multi-location therapy practices.
                </Paragraph>
              </CardContainer>

              <CardContainer>
                <Heading1>HEATING AC</Heading1>
                <PicContainer>
                  <PicContainer1>
                    <Image1 src={Pic}></Image1>
                  </PicContainer1>
                </PicContainer>
                <Paragraph>
                  Our appointment reminders for therapists suits therapists of
                  all types. We have independent therapists as well as large,
                  multi-location therapy practices.
                </Paragraph>
              </CardContainer>
            </Container1>
          </Frame1>
          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic} alt=""></Image>
              </Container3>
            </Container4>
          </Container5>
        </Frame2>

        <Frame3>
          <Frame4>
            <CardContainer>
              <Heading1>FITNESS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Fitness Instructors can send text message alerts to clients to
                encourage them to work out or eat healthy as well as information
                on upcoming classes.
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>SALONS & SPAS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Hair stylists and salons can send appointment reminders to
                customers every few months when it’s time to schedule a new
                appointment.
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>PEST CONTROL</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Utilize appointment reminders for pest control to remind
                customers of existing appointments or annual check ups.
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>AUTO MECHANICS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Auto mechanics can send text or phone call reminders when a
                customer is due for an oil change or service.
              </Paragraph>
            </CardContainer>
          </Frame4>
        </Frame3>

        <Frame3>
          <Frame4>
            <CardContainer>
              <Heading1>REALTORS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Realtors can use our reminder app to send text messages to
                clients regarding showings, open houses, walk throughs, new
                listings, price reductions and more!
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>SALONS & SPAS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Photographers can remind their clients about upcoming photo
                shoots, specials, and more. They can also let clients know when
                their pictures are ready for viewing.
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>PEST CONTROL</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                House cleaning services can utilize recurring Google
                Calendar appointment reminders to remind their clients of
                bi-monthly scheduled cleanings
              </Paragraph>
            </CardContainer>

            <CardContainer>
              <Heading1>AUTO MECHANICS</Heading1>
              <PicContainer>
                <PicContainer1>
                  <Image1 src={Pic}></Image1>
                </PicContainer1>
              </PicContainer>
              <Paragraph>
                Pretty much anyone who works with customers, clients, or
                patients can utilize our reminder service to reduce no shows,
                increase customer satisfaction and more!
              </Paragraph>
            </CardContainer>
          </Frame4>
        </Frame3>

        <Frame5>
          <Heading>"EXPRESS ACCOUNTS" FOR SMALL BUDGETS</Heading>

          <ContextContainer>
            <PictureContainer>
              <Image4 src={Pic3}></Image4>
            </PictureContainer>

            <TextContainer>
              <Heading1>
                Express accounts are only $9.95 per month. These accounts are
                perfect for the budget conscious individual business owner.
              </Heading1>
              <Menu>
                <List>Add appointment reminders through the web interface</List>
                <List>Add appointment reminders through the web interface</List>
                <List>Add appointment reminders through the web interface</List>
                <List>Add appointment reminders through the web interface</List>
              </Menu>
              <Paragraph></Paragraph>
            </TextContainer>
          </ContextContainer>
        </Frame5>

        <Frame6>
          <ContextContainer3>
            <ContextContainer4>
              <Heading1>
                Some of the types of businesses that our express accounts are
                perfect for are:
              </Heading1>
              <Paragraph1>
                <Menu1>
                  <List>Tutors</List>
                  <List>Music Teachers</List>
                  <List>Coaches</List>
                  <List>Massage Therapists</List>
                  <List>Personal Trainers</List>
                  <List>Lawn Care</List>
                  <List>Painters</List>
                  <List>Snow Removal</List>
                  <List>Dog Groomers</List>
                  <List>Babysitters</List>
                </Menu1>
              </Paragraph1>
            </ContextContainer4>
          </ContextContainer3>

          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic4} alt=""></Image>
              </Container3>
            </Container4>
          </Container5>
        </Frame6>

        <Frame5>
          <Heading>"PERSONAL ACCOUNTS" FOR INDIVIDUAL BUSINESS OWNERS</Heading>

          <ContextContainer>
            <PictureContainer>
              <Image4 src={Pic3}></Image4>
            </PictureContainer>

            <TextContainer>
              <Heading1>
                Personal accounts are only $29.95 per month. These accounts are
                perfect for the individual business owner who wants to send
                automated appointment reminders to their customers or clients.
              </Heading1>
              <Menu>
                <List>
                  Send Google Calendar appointment reminders by linking up your
                  Google Calendar in a couple of easy steps!{" "}
                </List>
                <List>
                  Upload files such as excel and csv files with your customer
                  and appointment information.
                </List>
                <List>Add appointment reminders through the web interface</List>
                <List>Create different reminders based on appt types</List>
                <List>
                  Check the status and replies to your reminders in real-time.
                </List>
                <List>
                  Up to 400 Reminders per month (Each additional block of 100
                  reminders is just $7.50) 
                </List>
              </Menu>
              <Paragraph></Paragraph>
            </TextContainer>
          </ContextContainer>
        </Frame5>

        <Frame6>
          <ContextContainer3>
            <ContextContainer4>
              <Heading1>
                Some of theSome of the types of businesses that our personal
                accounts are perfect for are:
              </Heading1>
              <Paragraph1>
                <Menu1>
                  <List>Therapists (all kinds!)</List>
                  <List>Lawn Care Professionals</List>
                  <List>Counselors</List>
                  <List>Attorneys</List>
                  <List>Accountants</List>
                  <List>Hair Stylists</List>
                  <List>Nail Salons and Pedicures</List>
                  <List>Fitness Instructors</List>
                  <List>Tattoo Artists</List>
                  <List>Real Estate Agents</List>
                  <List>House Cleaning</List>
                  <List>Window Cleaning</List>
                  <List>Dog Training</List>
                  <List>Lot’s More!</List>
                </Menu1>
              </Paragraph1>
            </ContextContainer4>
          </ContextContainer3>

          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic5} alt=""></Image>
              </Container3>
            </Container4>
          </Container5>
        </Frame6>

        <Frame5>
          <Heading>SMALL BUSINESS ACCOUNTS</Heading>

          <ContextContainer>
            <PictureContainer>
              <Image4 src={Pic3}></Image4>
            </PictureContainer>

            <TextContainer>
              <Heading1>
                Our fully functional Small Business accounts are only $59.95 per
                month. These accounts are perfect for the small business owner
                who wants to send automated appointment reminders to their
                customers or clients.
              </Heading1>
              <Menu>
                <List>
                  Send Google Calendar appointment reminders by linking up your
                  Google Calendar in a couple of easy steps!
                </List>
                <List>
                  Upload files such as excel and csv files with your customer
                  and appointment information.
                </List>
                <List>Add appointment reminders through the web interface</List>
                <List>Create different reminders based on appt types</List>
                <List>
                  Check the status and replies to your reminders in real-time.
                </List>
                <List>
                  Up to 900 Reminders per month (Each additional block of 100
                  reminders is just $6.60) 
                </List>
              </Menu>
              <Paragraph></Paragraph>
            </TextContainer>
          </ContextContainer>
        </Frame5>

        <Frame6>
          <ContextContainer3>
            <ContextContainer4>
              <Heading1>
                Some of the types of businesses that our small business accounts
                are perfect for are:
              </Heading1>
              <Paragraph1>
                <Menu1>
                  <List>Fitness Studios</List>
                  <List>Restaurants</List>
                  <List>Therapy Practices</List>
                  <List>Law Firms</List>
                  <List>Pest Control Companies</List>
                  <List>Heating and Air Conditioning</List>
                  <List>Electrical</List>
                  <List>Weight loss clinics</List>
                  <List>Religious Organizations</List>
                  <List>Real Estate Firms</List>
                  <List>Home Design and Landscape Companies</List>
                  <List>Auto Mechanic Shops</List>
                  <List>Salons and Spas</List>
                  <List>Lot’s More!</List>
                </Menu1>
              </Paragraph1>
            </ContextContainer4>
          </ContextContainer3>

          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic6} alt=""></Image>
              </Container3>
            </Container4>
          </Container5>
        </Frame6>

        <Frame5>
          <Heading>ACCOUNTS FOR LARGE COMPANIES</Heading>

          <ContextContainer>
            <PictureContainer>
              <Image4 src={Pic3}></Image4>
            </PictureContainer>

            <TextContainer>
              <Heading1>
                Our premium accounts start at only $99.95 per month. These
                accounts are perfect for large businesses and multi-site
                facilities who typically send a large amount of appointment
                reminders.
              </Heading1>
              <Menu>
                <List>
                  Send Google Calendar appointment reminders by linking up your
                  Google Calendar in a couple of easy steps!
                </List>
                <List>
                  Upload files such as excel and csv files with your customer
                  and appointment information.
                </List>
                <List>Add appointment reminders through the web interface</List>
                <List>Create different reminders based on appt types</List>
                <List>
                  Check the status and replies to your reminders in real-time.
                </List>
                <List>
                  Up to 1700 Reminders per month (Each additional block of 100
                  reminders is just $5.90) 
                </List>
                <List>Multi-Site Configurations</List>
                <List>
                  Configure Reminders Across Multiple Facilities With Different
                  Names, Addresses, Etc…
                </List>
                <List>Detailed Invoicing With Facility Breakdowns</List>
                <List>Separate or Shared Accounts Across Locations</List>
                <List>Private & Secure</List>
                <List>No Long-Term Contracts!</List>
                <List>
                  Up to 1700 Reminders per month (Each additional 100 reminders
                  is just $5.90) 
                </List>
                <List>
                  Volume Discounts (Send over 5k reminders per month and save
                  $$$)
                </List>
                <List>Optional HIPAA Compliance</List>
              </Menu>
              <Paragraph></Paragraph>
            </TextContainer>
          </ContextContainer>
        </Frame5>

        <Frame6>
          <ContextContainer3>
            <ContextContainer4>
              <Heading1>
                Some of the types of businesses that our premium accounts are
                perfect for are:
              </Heading1>
              <Paragraph1>
                <Menu1>
                  <List>Busy Small Businesses</List>
                  <List>Multi Site Businesses</List>
                  <List>Large & Small Corporations</List>
                  <List>Healthcare</List>
                  <List>Waste Management</List>
                  <List>Anyone who sends over 1700 Reminders per Month!</List>
                </Menu1>
              </Paragraph1>
            </ContextContainer4>
          </ContextContainer3>

          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic7} alt=""></Image>
              </Container3>
            </Container4>
          </Container5>
        </Frame6>

        <Frame7>
          <TableContainer>
            <Heading>BASIC INTEGRATIONS</Heading>
            <Paragraph2>
              Our premium accounts allow you to send Google Calendar sms
              reminders, call reminders, and email reminders by linking up your
              Google Calendar in a couple of easy steps!
            </Paragraph2>
            <Paragraph2>
              Our premium accounts allow you to send Google Calendar sms
              reminders, call reminders, and email reminders by linking up your
              Google Calendar in a couple of easy steps!
            </Paragraph2>
          </TableContainer>
          <TableContainer>
            <Heading>ADVANCED INTEGRATIONS</Heading>
            <Paragraph2>
              You can utilize our integration service or our API to send us
              large amounts of data through secure file transfers. Receive
              real-time reports when we receive a file and get automatic email
              alerts when we do not receive a file for a couple of days.
            </Paragraph2>
          </TableContainer>
          <TableContainer>
            <Heading>VOLUME PRICING</Heading>
            <Paragraph2>
              If you plan on sending over 5000 appointment reminders per month,
              you will save big with our volume pricing with costs as low as 5
              cents per reminder.
            </Paragraph2>
          </TableContainer>
        </Frame7>

        <Frame7>
          <PicContainer2>
            <PicHeading>We Take Care of Your Customers</PicHeading>
            <PicContainer3>
              <Image1 src={Pic8}></Image1>
            </PicContainer3>
            <Paragraph3>
              Reminding your customers to come to their appointments is easier
              than ever through our automated reminder service. Many customers
              these days even EXPECT you to send them a reminder.
            </Paragraph3>
            <Paragraph3>
              Using our automated appointment reminders, you can send a reminder
              in your customers preferred outreach method (call, text, or email)
              and add specific information about the type of the appointment you
              are reminding them about.
            </Paragraph3>
            <Paragraph3>
              For example, if this is a new customer, maybe they need to arrive
              early to the appointment, while established customers don’t need
              the message.
            </Paragraph3>
            <Paragraph3>
              You can also include customer specific information such as room
              numbers, amounts due, etc…
            </Paragraph3>
          </PicContainer2>
          <PicContainer2>
            <PicHeading>APPOINTMENT REMINDERS HELP YOUR OFFICE</PicHeading>
            <PicContainer3>
              <Image1 src={Pic9}></Image1>
            </PicContainer3>
            <Paragraph3>
              The use of appointment reminders benefits your office staff as
              well. Your employees can spend more time taking care of your
              customers when they show up, instead of tying up the phone lines
              with reminder calls. 
            </Paragraph3>
            <Paragraph3>
              A lot of appointments are made far in advance. A friendly reminder
              sent a couple days prior to the appointment can encourage your
              customers to show up even when they don’t remember making the
              appointment because it was done months ago.
            </Paragraph3>
            <Paragraph3>
              A lot of appointments are made far in advance. A friendly reminder
              sent a couple days prior to the appointment can encourage your
              customers to show up even when they don’t remember making the
              appointment because it was done months ago.
            </Paragraph3>
          </PicContainer2>
          <PicContainer2>
            <PicHeading>We Take Care of Your Customers</PicHeading>
            <PicContainer3>
              <Image1 src={Pic10}></Image1>
            </PicContainer3>
            <Paragraph3>
              <menu>
                <PicList>
                  Our database and web servers are stored securely in the USA
                  with our HIPAA Compliant data partner HIPAA Vault
                </PicList>
                <PicList>
                  HIPAA Vault maintains data centers in multiple geographic
                  locations including San Diego, CA and Phoenix, AZ.
                </PicList>
                <PicList>
                  Even if you are not a medical provider that needs HIPAA
                  Compliance, your data is highly secure!
                </PicList>
                <PicList>
                  Etica Inc. dba HIPAA Vault Makes the Inc. 5000 list of
                  America’s Fastest Growing Companies
                </PicList>
              </menu>
            </Paragraph3>
          </PicContainer2>
          <PicContainer2>
            <PicHeading>We Take Care of Your Customers</PicHeading>
            <PicContainer3>
              <Image1 src={Pic11}></Image1>
            </PicContainer3>
            <Paragraph3>
              <menu>
                <PicList>
                  Any time you connect to our website to view patient data, you
                  are connecting through a secure, encrypted connection. This is
                  also true with our integration service and web API.
                </PicList>
                <PicList>
                  Our data is transmitted through the most current version of
                  TLS Encryption and never sent using plain, open text.
                </PicList>
                <PicList>
                  For more advanced setups you can send files to us via SFTP.
                </PicList>
              </menu>
            </Paragraph3>
          </PicContainer2>
        </Frame7>
      </MainContainer>
      <Footer />
    </>
  );
};

export default BusinessReminder;
