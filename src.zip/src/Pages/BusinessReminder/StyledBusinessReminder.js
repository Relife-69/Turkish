import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  padding: 50px 0px;
`;
export const Frame = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
`;
export const Container = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 80%;
`;
export const Heading = styled.h1`
  font-size: 34px;
  display: flex;
  justify-content: center;
  color: #1376f8;
  align-items: center;
  font-weight: 700;
`;
export const NormalHeading = styled.h2`
  font-size: 28px;
  color: #023e8a;
  align-items: center;
  font-weight: 700;
`;
export const Frame1 = styled.div`
  display: flex;
  align-items: center;
  max-width: 700px;
  gap: 50px;
  flex-wrap: wrap;
`;
export const CardContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 300px;
  min-height: 200px;
`;
export const Heading1 = styled.h3`
  font-size: 29px;
  align-items: center;
  font-weight: 700;
`;
export const Container1 = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
`;
export const Container2 = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
`;
export const Image = styled.img`
  width: 400px;
  height: 400px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Container3 = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 350px;
  height: 350px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Container4 = styled.div`
  display: flex;
  flex-direction: column;
  width: 500px;
  margin-bottom: 100px;
  justify-content: end;
  align-items: end;
`;
export const Container5 = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: column;
  width: 500px;
  gap: 1px;
`;
export const Frame2 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
`;
export const PicContainer1 = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 135px;
  height: 135px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const PicContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 150px;
  margin-bottom: 30px;
  justify-content: end;
  align-items: end;
`;
export const Image1 = styled.img`
  width: 135px;
  height: 135px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 10px;
  top: 9px;
`;
export const Paragraph = styled.p`
  font-size: 17px;
  align-items: center;
  font-weight: 500;
  text-align: center;
`;
export const Image2 = styled.img`
  width: 135px;
  height: 135px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 10px;
  top: 9px;
`;
export const Frame3 = styled.div`
  display: flex;
  align-items: center;
  width: 80%;
`;
export const Frame4 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
`;
export const Frame5 = styled.div`
  width: 80%;
  justify-content: center;
  align-items: center;
  display: flex;
  flex-direction: column;
`;
export const PictureContainer = styled.div`
  display: flex;
  max-width: 278px;
  min-height: 182px;
  justify-content: center;
  align-items: center;
`;
export const Image4 = styled.img`
  width: 278px;
  height: 182px;
  border-radius: 10px 10px 0px 0px;
`;
export const ContextContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 50px;
`;
export const TextContainer = styled.div``;
export const Menu = styled.ul`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
`;
export const List = styled.li`
  font-size: 20px;
  align-items: center;
  font-weight: bold;
`;
export const Frame6 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const ContextContainer3 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const ContextContainer4 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  width: 674px;
  flex-direction: column;
`;
export const Menu1 = styled.ul`
  font-size: 14px;
  font-weight: 500;
`;
export const Paragraph1 = styled.p`
  font-size: 15px;
  font-weight: 900;
`;

export const Frame7 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
  padding: 5px;
`;
export const TableContainer = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  flex-direction: column;
  width: 500px;
`;

export const ContextContainer5 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  width: 400px;
`;
export const Paragraph2 = styled.p`
  font-size: 15px;
  font-weight: bold;
  margin: 0%;
  gap: 1%;
`;
export const PicContainer2 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  flex-direction: column;
  width: 500px;
`;
export const PicHeading = styled.h3`
  font-size: 29px;
  align-items: center;
  text-align: center;
  font-weight: 900;
`;
export const PicContainer3 = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 115px;
  height: 115px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Paragraph3 = styled.p`
  font-size: 20px;
  font-weight: 400;
  margin: 1%;
`;
export const PicList = styled.li`
  font-size: 20px;
`;
