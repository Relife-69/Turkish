import React from "react";
import {
  MainConatiner,
  Section,
  Container,
  BlueHeading,
  Section1,
  BlueHeading1,
  Paragraph,
  Menu,
  List,
  ContextCointer,
  ImageContainer,
  PicSizeContainer,
  PicBackGroundContainer,
  Image,
  Section2,
  TextContainer,
  List1,
  Section3,
  TextContainer1,
  WhiteHeading,
  WhiteParagraph,
  WhiteMenu,
  TextContainer2,
  WhiteImage,
  Section4,
  Section4Container1,
  ListDot,
  PicWhiteBackGroundContainer,
  PicWhiteSizeContainer,
  WhiteImage1,
  WhiteListDot,
} from "./StyledCallReminder";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import Pic from "../../Components/Images/1.png";
import Pic1 from "../../Components/Images/2.png";
import Pic2 from "../../Components/Images/3.png";
import Pic3 from "../../Components/Images/4.png";
import Pic4 from "../../Components/Images/5.png";
import Pic5 from "../../Components/Images/6.png";

const CallReminder = () => {
  return (
    <>
      <Navbar />
      <MainConatiner>
        <Section>
          <Container>
            <BlueHeading>AUTOMATED REMINDER CALLS</BlueHeading>
          </Container>
        </Section>

        <Section1>
          <ContextCointer>
            <BlueHeading1>What are Automated Reminder Calls?</BlueHeading1>
            <BlueHeading1>Reminder Call Technology</BlueHeading1>
            <Paragraph>
              Automated reminder calls are telephone calls made by an automated
              dialing system that deliver a pre-recorded message to the
              recipient.
            </Paragraph>
            <Paragraph>
              These calls are commonly used by businesses, healthcare providers,
              service organizations, and others to remind individuals about
              upcoming appointments, payment due dates, events, or other
              important commitments. The primary goal is to ensure that the
              recipient remembers to attend, pay, or take some specific action
              by a certain date or time.
            </Paragraph>
            <Paragraph>
              The process typically involves the following steps:
              <Menu>
                <List>
                  Scheduling: The organization schedules a reminder call for a
                  specific time and date, often determined based on the timing
                  of the event or deadline for which the reminder is intended.
                </List>
                <List>
                  Message Creation: A pre-recorded message is created, detailing
                  the specifics of what the recipient is being reminded about.
                  This message may include the date, time, location of the
                  appointment or event, or any other relevant details.
                </List>
                <List>
                  Automated Calling: At the scheduled time, an automated dialing
                  system places calls to the list of recipients who need to be
                  reminded. When the call is answered, the system plays the
                  pre-recorded message.
                </List>
                <List>
                  Confirmation and Follow-up: Most systems (including ours)
                  allow recipients to confirm their attendance or reschedule
                  appointments directly through the call by pressing specified
                  keys on their phone keypad. Additionally, the system may be
                  set up to send follow-up reminders if necessary.
                </List>
              </Menu>
            </Paragraph>

            <Paragraph>
              Automated reminder calls are highly efficient for organizations
              because they reduce the need for manual calling, save time, and
              can significantly decrease the rate of no-shows or missed
              deadlines. They also offer convenience for recipients by providing
              timely reminders without requiring direct interaction with a staff
              member.
            </Paragraph>
          </ContextCointer>

          <ImageContainer>
            <PicSizeContainer>
              <PicBackGroundContainer>
                <Image src={Pic} alt=""></Image>
              </PicBackGroundContainer>
            </PicSizeContainer>
          </ImageContainer>
        </Section1>

        <Section2>
          <TextContainer>
            <BlueHeading1>Reminder Call Statistics</BlueHeading1>
            <Paragraph>
              <menu>
                <List1>
                  According to the Medical Group Management Association
                  (MGMA), nearly 88% of healthcare leaders reported that their
                  organizations use automated appointment reminders, which has
                  led to higher revenue, lower no-show rates, better patient
                  compliance, and more efficient appointment utilization among
                  other benefits.
                </List1>
                <List1>
                  The American Journal of Medicine highlighted that no-show
                  rates for patients dropped by half when they received
                  automated reminder calls. This not only helps in maintaining
                  the schedule efficiently but also strengthens the relationship
                  between clients and businesses, ensuring they remain at the
                  forefront of their clients’ minds.
                </List1>
                <List1>
                  Optimizing Number and Timing of Appointment Reminders: This
                  study, conducted within Kaiser Permanente Colorado’s
                  integrated healthcare delivery system, aimed to find the
                  optimal timing and frequency for appointment reminders. It
                  compared the effectiveness of reminders sent 3 days before, 1
                  day before, and both 3 days and 1 day before an appointment.
                  While specific outcomes on automated calls alone aren’t
                  detailed separately, the study emphasizes the general
                  effectiveness of reminders in reducing missed appointments and
                  discusses the strategic implementation of reminder systems
                  within healthcare settings.
                </List1>
                <List1>
                  Text-messaging versus Telephone Reminders: A study published
                  in BMC Health Services Research explored the effectiveness and
                  cost-effectiveness of text messaging compared to telephone
                  reminders in reducing missed appointments at an academic
                  primary care clinic. It found that both methods were
                  effective.
                </List1>
              </menu>
            </Paragraph>
          </TextContainer>
        </Section2>

        <Section3>
          <TextContainer1>
            <WhiteHeading>When to use Reminder Calls</WhiteHeading>
            <WhiteParagraph>
              Automated Reminder Calls are a great choice when you have a lot of
              information that you need to convey. You can also set up your
              account to trigger reminder calls if text message reminders
              fail due to an invalid mobile number. 
            </WhiteParagraph>
            <WhiteParagraph>
              In some cases reminder calls are simply the best choice based on
              the demographic and the type of appointment it is. For example, if
              you are reminding someone of a specialized procedure with lots of
              specific instructions, it just makes more sense to put that in a
              call (or maybe an email reminder)  rather than a text
              message. Text message reminders are excellent for short messages
              with just basic information. Also, if you are attempting to reach
              an older demographic, many times a call may be a better choice
              simply because many people either prefer calls, or do not have
              texting capabilities.
            </WhiteParagraph>
            <WhiteParagraph>
              You will need to consider your specific use-case when deciding
              whether to use call reminders. As for which outreach method is
              more effective in reducing no shows, our experience as well
              as study data on texts vs calls show that they have very similar
              outcomes.
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <WhiteImage src={Pic1} alt=""></WhiteImage>
          </TextContainer2>
        </Section3>

        <Section4>
          <Section4Container1>
            <BlueHeading>
              SENDING REMINDER CALLS WITH APPOINTMENTREMINDER.COM
            </BlueHeading>
            <Paragraph>
              <menu>
                <ListDot>
                  AppointmentReminders.com specializes in sending automated call
                  appointment reminders! 
                </ListDot>
                <ListDot>
                  When you send automated call reminders with us, you can expect
                  all of these features and more!
                </ListDot>
                <ListDot>
                  Personalization: Custom messages with recipient’s details.
                </ListDot>
                <ListDot>
                  Calls Sent From Your Caller ID: Send calls from your caller
                  ID for a more professional look.
                </ListDot>
                <ListDot>
                  Record Your Own Messages: Record your own messages right over
                  the phone or use text-to-speech or choose from our library of
                  prerecorded files.
                </ListDot>
                <ListDot>
                  Multilingual Support: Offers reminders in English or Spanish.
                </ListDot>
                <ListDot>
                  Interactive Voice Response (IVR): Optional – Lets
                  recipients confirm, cancel or change appointments via keypad.
                </ListDot>
                <ListDot>
                  Scheduling Flexibility: Timely reminders set for optimal
                  times.
                </ListDot>
                <ListDot>
                  System Integration: Syncs with Google Calendar and scheduling
                  software.
                </ListDot>
                <ListDot>
                  Analytics and Reporting: Insights on call outcomes and
                  effectiveness.
                </ListDot>
                <ListDot>Scalability: Manages high volumes of calls.</ListDot>
                <ListDot>
                  Regulatory Compliance: Meets privacy and legal standards.
                </ListDot>
                <ListDot>
                  Call Frequency Customization: Adjust reminder frequency.
                </ListDot>
                <ListDot>
                  Voice Message Leave: Leaves messages if calls are unanswered.
                </ListDot>
                <ListDot>Retry Logic: Redials for unanswered calls.</ListDot>
                <ListDot>
                  Security and Privacy: Protects transmitted and personal
                  information.
                </ListDot>
                <ListDot>
                  Custom Call Scripts: Tailor call content for specific services
                  or appointments.
                </ListDot>
                <ListDot>
                  Time Zone Awareness: Automatically adjusts call times based on
                  recipient’s time zone.
                </ListDot>
                <ListDot>
                  Do Not Disturb Respect: Avoids calling during specified quiet
                  hours.
                </ListDot>
                <ListDot>
                  Follow-up Reminders: Send texts or emails if calls are
                  unanswered or not responded to.
                </ListDot>
                <ListDot>
                  User-friendly Dashboard: For managing and monitoring calls in
                  real time.
                </ListDot>
                <ListDot>
                  Event-triggered Reminders: Sends reminders based on specific
                  actions or dates, not just appointments.
                </ListDot>
                <ListDot>
                  Opt-out Mechanism: Allows recipients to easily opt out of
                  future calls.
                </ListDot>
              </menu>
            </Paragraph>
          </Section4Container1>
        </Section4>

        <Section3>
          <TextContainer1>
            <WhiteHeading>
              Send Your Reminder Calls at the Appropriate Time
            </WhiteHeading>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteListDot>
                  Our reminder system allows you to schedule your reminder calls
                  at the appropriate time.   You can also trigger them when an
                  event happens such as a text message or email failure.
                </WhiteListDot>
                <WhiteListDot>
                  For example, you can send a reminder a week ahead of the
                  appointment and then another on the day before the
                  appointment.  You can also change the reminder content based
                  on the customer or patients reply to the initial reminder. 
                  Say the customer or patient confirms the appointment using the
                  reminder call you send out one week prior. In this case, you
                  may want to just give them a gentle reminder the day before,
                  rather than asking for another confirmation.
                </WhiteListDot>
                <WhiteListDot>
                  When you send your reminder calls, really depends on a few
                  factors. If this is an annual appointment, you may want to
                  send a reminder a couple weeks prior to the appointment. And
                  then send another one a couple days before. However, if this
                  is a recurring weekly appointment, probably one reminder on
                  the day before or even on the day of the appointment is
                  sufficient.
                </WhiteListDot>
                <WhiteListDot>
                  Learn your magic number as far as optimizing number and timing
                  of reminders.  This way you keep your customers happy and
                  informed without annoying them or causing them to  of your
                  reminders.
                </WhiteListDot>
              </WhiteMenu>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic2} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
        </Section3>

        <Section3>
          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic3} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>

          <TextContainer1>
            <WhiteHeading>
              Allow Your Patients or Customers to Reply to your Reminder Calls
            </WhiteHeading>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteListDot>
                  Allow your patients or customers to confirm the appointment
                  with a simple keypress! In fact, we allow you to add up to 3
                  reply digits to each reminder call. 
                </WhiteListDot>
                <WhiteListDot>
                  For example, a typical scenario may be where you would allow
                  your customer to either “confirm”, “cancel”, or “reschedule”
                  the appointment by pressing the 1,2 or 3 keypress on their
                  phone.
                </WhiteListDot>
                <WhiteListDot>
                  Which digits you allow is entirely up to you.  You may want
                  just allow “confirm” or perhaps you do not want to include the
                  ability to reply at all. With our call reminders, you can
                  include whichever replies are necessary for your specific
                  case.
                </WhiteListDot>
                <WhiteListDot>
                  As well, we allow your customers to opt out of reminders using
                  a simple key-press. If someone presses ‘9’ in response to a
                  call type reminder, they will be unsubscribed from calls. If
                  you want people to be aware of this option then you will need
                  to add it to your call type reminder (e.g. press ‘9’ to
                  unsubscribe).
                </WhiteListDot>
              </WhiteMenu>
            </WhiteParagraph>
          </TextContainer1>
        </Section3>

        <Section3>
          <TextContainer1>
            <WhiteHeading>Generate your calls from your Caller ID</WhiteHeading>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteListDot>
                  You can also configure your phone call reminders to originate
                  from your office Caller ID so there is no confusion about who
                  is calling. This leads to more people answering your automated
                  reminder calls and in turn showing up for their appointment.
                </WhiteListDot>
                <WhiteListDot>
                  In fact, you can add as many Caller IDs as you like with our
                  service.  This way if you have different locations that are
                  sending out call reminders, they can all originate from the
                  phone number associated with that location.
                </WhiteListDot>
                <WhiteListDot>
                  It’s very easy to add Caller IDs as well.  Simply go the
                  the Caller ID Screen and add a caller ID.  Then click on
                  verify.  This will place a call to you at the caller ID that
                  you entered and ask you to enter a code.  Once you enter the
                  code, the Caller ID will be verified.  Now you can send your
                  call reminders from this number.  If you are unable to verify
                  the Caller ID through this method, let us know and we can
                  usually add it for you.
                </WhiteListDot>
              </WhiteMenu>
            </WhiteParagraph>
          </TextContainer1>

          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic5} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>
        </Section3>

        <Section3>
          <TextContainer2>
            <PicWhiteSizeContainer>
              <PicWhiteBackGroundContainer>
                <WhiteImage1 src={Pic4} alt=""></WhiteImage1>
              </PicWhiteBackGroundContainer>
            </PicWhiteSizeContainer>
          </TextContainer2>

          <TextContainer1>
            <WhiteHeading>
              Roll Your Automated Reminder Calls to Texts or Emails
            </WhiteHeading>
            <WhiteParagraph>
              <WhiteMenu>
                <WhiteListDot>
                  Just like we provide the ability to roll failed text messages
                  to email or call reminders, we also provide the ability to
                  roll failed call reminders to email reminders or text
                  reminders.
                </WhiteListDot>
                <WhiteListDot>
                  This way, you can be sure that even if we are unable to
                  deliver the call reminder, your customer will still get the
                  notification via text message or email.
                </WhiteListDot>
                <WhiteListDot>
                  Your customers can also unsubscribe from just the call
                  reminders which will result in an automatic rollover to text
                  or email (however you set it up).
                </WhiteListDot>
              </WhiteMenu>
            </WhiteParagraph>
          </TextContainer1>
        </Section3>
      </MainConatiner>
      <Footer />
    </>
  );
};

export default CallReminder;
