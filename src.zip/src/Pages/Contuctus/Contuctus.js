import React, { useState } from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  Description,
  Heading1,
  Heading2,
  Image1,
  Image2,
  Image3,
  ImageContainer,
  Input1,
  Input2,
  Input3,
  InputContainer,
  InputContainer1,
  Label,
  Button,
  MainContainer,
  MainHeading,
  NameContainer,
  PictureContainer,
  TextContainer,
} from "./StyledContuctus";
import axios from "axios";
import Back from "../../Components/Images/Background.png";
import Pic1 from "../../Components/Images/11.png";
import Pic2 from "../../Components/Images/12.png";
import { Link, useNavigate } from "react-router-dom";
const Contuctus = () => {
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [massage, setMassage] = useState("");
  const [error, setError] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    const user = {
      first_name: firstname,
      last_name: lastname,
      email,
      phone,
      massage,
    };
    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/contact-us/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Api response:", result.data);
      alert("Request Sent Successfully");
    } catch (error) {
      console.error("Error:", error);
      setError(error.response ? error.response.data : "Request Error");
    }
  };

  return (
    <>
      <Navbar />
      <MainContainer>
        <TextContainer>
          <MainHeading>
            <span>CONTACT </span> US
          </MainHeading>
          <Heading1>
            Questions?<span> Comments? </span> We would love to hear from you!
          </Heading1>
          <Heading2>
            Thanks For <span> Visiting: </span>{" "}
          </Heading2>
          <Description>
            Here at AppointmentReminders.com, we are dedicated to excellent
            customer service! That’s why when you contact us for a support
            question or a simple inquiry we will typically get back to you
            within 24 hours if not immediately. We know how frustrating bad
            customer service can be which is why we pride ourselves on being
            available to help whether it’s though email, chat, phone, or an
            online meeting.
          </Description>
          <Heading2>
            <span> New </span> Accounts:
          </Heading2>
          <Description>
            If you have just created an account with us and need help getting
            started, please just let us know.  We are aware that it can be a bit
            overwhelming when you first start because you are new to the system,
            but typically once you get everything set up your account will
            require very little maintenance.  Therefore we always provide free
            live account set up and support for ALL account tiers. We will walk
            you through each page of your account so you understand exactly how
            things work.  Also, we will help you link your calendar (if needed),
            configure and test your reminders, and learn how to check reminder
            status and replies to your reminders. We look forward to serving you
            and helping your company succeed!
          </Description>
          <Heading2>
            New and Existing <span>Customers:</span>
          </Heading2>
          <Description>
            The best way to obtain support is to create a new email support
            ticket by clicking here or emailing us at
            support@appointmentreminders.com
          </Description>
          <Heading2>
            By <span>phone:</span>
          </Heading2>
          <Description>
            You may contact us by phone during regular business hours at
            +1-727-346-6423
          </Description>
          <Heading2>
            By <span> Address: </span>
          </Heading2>
          <Description>We are in St. Petersburg, FL</Description>
          <Heading2>
            By <span> email: </span>
          </Heading2>
          <Description>
            You may email us through the following emails or use the form below.
            Sales inquiries please email
            <Link> appointmentreminders.bot </Link> Support questions please
            email <Link> support@appointmentreminders.bot </Link>
          </Description>
          <Heading2>
            <span>Questions? </span>
          </Heading2>
          <Description>
            To obtain information about our services, please fill out the
            following form and someone will get back to you shortly.
          </Description>
          <InputContainer>
            <NameContainer>
              <Label>First Name</Label>
              <Input1
                required
                type="text"
                value={firstname}
                onChange={(e) => setFirstname(e.target.value)}
                placeholder="Enter Here"
              />
            </NameContainer>
            <NameContainer>
              <Label>Last Name</Label>
              <Input1
                required
                type="text"
                value={lastname}
                onChange={(e) => setLastname(e.target.value)}
                placeholder="Enter Here"
              />
            </NameContainer>
          </InputContainer>
          <InputContainer1>
            <Label>Email</Label>
            <Input2
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Here"
            />
          </InputContainer1>
          <InputContainer1>
            <Label>Phone No</Label>
            <Input2
              required
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Enter"
            />
          </InputContainer1>
          <InputContainer1>
            <Label>How May We Help</Label>
            <Input3
              required
              type="text"
              className="massage"
              placeholder="Enter Here"
              value={massage}
              onChange={(e) => setPhone(e.target.value)}
            />
          </InputContainer1>
          <Button onClick={handleSubmit}>SEND</Button>
        </TextContainer>
        <PictureContainer>
          <ImageContainer>
            <Image1 src={Back} />
            <Image2 src={Pic1} />
          </ImageContainer>
          <Image3 src={Pic2} />
        </PictureContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Contuctus;
