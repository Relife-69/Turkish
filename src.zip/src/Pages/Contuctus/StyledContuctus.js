import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  gap: 10px;
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  width: 650px;
`;
export const PictureContainer = styled.div`
  display: flex;
  align-items: end;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
`;
export const ImageContainer = styled.div`
  display: flex;
  width: 700px;
  height: 700px;
  align-items: center;
  justify-content: end;
`;
export const Image1 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  position: absolute;
`;
export const Image2 = styled.img`
  width: 600px;
  height: 600px;
  border-radius: 50%;
  border: none;
  top: 80px;
  position: relative;
  right: 50px;
`;
export const Image3 = styled.img`
  width: 600px;
  height: 952px;
`;
export const MainHeading = styled.h1`
  font-size: 34px;
  font-weight: 700;
  margin-bottom: 10px;
  line-height: 41.15px;
  span {
    color: #1376f1;
  }
`;
export const Heading1 = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  line-height: 41.15px;
  span {
    color: #1376f1;
  }
`;
export const Heading2 = styled.h1`
  font-weight: 600;
  margin: 0%;
  line-height: 41.15px;
  width: 280px;
  span {
    color: #1376f1;
  }
`;
export const Description = styled.p`
  font-size: 14px;
  font-weight: 600;
  margin: 0%;
  a {
    color: #1376f1;
    text-decoration: none;
  }
`;

export const InputContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 660px;
`;
export const InputContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: space-between;
  width: 660px;
  flex-direction: column;
`;

export const NameContainer = styled.div`
  display: flex;
  align-items: start;
  flex-direction: column;
  justify-content: start;
  width: 320px;
`;
export const Label = styled.label`
  font-size: 14px;
  font-weight: 500;
`;
export const Input1 = styled.input`
  width: 300px;
  padding: 0px 10px;
  height: 40px;
  border-radius: 4px;
`;
export const Input2 = styled.input`
  width: 640px;
  padding: 0px 10px;
  height: 40px;
  border-radius: 4px;
`;
export const Input3 = styled.textarea`
  width: 640px;
  padding: 10px;
  height: 210px;
  border-radius: 4px;
`;

export const Button = styled.button`
  width: 663px;
  height: 40px;
  border-radius: 4px;
  border: none;
  background-color: #1376f8;
  color: white;
  font-size: 18px;
  font-weight: 500;
  cursor: pointer;
  &:hover {
    background-color: white;
    border: 2px solid #1376f8;
    color: #1376f8;
  }
`;
