import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 40px 0px;
  justify-content: center;
  gap: 40px;
  width: 100%;
  flex-direction: column;
`;
export const Container = styled.div`
  display: flex;
  align-items: start;
  justify-content: space-between;
  /* flex-wrap: wrap; */
  width: 80%;
`;
export const Container1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: center;
  flex-direction: column;
  gap: 20px;
  /* flex-wrap: wrap; */
  width: 80%;
`;
export const Container2 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
  width: 80%;
`;
export const PictureContainer = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: start;
  justify-content: end;
`;
export const Image1 = styled.img`
  width: 410px;
  height: 410px;
  border-radius: 50%;
  border: none;
  position: absolute;
`;
export const Image2 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 50px;
  position: relative;
  right: 30px;
`;

export const ContextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  max-width: 700px;
  gap: 30px;
`;

export const ContextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 20px;
`;
export const ContextContainer2 = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 20px;
  width: 600px;
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
`;
export const TextContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 15px;
`;
export const Heading = styled.h1`
  font-size: 34px;
  font-weight: 700;
  margin: 0%;
  color: #1376f8;
  position: relative;
  z-index: 9999;
  /* width: 900px; */
`;
export const Heading1 = styled.h1`
  font-size: 28px;
  font-weight: 700;
  margin: 0%;
  color: #023e8a;
`;

export const Description = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
  span {
    color: #023e8a;
  }
`;

export const ListContainer = styled.ul`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
`;
export const List = styled.li`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
