import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  Container,
  Container1,
  Container2,
  ContextContainer,
  ContextContainer2,
  Description,
  Heading,
  Heading1,
  Image1,
  Image2,
  MainContainer,
  PictureContainer,
  TextContainer,
  TextContainer1,
} from "./StyledAdvancedIntegration";

import Back from "../../Components/Images/Background.png";
import Pic from "../../Components/Images/27.png";
import Pic1 from "../../Components/Images/26.png";

const AdvancedIntegration = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <Container>
          <ContextContainer>
            <Heading>Advanced Appointment Reminder Integrations</Heading>
            <TextContainer>
              <Heading1>
                About our Advanced Appointment Reminder Integration
              </Heading1>
            </TextContainer>
            <Description>
              We make it very easy for you to integrate your data into our site
              using our advanced appointment reminder integration methods. No
              matter what EMR or scheduling service you use, we can usually
              integrate with it using one of the methods below. If none of these
              are an option, we do offer some basic integration methods as well
              that ANYONE can use!
            </Description>
            <TextContainer>
              <Description>
                <span>Method 1: </span> Allow us to Connect to your EMR
              </Description>
              <Description>
                We can connect seamlessly to most EMRs without any intervention
                on your part. Contrary to popular belief, integrating your data
                for fully automated appointment reminders with us is very
                inexpensive and much more flexible than using built-in EMR
                reminders, and takes a very small amount of time to setup.
              </Description>
            </TextContainer>
            <TextContainer>
              <Description>
                <span>Method 2: </span> Appointment Reminders "Upload" Service
                Application
              </Description>
              <Description>
                Use our appointment reminder upload service application to
                upload and download files securely. If you are able to generate
                a .csv or excel file that meets our standard formatting
                requirements then there is no fee for using this service.
              </Description>
              <Description>
                If you cant create a file that meets our specifications, but you
                can create a file that contains all the information that we
                need, you utilize this along with our Appointment
                Reminder Integration Service. This will allow you to upload
                files in any format any allow us to parse them on our end for a
                small monthly charge.
              </Description>
            </TextContainer>
            <TextContainer>
              <Description>
                <span>Method 3: </span> Utilize Our Appointment Reminders "API"
              </Description>
              <Description>
                The API that we offer is very simple. Essentially it allows you
                to upload and download files through your own code. We have VB
                and C# samples that you can download. However, it hould be easy
                to integrate in any of the more popular coding platforms.
              </Description>
            </TextContainer>
          </ContextContainer>
          <PictureContainer>
            <Image1 src={Back} />
            <Image2 src={Pic} />
          </PictureContainer>
        </Container>
        <Container1>
          <Heading>Allow Us to Connect to Your EMR</Heading>
          <TextContainer>
            <Description>
              We can interface with most EMRs and scheduling software using our
              integration service.
            </Description>
            <Description>
              As with all of our accounts, you are able to fully customize
              your appointment reminders, choose whether to send calls, texts,
              or emails, and accept responses from your customers.
            </Description>
            <Description>
              All of your data is secure and HIPAA Complaint throughout the
              entire process. Most EMRs will allow us to both read appointment
              information and write back with confirmations. However, some EMRs
              will only allow us to read appointment information. In this case,
              you can use several methods to view responses in real-time.
            </Description>
          </TextContainer>
        </Container1>
        <Container2>
          <ContextContainer2>
            <Heading>
              Some of the more popular EMRs that we interface with are...
            </Heading>
            <PictureContainer>
              <Image1 src={Back} />
              <Image2 src={Pic1} />
            </PictureContainer>
          </ContextContainer2>
          <ContextContainer2>
            <Heading>
              Watch a Video Demonstrating Practice Fusion Integration!
            </Heading>
            <PictureContainer>
              <Image1 src={Back} />
              <Image2 src={Pic1} />
            </PictureContainer>
          </ContextContainer2>
        </Container2>
        <Container1>
          <Heading>Appointment Reminders Upload Service</Heading>
          <TextContainer1>
            <Description>
              We know you have invested a lot of time and money in your
              appointment scheduling software. You like it, your staff likes it
              and knows how to use it.  You have no desire to switch to
              something new in order to add automated appointment reminders.
              That’s why it doesn’t matter what type of software you are
              currently using. Whether it is managed by a 3rd party or housed on
              your network, we can usually integrate it into our site.
            </Description>
          </TextContainer1>
        </Container1>
        <Container1>
          <Heading>Here’s how it works!</Heading>
          <TextContainer1>
            <Description>
              If you have a Small Business or Premium account, you can download
              and utilize our Upload Service free of charge.
            </Description>
            <Description>
              This is basically just a program that will automatically send
              files to us. If your files meet our formatting criteria for import
              files, you can simply use this program.  If your files do not meet
              our formatting criteria, then you may need to use our “Integration
              Service” in addition.
            </Description>
            <Description>
              You will install our Upload Service Windows Application on a
              computer connected to your network. This is a very simple
              bare-bones application that looks for a file periodically.  If it
              sees a file, it will connect to us through a secure encrypted
              connection and upload the file to us.  From there we will send out
              your reminders. 
            </Description>
            <Description>
              Depending on your EMR and your technical capabilities, there are a
              couple of options.  The file can be generated automatically and
              placed into a folder on your network. Or may require a very simple
              quick manual creation of the file.
            </Description>
            <Description>
              You can choose to receive automated reports whenever we receive a
              file. These reports will contain a summary of what reminders we
              added, as well as a notification if we don’t receive a file within
              a given time frame.
            </Description>
            <Description>
              There are no setup fees or contracts with our appointment reminder
              upload service and if you can upload a file that adheres to our
              import file format, there is no additional monthly charge.
            </Description>
            <Description>
              Not sure if this will work for you? Please contact us for any
              questions regarding using our upload service to send your
              appointment reminders!
            </Description>
          </TextContainer1>
        </Container1>
        <Container1>
          <Heading>Appointment Reminders Integration Service</Heading>
          <TextContainer1>
            <Description>
              You can use our Appointment Reminder Integration Service in
              conjunction with the Appointment Reminders Upload Service.
            </Description>
            <Description>
              Essentially this allows you to utilize the upload service with ANY
              file format and we can parse the file on our side.
            </Description>
            <Description>
              The cost is typically only about $100 per month. If you use over
              5000 reminders per month, we waive the integration service fee
              altogether and you get into volume pricing.
            </Description>
          </TextContainer1>
        </Container1>
        <Container1>
          <Heading>Programming API - Upload & Download Files</Heading>
          <TextContainer1>
            <Description>
              Our free web-based Programming API allows you to automate data
              transfers between your company and our site.
            </Description>
            <Heading1>
              You can use our API to create automated jobs to:
            </Heading1>
            <TextContainer>
              <Description>
                Upload customer and appointment information to our site.
              </Description>
              <Description>
                Retrieve appointment reminder results and responses
              </Description>
            </TextContainer>
            <Heading1>Technical specifications of our API:</Heading1>
            <TextContainer>
              <Description>
                Our API utilizes http methods that are available through our
                SECURE web URL.
              </Description>
              <Description>
                We have VB.NET and C# samples available for you to download for
                free. These examples utilize Microsoft’s WebClient class but you
                are
              </Description>
              <Description>
                free to use any language and method that you want. You are
                certainly not limited to these languages or methods.
              </Description>
            </TextContainer>
          </TextContainer1>
        </Container1>
        <Container1>
          <Heading>Common data transfer example utilizing our API:</Heading>
          <TextContainer>
            <Description>
              The following example describes a typical usage of our API.
            </Description>
            <Description>
              1. Create a recurring nightly job using VB.NET, C#, Java, or
              another programming language.
            </Description>
            <Description>
              2. Extract data from your EMR or Scheduling Software for patients
              who have an upcoming appointment.{" "}
            </Description>
            <Description>
              3. Create a simple .csv file with the appointment information.{" "}
            </Description>
            <Description>
              4. Upload the file securely to our site using our API.{" "}
            </Description>
            <Description>
              5. Retrieve a “Reminder Results” report for the previous day using
              our API.{" "}
            </Description>
            <Description>
              6. Parse the results and write them back into your data source.{" "}
            </Description>
          </TextContainer>
          <Heading>
            Our API is available with Small Business or Premium accounts
          </Heading>
        </Container1>
      </MainContainer>
      <Footer />
    </>
  );
};

export default AdvancedIntegration;
