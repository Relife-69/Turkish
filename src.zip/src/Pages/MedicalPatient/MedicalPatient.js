import React from "react";
import {
  MainContainer,
  Frame1,
  Heading,
  Paragraph,
  Container2,
  Paragraph1,
  Container3,
  Image,
  Paragraph2,
  Menu,
  List,
  Container4,
  Container5,
  Paragraph3,
  Frame2,
  Paragraph4,
  Frame3,
  Container6,
  Paragraph5,
  List1,
  Container7,
  Image1,
  Paragraph6,
  Frame4,
  Heading1,
  Paragraph7,
  Container8,
  Heading2,
  Heading3,
  Frame5,
  Container9,
  Heading4,
  Image2,
  Container10,
  List2,
  Image3,
  Image4,
  Image5,
  Frame6,
  Container14,
  Image7,
  Frame7,
  Image8,
  Frame10,
  Container21,
  Heading5,
  Paragraph8,
  Image11,
  Image12,
  Paragraph11,
  Image13,
  Heading6,
  SImage,
  ImageContainer1,
  ImageContainer2,
} from "./StyledMedicalPatient";
import Pic from "../../Components/Images/13.png";
import Pic1 from "../../Components/Images/13.png";
import Pic2 from "../../Components/Images/13.png";
import Pic3 from "../../Components/Images/13.png";
import Pic4 from "../../Components/Images/13.png";
import Pic5 from "../../Components/Images/13.png";
import Pic6 from "../../Components/Images/13.png";
import Pic7 from "../../Components/Images/13.png";
import Pic8 from "../../Components/Images/13.png";
import Pic9 from "../../Components/Images/13.png";
import Pic10 from "../../Components/Images/13.png";
import Pic11 from "../../Components/Images/13.png";
import Pic12 from "../../Components/Images/13.png";
import Pic13 from "../../Components/Images/13.png";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";

const MedicalPatient = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <Frame1>
          <Container2>
            <Heading>HIPAA Compliant Appointment Reminders</Heading>
            <Paragraph>Our Commitment To Privacy and Security</Paragraph>
            <Paragraph1>
              HIPAA compliance refers to adherence to the regulations and
              standards set forth by the Health Insurance Portability and
              Accountability Act of 1996 (HIPAA), a United States legislation
              that provides data privacy and security provisions for
              safeguarding medical information. The main goal of HIPAA is to
              protect sensitive patient health information from being disclosed
              without the patient’s consent or knowledge. HIPAA compliance is
              crucial for healthcare providers, health plans, healthcare
              clearinghouses, and business associates of these entities that
              have access to protected health information (PHI)
            </Paragraph1>
            <Paragraph2>
              HIPAA compliance involves several key components:
            </Paragraph2>
            <Paragraph1>
              <Menu>
                <List>
                  Privacy Rule: Sets standards for the protection of
                  individuals’ medical records and other personal health
                  information. It requires appropriate safeguards to protect the
                  privacy of personal health information and sets limits and
                  conditions on the uses and disclosures that may be made of
                  such information without patient authorization.
                </List>
                <List>
                  Security Rule: Specifies a series of administrative, physical,
                  and technical safeguards for covered entities and their
                  business associates to use to ensure the confidentiality,
                  integrity, and security of electronic protected health
                  information (e-PHI).
                </List>
                <List>
                  Enforcement Rule: Outlines the procedures for investigations
                  and penalties for HIPAA violations. It establishes the
                  processes for hearings and appeals of HIPAA violations.
                </List>
                <List>
                  Breach Notification Rule: Requires covered entities and their
                  business associates to provide notification following a breach
                  of unsecured protected health information. This includes
                  notifying affected individuals, the U.S. Department of Health
                  and Human Services (HHS), and, in some cases, the media.
                </List>
                <List>
                  Omnibus Rule: Implemented in 2013, this rule made several
                  significant updates to HIPAA in accordance with the Health
                  Information Technology for Economic and Clinical Health
                  (HITECH) Act. It expanded many of the requirements to business
                  associates of covered entities, increased penalties for
                  non-compliance, and set new guidelines for breach
                  notifications based on the risk of harm.
                </List>
              </Menu>
            </Paragraph1>
          </Container2>
          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic} alt=""></Image>
              </Container3>
            </Container4>
            <Paragraph3>
              For an entity to be HIPAA compliant, it must not only adhere to
              these rules but also regularly review and update its practices in
              response to new threats to PHI security and changes in
              technology. 
            </Paragraph3>
            <Paragraph3>
              Compliance includes conducting risk assessments, implementing
              necessary policies and procedures to safeguard information,
              training employees, and ensuring that any third-party vendors
              (business associates) also comply with HIPAA requirements.
            </Paragraph3>
            <Paragraph3>
              Non-compliance can result in significant financial penalties,
              legal action, and damage to reputation.
            </Paragraph3>
          </Container5>
        </Frame1>
        <Frame2>
          <Heading>Do I Need HIPAA Compliant Appointment Reminders?</Heading>
          <Paragraph4>
            HIPAA-compliant appointment reminders are communications sent to
            patients to remind them of scheduled appointments, and they must
            adhere to the Health Insurance Portability and Accountability Act
            (HIPAA) regulations. These reminders can be in the form of phone
            calls, emails, text messages, or postcards, but regardless of the
            method, they must protect the patient’s Protected Health Information
            (PHI) and ensure privacy and confidentiality in accordance with
            HIPAA standards.
          </Paragraph4>
        </Frame2>
        <Frame3>
          <Container6>
            <Paragraph5>
              Key Features of HIPAA-Compliant Appointment Reminders
            </Paragraph5>
            <Paragraph1>
              <Menu>
                <List1>
                  Limited Information: The reminders should contain minimal
                  information. Typically, it’s advisable to include only the
                  date and time of the appointment, the healthcare provider’s
                  name, and perhaps the location. Detailed medical information
                  or the purpose of the visit should not be disclosed
                </List1>
                <List1>
                  Opt-Out Option: Patients should be given a clear and
                  straightforward way to opt-out of receiving appointment
                  reminders if they wish to do so.
                </List1>
              </Menu>
            </Paragraph1>
            <Paragraph1>
              Implementing these key features helps ensure that appointment
              reminders meet HIPAA requirements, protecting patient information
              while keeping them informed about their healthcare needs.
            </Paragraph1>
          </Container6>
          <Container6>
            <Paragraph5>
              Who Needs HIPAA-Compliant Appointment Reminders?
            </Paragraph5>
            <Paragraph1>
              Entities that need to ensure their appointment reminders are HIPAA
              compliant include:
            </Paragraph1>
            <Paragraph1>
              <Menu>
                <List1>
                  Healthcare Providers: This includes doctors, clinics,
                  hospitals, dentists, chiropractors, psychologists, and any
                  other providers of medical services who communicate with
                  patients about upcoming appointments.
                </List1>
                <List1>
                  Health Plans: Insurance companies, HMOs, Medicaid, Medicare,
                  and any organization that pays for the cost of medical care
                  and communicates with enrollees about appointments or care
                  schedules.
                </List1>
                <List1>
                  Healthcare Clearinghouses: Entities that process nonstandard
                  health information they receive from another entity into a
                  standard format or vice versa. While they might be less
                  directly involved in sending appointment reminders, they need
                  to be aware of HIPAA compliance in all communications.
                </List1>
                <List1>
                  Business Associates: These are individuals or entities that
                  perform certain functions or activities involving the use or
                  disclosure of PHI on behalf of, or provides services to, a
                  covered entity. If a business associate is responsible for
                  sending appointment reminders, they must also comply with
                  HIPAA regulations.
                </List1>
              </Menu>
            </Paragraph1>
          </Container6>
          <Container5>
            <Container4>
              <Container3>
                <Image src={Pic} alt=""></Image>
              </Container3>
            </Container4>
            <Paragraph6>
              “Anyone in the healthcare ecosystem who communicates with patients
              about their care—be it doctors, hospitals, or health plans—must
              embrace HIPAA-compliant appointment reminders as a cornerstone of
              maintaining trust and confidentiality in patient communication.”
              -Jonah Langer (AppointmentReminders.com)
            </Paragraph6>
          </Container5>
        </Frame3>
        <Frame4>
          <Container7>
            <Heading1>
              Do I Need HIPAA Compliant Appointment Reminders?
            </Heading1>
            <Paragraph7>
              HIPAA-compliant appointment reminders are communications sent to
              patients to remind them of scheduled appointments, and they must
              adhere to the Health Insurance Portability and Accountability Act
              (HIPAA) regulations. These reminders can be in the form of phone
              calls, emails, text messages, or postcards, but regardless of the
              method, they must protect the patient’s Protected Health
              Information (PHI) and ensure privacy and confidentiality in
              accordance with HIPAA standards.
            </Paragraph7>
          </Container7>
          <Container8>
            <Heading3>HIPAA Compliance</Heading3>
            <Heading2>100%</Heading2>
          </Container8>
          <Container8>
            <Heading3>Security</Heading3>
            <Heading2>100%</Heading2>
          </Container8>
          <Container8>
            <Heading3>Privacy</Heading3>
            <Heading2>100%</Heading2>
          </Container8>
          <Container8>
            <Heading3>Peace of Mind</Heading3>
            <Heading2>100%</Heading2>
          </Container8>
        </Frame4>
        <Frame5>
          <Container10>
            <Container9>
              <Heading4>ADMINSTRATIVE SAFEGUARD</Heading4>
              <Image2 src={Pic2} alt=""></Image2>
            </Container9>
            <Menu>
              <List1>
                Risk Analysis and Management: Conduct regular assessments to
                identify potential risks to PHI and implement measures to
                mitigate these risks.
              </List1>
            </Menu>
            <Menu>
              <List2>
                Security Policies and Procedures: Develop and maintain written
                security policies and procedures that address how PHI is to be
                protected.
              </List2>
              <List2>
                Workforce Training and Management: Train staff on HIPAA policies
                and procedures, and ensure that access to PHI is limited to
                employees who need it to perform their job functions.
              </List2>
              <List2>
                Incident Response and Reporting: Establish a protocol for
                responding to and reporting security incidents and breaches.
              </List2>
            </Menu>
            <Container9>
              <Heading4>Technical Safeguards</Heading4>
              <Image4 src={Pic4} alt=""></Image4>
            </Container9>
            <Menu>
              <List>
                Access Control: Implement technical policies and procedures that
                allow only authorized persons to access electronic PHI (ePHI).
                This may include unique user IDs, emergency access procedures,
                and automatic logoff mechanisms.
              </List>
              <List>
                Audit Controls: Deploy hardware, software, and/or procedural
                mechanisms to record and examine activity in information systems
                containing or using ePHI.
              </List>
              <List>
                Integrity Controls: Put measures in place to ensure that ePHI is
                not improperly altered or destroyed. Digital signatures and
                checksums are examples of mechanisms that can be used.
              </List>
              <List>
                Transmission Security: Protect ePHI that is transmitted over
                electronic networks by using encryption and secure transmission
                protocols to prevent unauthorized access.
              </List>
            </Menu>
          </Container10>
          <Container10>
            <Container9>
              <Heading4>PHYSICAL SAFEGUARDS</Heading4>
              <Image3 src={Pic3} alt=""></Image3>
            </Container9>
            <Menu>
              <List>
                Facility Access Controls: Implement measures to limit physical
                access to facilities where PHI is stored, ensuring that only
                authorized personnel can access sensitive areas.
              </List>
              <List>
                Workstation and Device Security: Ensure that workstations and
                electronic devices are secure and that PHI is not accessible to
                unauthorized individuals.
              </List>
              <List>
                Device and Media Controls: Manage the receipt, movement, and
                disposal of electronic devices and media to ensure the
                protection of PHI.
              </List>
            </Menu>
            <Container9>
              <Heading4>Business Associate Agreements (BAAs)</Heading4>
              <Image5 src={Pic5} alt=""></Image5>
            </Container9>
            <Menu>
              <List1>
                Business Associate Agreements: Ensure that business associates
                who handle PHI on your behalf are also compliant with HIPAA
                regulations, typically enforced through Business Associate
                Agreements (BAAs).
              </List1>
            </Menu>
            <Container4>
              <ImageContainer1>
                <SImage src={Pic} alt=""></SImage>
              </ImageContainer1>
            </Container4>
          </Container10>
        </Frame5>
        <Frame6>
          <Container14>
            <Heading>HIPAA COMPLIANT APPOINTMENT REMINDERS</Heading>
            <Paragraph1>
              <Menu>
                <List>
                  We specialize in HIPAA Compliant Appointment Reminders for
                  patients. Data security and privacy are at the forefront of
                  technology, especially where medical records and information
                  are concerned.
                </List>
                <List>
                  We take extra steps to ensure that any data you share with us
                  is secure, private, and confidential.
                  <Menu>
                    <List1>
                      NEVER share your company data or your patients data
                    </List1>
                    <List1>
                      Only store the minimal data required to send your HIPAA
                      compliant appointment reminders
                    </List1>
                    <List1>Encrypt your data when in transit and at rest</List1>
                    <List1>Delete your data when no longer needed</List1>
                    <List1>Follow all additional HIPAA guidelines</List1>
                    <List1>
                      Sign a BAA(Business Associate Agreement) with you. We can
                      typically sign yours as well if you have your own BAA that
                      you prefer to use.
                    </List1>
                  </Menu>
                </List>
                <List>
                  We specialize in HIPAA Compliant Appointment Reminders for
                  patients. Data security and privacy are at the forefront of
                  technology, especially where medical records and information
                  are concerned.
                </List>
              </Menu>
            </Paragraph1>
          </Container14>
          <Container5>
            <Container4>
              <ImageContainer1>
                <SImage src={Pic} alt=""></SImage>
              </ImageContainer1>
            </Container4>
          </Container5>
        </Frame6>
        <Frame6>
          <Container14>
            <Heading>HIPAA COMPLAINT DATA STORAGE</Heading>
            <Paragraph1>
              <Menu>
                <List>
                  Our HIPAA Compliant data centers are housed in the United
                  States. All transmissions to and from our data centers use
                  high level encryption to keep your data safe in transit.
                  <Menu>
                    <List1>
                      Our database and web servers are stored securely in the
                      USA with our HIPAA Compliant data partner HIPAA Vault
                    </List1>
                    <List1>
                      HIPAA Vault maintains data centers in multiple geographic
                      locations within the United States including San Diego, CA
                      and Phoenix, AZ.
                    </List1>
                    <List1>
                      Etica Inc. dba HIPAA Vault Makes the Inc. 5000 list of
                      America’s Fastest Growing Companies
                    </List1>
                  </Menu>
                </List>
                <List>
                  We only require the minimum amount of data necessary to send
                  your HIPAA compliant appointment reminders.
                </List>
                <List>
                  We will work with you to build your patient
                  appointment reminders in a way that provides maximum HIPAA
                  compliance.  This is done by only sending the minimum
                  information to your patients about their appointments and
                  never sending specifics about the appointment or any kind of
                  diagnosis information.
                </List>
                <List>
                  If and when you cancel your appointmentreminders.com account,
                  we will completely erase all of your company and patient data.
                </List>
              </Menu>
            </Paragraph1>
          </Container14>
          <Container5>
            <Container4>
              <ImageContainer1>
                <SImage src={Pic} alt=""></SImage>
              </ImageContainer1>
            </Container4>
          </Container5>
        </Frame6>
        <Frame6>
          <Container14>
            <Heading>HIPAA COMPLIANT COMMOUNCATION</Heading>
            <Paragraph1>
              <Menu>
                <List>
                  We are proud to offer HIPAA Compliant Twilio powered call,
                  texts, and emails.
                </List>
                <List>
                  Twilio’s HIPAA-compliant solution is designed to meet the
                  needs of healthcare organizations that handle protected health
                  information (PHI). By adhering to the Health Insurance
                  Portability and Accountability Act (HIPAA) regulations, Twilio
                  provides a framework that enables secure and compliant
                  communication solutions for healthcare providers, payers, and
                  technology companies within the healthcare industry. Here are
                  key aspects of Twilio’s HIPAA-compliant offerings:
                </List>
                <List>
                  Security and Compliance Features
                  <Menu>
                    <List1>
                      Data Protection: Twilio implements robust security
                      measures, including encryption of PHI in transit and at
                      rest, to ensure that sensitive health information is
                      adequately protected against unauthorized access.
                    </List1>
                    <List1>
                      Access Controls and Audit Trails: Twilio provides features
                      for managing access controls and maintaining audit trails,
                      which are essential for compliance with HIPAA
                      requirements. These features help healthcare organizations
                      control who has access to PHI and track how PHI is
                      accessed and used.
                    </List1>
                  </Menu>
                </List>
                <List>
                  Use Cases in Healthcare
                  <Menu>
                    <List1>
                      Telehealth: Twilio’s HIPAA-compliant solutions are widely
                      used in telehealth applications, enabling secure and
                      efficient communication between patients and healthcare
                      providers.
                    </List1>
                    <List1>
                      Patient Engagement: Healthcare organizations leverage
                      Twilio to send appointment reminders, health tips, and
                      other communications that improve patient engagement while
                      adhering to HIPAA regulations.
                    </List1>
                    <List1>
                      Operational Efficiency: Twilio can also be used to
                      streamline operations, such as automating call centers and
                      improving communication flows within healthcare
                      organizations.
                    </List1>
                  </Menu>
                </List>
              </Menu>
            </Paragraph1>
          </Container14>
          <Container5>
            <Container4>
              <ImageContainer1>
                <SImage src={Pic} alt=""></SImage>
              </ImageContainer1>
            </Container4>
          </Container5>
        </Frame6>
        <Frame6>
          <Container14>
            <Heading>SECURE ENCRYPTED CONNECTION</Heading>
            <Paragraph1>
              A secure encrypted connection is a method of transmitting data
              between two systems (such as a user’s computer and a website’s
              server) in a way that the data is converted into a coded form.
              This encryption ensures that the information cannot be easily
              understood or accessed by unauthorized parties, even if they
              manage to intercept the data during its transmission. 
            </Paragraph1>
            <Paragraph1>
              Encryption transforms readable data (plaintext) into an unreadable
              format (ciphertext) using an algorithm and an encryption key. Only
              those with the corresponding decryption key can convert the data
              back into its original, readable form.
            </Paragraph1>
            <Heading>END-TO-END ENCRYPTION</Heading>
            <Paragraph1>
              <Menu>
                <List1>
                  End-to-end encryption ensures that data is encrypted on the
                  sender’s system and only decrypted by the recipient, with no
                  intermediaries being able to decrypt the data at any point in
                  between.
                </List1>
              </Menu>
              Secure encrypted connections are foundational to online security
              and privacy, especially in communications over the internet, where
              data can pass through multiple points and be exposed to potential
              interception. 
              <Menu>
                <List1>
                  Any time you connect to our website to view patient reminder
                  data, you are connecting through a secure, encrypted
                  connection. This is also true with our integration service and
                  web API.
                </List1>
                <List1>
                  Our data is transmitted through the most current version
                  of TLS Encryption and never sent using plain, open text.
                </List1>
                <List1>
                  For more advanced setups we can provide you with an SFTP to
                  upload files
                </List1>
                <List1>
                  No matter how you connect, your data is always secure and
                  encrypted
                </List1>
              </Menu>
            </Paragraph1>
          </Container14>
          <Container5>
            <Container4>
              <ImageContainer1>
                <SImage src={Pic} alt=""></SImage>
              </ImageContainer1>
            </Container4>
          </Container5>
        </Frame6>
        <Frame10>
          <Frame7>
            <Container21>
              <Heading5>WE TAKE CARE OF YOUR PATIENTS</Heading5>
              <Paragraph8>
                “Our system extends beyond simple appointment reminders; we also
                offer notifications for diagnostic screenings, annual check-ups,
                and more, supporting your efforts in patient compliance and
                preventive care.”
              </Paragraph8>
              <Container5>
                <Container4>
                  <ImageContainer2>
                    <SImage src={Pic} alt=""></SImage>
                  </ImageContainer2>
                </Container4>
                <Paragraph11>
                  Our service streamlines the process of reminding your patients
                  about their appointments, making it simpler and more efficient
                  than ever before. In today’s digital age, 
                  <span>
                    patients not only appreciate but often expect to receive
                    appointment reminders.
                  </span>
                   This communication is crucial, not just for the sake of
                  convenience but also as a proactive step in patient care
                  management.
                </Paragraph11>
                <Paragraph11>
                   <span>Preventive healthcare</span> plays a vital role in
                  avoiding serious health issues down the line. While patients
                  bear some responsibility for their health, healthcare
                  providers are instrumental in promoting adherence to
                  recommended care plans.
                </Paragraph11>
                <Paragraph11>
                   Our system extends beyond simple appointment reminders; we
                  also offer notifications for diagnostic screenings, annual
                  check-ups, and more, supporting your efforts in patient
                  compliance and preventive care.
                </Paragraph11>
                <Paragraph11>
                  Our platform offers the unique ability to tailor reminders to
                  specific types of appointments. Whether it’s informing new
                  patients about the need to arrive early for paperwork or
                  reminding others to fast before a lab test, our service
                  ensures the right message gets to the right patient. We even
                  provide options to include links for downloading necessary
                  forms, streamlining the preparation process for both patients
                  and healthcare providers.
                </Paragraph11>
                <Paragraph11>
                   
                  <span>
                    Leveraging information directly from your Electronic Medical
                    Records (EMR)
                  </span>
                  , our service automatically sends out customized patient
                  reminders based on the appointment type. This flexibility and
                  customization far exceed the capabilities of standard reminder
                  systems integrated into most EMRs.
                </Paragraph11>
                <Paragraph11>
                  Setting up your account for automation is a one-time process
                  that significantly reduces the need for manual intervention
                  afterward. Our goal is to make patient communication
                  effortless for you, allowing you to focus more on providing
                  top-notch care.
                </Paragraph11>
              </Container5>
              <Container4>
                <ImageContainer2>
                  <SImage src={Pic} alt=""></SImage>
                </ImageContainer2>
              </Container4>
            </Container21>
            <Container21>
              <Heading5>WE TAKE CARE OF YOUR PATIENTS</Heading5>
              <Container5>
                <Container4>
                  <ImageContainer2>
                    <SImage src={Pic} alt=""></SImage>
                  </ImageContainer2>
                </Container4>
                <Paragraph11>
                  Automated call, text, and email HIPAA-compliant appointment
                  reminders offer a myriad of benefits for a busy medical
                  office, streamlining operations, enhancing patient
                  communication, and improving overall healthcare delivery.
                  Here’s how they help:
                </Paragraph11>
                <Heading6>1. Improves Appointment Attendance Rates</Heading6>
                <Paragraph11>
                    Automated reminders significantly reduce no-show rates by
                  ensuring patients are aware of their upcoming appointments.
                  Timely reminders can prompt patients to confirm, cancel, or
                  reschedule their appointments, allowing medical offices to
                  optimize their schedules and reduce gaps in their daily
                  appointments.
                </Paragraph11>
                <Heading6>
                  2. Saves Time and Reduces Administrative Burden
                </Heading6>
                <Paragraph11>
                    The automation of appointment reminders offloads a
                  substantial amount of work from the administrative staff, who
                  would otherwise spend a considerable amount of time making
                  phone calls or sending manual messages. This efficiency allows
                  staff to focus on more critical tasks, improving the overall
                  productivity of the office.
                </Paragraph11>
                <Heading6>
                  3. Enhances Patient Satisfaction and Engagement
                </Heading6>
                <Paragraph11>
                  By accommodating patient preferences for communication—whether
                  through calls, texts, or emails—automated reminders cater to a
                  broader range of patients. This flexibility improves patient
                  satisfaction by making interactions with the medical office
                  more convenient and personalized. Additionally, regular
                  reminders can enhance patient engagement by keeping them
                  informed and involved in their healthcare journey.
                </Paragraph11>
                <Heading6>4. Reduces Errors and Improves Accuracy</Heading6>
                <Paragraph11>
                  Automated systems minimize the risk of human error in
                  appointment reminders. By integrating with Electronic Medical
                  Records (EMR) systems, these automated reminders ensure that
                  the right message is delivered to the right patient at the
                  right time, improving the accuracy of patient communications. 
                  Our service is far more efficient, flexible, and cost
                  effective than appointment reminders that are built-in to
                  EMRs. 
                </Paragraph11>
                <Heading6>
                  5. Supports Preventive Care and Treatment Adherence
                </Heading6>
                <Paragraph11>
                  Beyond just appointment reminders, automated systems can
                  remind patients of upcoming screenings, vaccinations, and
                  follow-up care, which are essential for preventive care and
                  managing chronic conditions. This consistent communication
                  helps in maintaining treatment adherence, significantly
                  impacting patient health outcomes. 
                </Paragraph11>
                <Heading6>6. Increases Revenue and Reduces Costs</Heading6>
                <Paragraph11>
                  By minimizing no-shows and optimizing the appointment
                  schedule, automated reminders can directly increase the
                  revenue of a medical office. Additionally, the reduction in
                  administrative workload can lead to cost savings by decreasing
                  the need for additional staff to manage patient
                  communications.
                </Paragraph11>
              </Container5>
            </Container21>
          </Frame7>
        </Frame10>
      </MainContainer>
      <Footer />
    </>
  );
};

export default MedicalPatient;
