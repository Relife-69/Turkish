import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  padding: 30px 0px;
  gap: 10px;
`;
export const Frame1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
  gap: 10px;
  @media (max-width: 900px) {
    width: 95%;
  }
  @media (max-width: 750px) {
    flex-wrap: wrap;
  }
`;
export const Heading = styled.h1`
  font-size: 29px;
  color: #1376f8;
  align-items: center;
  font-weight: 700;
`;
export const Paragraph = styled.p`
  font-size: 15px;
  color: #023e8a;
  align-items: center;
  font-weight: 700;
`;
export const Container2 = styled.div`
  align-items: start;
  justify-content: left;
  gap: 30px;
  flex-direction: column;
  max-width: 600px;
`;
export const Paragraph1 = styled.p`
  font-size: 13px;
  color: black;
  align-items: center;
  font-weight: 500;
`;
export const Container3 = styled.div`
  align-items: center;
  display: flex;
  justify-content: end;
  width: 350px;
  height: 350px;
  background-color: #1376f8;
  border-radius: 50%;
  @media (max-width: 400px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 250px;
    height: 250px;
  }
`;
export const ImageContainer1 = styled.div`
  align-items: center;
  display: flex;
  justify-content: end;
  width: 350px;
  height: 350px;
  background-color: #1376f8;
  border-radius: 50%;
  @media (max-width: 800px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 400px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 230px;
    height: 230px;
  }
`;
export const ImageContainer2 = styled.div`
  align-items: center;
  display: flex;
  justify-content: end;
  width: 350px;
  height: 350px;
  background-color: white;
  border-radius: 50%;
  @media (max-width: 800px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 400px) {
    width: 300px;
    height: 300px;
  }
  @media (max-width: 350px) {
    width: 230px;
    height: 230px;
  }
`;
export const Image = styled.img`
  width: 390px;
  height: 380px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 20px;
  top: 50px;
  @media (max-width: 400px) {
    width: 340px;
    height: 330px;
    right: 10px;
    top: 30px;
  }
  @media (max-width: 350px) {
    width: 280px;
    height: 270px;
    right: 10px;
    top: 30px;
  }
`;
export const SImage = styled.img`
  width: 390px;
  height: 380px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 20px;
  top: 50px;
  @media (max-width: 800px) {
    width: 340px;
    height: 330px;
    right: 10px;
    top: 30px;
  }
  @media (max-width: 400px) {
    width: 340px;
    height: 330px;
    right: 10px;
    top: 30px;
  }
  @media (max-width: 350px) {
    width: 280px;
    height: 270px;
    right: 10px;
    top: 30px;
  }
`;
export const Paragraph2 = styled.p`
  font-size: 14px;
  color: #1376f8;
  align-items: center;
  font-weight: 700;
`;
export const Menu = styled.ul`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
`;
export const List = styled.li`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
  list-style: decimal;
`;
export const Container4 = styled.div`
  display: flex;
  flex-direction: column;
  width: 400px;
  margin-bottom: 100px;
  justify-content: center;
  align-items: center;
  @media (max-width: 400px) {
    width: 350px;
    margin-bottom: 50px;
  }
  @media (max-width: 350px) {
    width: 280px;
  }
`;
export const Container5 = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;
export const Paragraph3 = styled.p`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
`;
export const Frame2 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  flex-direction: column;
  width: 80%;
  @media (max-width: 1100px) {
    flex-wrap: wrap;
  }
`;
export const Paragraph4 = styled.p`
  font-size: 13px;
  color: black;
  align-items: center;
  font-weight: 500;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
export const Frame3 = styled.div`
  justify-content: center;
  align-items: start;
  display: flex;
  gap: 50px;
  width: 80%;
  @media (max-width: 1100px) {
    flex-wrap: wrap;
  }
`;
export const Container6 = styled.div`
  align-items: start;
  justify-content: start;
  flex-direction: column;
  max-width: 350px;
  display: flex;
`;
export const Paragraph5 = styled.p`
  font-size: 20px;
  color: #023e8a;
  align-items: start;
  font-weight: 700;
`;
export const List1 = styled.li`
  font-size: 14px;
  align-items: start;
  font-weight: 500;
  list-style: circle;
`;

export const Image1 = styled.img`
  width: 400px;
  height: 350px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Paragraph6 = styled.p`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
  display: flex;
  justify-content: center;
  text-align: center;
`;
export const Frame4 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  gap: 30px;
  width: 100%;
  padding: 30px 0px;
  background-color: #1376f8;
  flex-direction: column;
`;
export const Heading1 = styled.h1`
  font-size: 29px;
  color: white;
  align-items: center;
  font-weight: 700;
  display: flex;
  text-align: center;
  align-items: center;
`;
export const Paragraph7 = styled.p`
  font-size: 13px;
  color: white;
  align-items: center;
  font-weight: 500;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
export const Container7 = styled.div`
  align-items: center;
  padding: 30px 0px;
  display: flex;
  justify-content: center;
  flex-direction: column;
  width: 80%;
`;
export const Container8 = styled.div`
  align-items: center;
  display: flex;
  justify-content: space-between;
  width: 80%;
  height: 70px;
  border-radius: 30px;
  background-color: white;
  padding: 10px 30px;
  @media (max-width: 600px) {
    width: 90%;
  }
  gap: 10px;
`;
export const Heading2 = styled.h1`
  font-size: 29px;
  color: #1376f8;
  font-weight: 700;
  display: flex;
`;
export const Heading3 = styled.h1`
  font-size: 29px;

  font-weight: 700;
  display: flex;
`;
export const Frame5 = styled.div`
  padding-top: 30px;
  justify-content: space-between;
  align-items: start;
  display: flex;
  width: 80%;
  gap: 30px;
  @media (max-width: 700px) {
    flex-wrap: wrap;
  }
`;
export const Container9 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  gap: 10px;
`;
export const Container10 = styled.div`
  justify-content: Start;
  align-items: center;
  display: flex;
  flex-direction: column;
  width: 45%;
  @media (max-width: 700px) {
    width: 100%;
  }
`;
export const Heading4 = styled.h2`
  color: #023e8a;
  font-size: 28px;
  font-weight: 700;
`;
export const Image2 = styled.img`
  width: 50px;
  height: 50px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const List2 = styled.li`
  font-size: 14px;
  align-items: center;
  font-weight: 500;
  list-style: lower-alpha;
`;
export const Image3 = styled.img`
  width: 50px;
  height: 50px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Container11 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  gap: 10px;
  width: 601px;
`;
export const Container12 = styled.div`
  justify-content: Start;
  align-items: center;
  display: flex;
  flex-direction: column;
  width: 601px;
`;
export const Image4 = styled.img`
  width: 50px;
  height: 50px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Image5 = styled.img`
  width: 50px;
  height: 50px;
  background-color: #1376f8;
  border-radius: 50%;
`;
export const Image6 = styled.img`
  width: 200px;
  height: 200px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Frame6 = styled.div`
  justify-content: space-between;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
  @media (max-width: 850px) {
    flex-wrap: wrap;
  }
`;
export const Frame7 = styled.div`
  justify-content: space-between;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 90%;
  @media (max-width: 1100px) {
    flex-wrap: wrap;
  }
`;
export const Container13 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container14 = styled.div`
  justify-content: start;
  align-items: start;
  display: flex;
  width: 50%;
  flex-direction: column;
  @media (max-width: 800px) {
    width: 100%;
  }
`;
export const Image7 = styled.img`
  width: 400px;
  height: 400px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;

export const Container16 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container15 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  width: 674px;
  flex-direction: column;
`;
export const Image8 = styled.img`
  width: 400px;
  height: 400px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Frame8 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container18 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container17 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  width: 674px;
  flex-direction: column;
`;
export const Image9 = styled.img`
  width: 400px;
  height: 400px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Frame9 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container20 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  gap: 30px;
  width: 80%;
`;
export const Container19 = styled.div`
  justify-content: Start;
  align-items: start;
  display: flex;
  width: 674px;
  flex-direction: column;
`;
export const Image10 = styled.img`
  width: 400px;
  height: 400px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Frame10 = styled.div`
  justify-content: center;
  align-items: center;
  display: flex;
  width: 100%;
  padding: 30px 0px;
  background-color: #1376f8;
`;
export const Container22 = styled.div`
  justify-content: center;
  align-items: center;
  flex-direction: column;
  display: flex;
  width: 80%;
`;
export const Container21 = styled.div`
  justify-content: start;
  align-items: start;
  display: flex;
  width: 586px;
  flex-direction: column;
  @media (max-width: 1100px) {
    width: 100%;
    justify-content: center;
    align-items: center;
  }
`;
export const Heading5 = styled.h1`
  font-size: 29px;
  color: white;
  align-items: center;
  font-weight: 700;
`;
export const Paragraph8 = styled.p`
  font-size: 13px;
  color: white;
  font-weight: 500;
  display: flex;
  flex-direction: column;
`;
export const Image11 = styled.img`
  width: 421px;
  height: 419px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Image12 = styled.img`
  width: 421px;
  height: 419px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Container23 = styled.div`
  align-items: center;
  display: flex;
  justify-content: center;
  width: 347px;
  height: 347px;
  background-color: white;
  border-radius: 50%;
`;
export const Paragraph11 = styled.p`
  font-size: 13px;
  color: white;
  align-items: center;
  font-weight: 500;
  span {
    color: white;
    text-decoration: underline;
  }
`;
export const Image13 = styled.img`
  width: 421px;
  height: 419px;
  border-radius: 50%;
  border: none;
  position: relative;
  right: 60px;
  top: 60px;
`;
export const Heading6 = styled.h2`
  color: white;
  font-size: 18px;
  font-weight: 700;
`;
