import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  gap: 50px;
  padding: 40px 0px;
`;

export const ContextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 80%;
`;

export const UserContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  flex-wrap: wrap;
  justify-content: space-between;
`;
export const UserProfile = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;
export const UserProfilePic = styled.img`
  width: 50px;
  height: 50px;
  border-radius: 50%;
`;
export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 5px;
  flex-direction: column;
`;
export const UserHeading = styled.div`
  font-size: 18px;
  font-weight: 600;
  margin: 0%;
`;
export const Time = styled.p`
  font-size: 14px;
  font-weight: 500;
  margin: 0%;
`;
export const SocialMediaContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;
export const SocialMedia = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #1376f8;
  width: 50px;
  height: 50px;
  border-radius: 8px;
`;
export const SocialImage = styled.img`
  width: 30px;
  height: 30px;
`;
export const Heading = styled.h1`
  font-size: 28px;
  font-weight: 600;
  color: #1376f8;
  span {
    color: white;
  }
`;
export const Description = styled.p`
  font-size: 18px;
  font-weight: 500;
  margin: 0%;
`;
export const PictureContainer = styled.div`
  width: 80%;
  height: 60vh;
  background-image: ${({ background }) => background};
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  position: relative;
`;
export const Button = styled.button`
  width: 260px;
  height: 50px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  border: none;
  font-size: 20px;
  font-weight: 600;
  background-color: #1376f8;
  &:hover {
    color: #1376f8;
    border: 2px solid #1376f8;
    background-color: white;
  }
`;
