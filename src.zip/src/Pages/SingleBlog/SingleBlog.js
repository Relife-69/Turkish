import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  ContextContainer,
  Button,
  Description,
  Heading,
  MainContainer,
  PictureContainer,
  UserProfile,
  UserProfilePic,
  TextContainer,
  UserHeading,
  SocialMediaContainer,
  SocialImage,
  Time,
  UserContainer,
  SocialMedia,
} from "./StyledSingleBlog";
import Pic from "../../Components/Images/29.png";
import Pic1 from "../../Components/Images/30.png";
import Pic2 from "../../Components/Images/31.png";
import Pic3 from "../../Components/Images/32.png";
import Pic4 from "../../Components/Images/33.png";
import Pic5 from "../../Components/Images/34.png";
import Pic6 from "../../Components/Images/35.png";
import Pic7 from "../../Components/Images/36.png";
import Pic8 from "../../Components/Images/37.png";
import { Link } from "react-router-dom";

const SingleBlog = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <Heading>Is Text Messaging Dead?</Heading>
          <UserContainer>
            <UserProfile>
              <UserProfilePic src={Pic2} />
              <TextContainer>
                <UserHeading>Don S. Gregg</UserHeading>
                <Time>20 June 2024</Time>
              </TextContainer>
            </UserProfile>
            <SocialMediaContainer>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic3} />
                </Link>
              </SocialMedia>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic4} />
                </Link>
              </SocialMedia>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic5} />
                </Link>
              </SocialMedia>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic6} />
                </Link>
              </SocialMedia>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic7} />
                </Link>
              </SocialMedia>
              <SocialMedia>
                <Link>
                  <SocialImage src={Pic8} />
                </Link>
              </SocialMedia>
            </SocialMediaContainer>
          </UserContainer>
        </ContextContainer>
        <PictureContainer background={`url(${Pic})`}>
          <Heading>
            <span>
              Some would say it is...where did it go??...what will replace
              it??....
            </span>
          </Heading>
        </PictureContainer>
        <ContextContainer>
          <Description>
            Text messaging is dead—or so they say. Imagine a world where the
            simple SMS is a ghost, overshadowed by the vibrant, interactive
            world of WhatsApp, Facebook Messenger, and Telegram. These apps
            offer a dazzling array of features: multimedia sharing, group chats,
            voice and video calls, and encryption, leaving the humble text
            message in the dust.
          </Description>
        </ContextContainer>
        <PictureContainer background={`url(${Pic1})`}>
          <Heading>
            <span>What Will Replace Text Messaging?</span>
          </Heading>
          <Button>Read more</Button>
        </PictureContainer>
        <ContextContainer>
          <Description>
            Social media platforms like Instagram, Snapchat, and Twitter lure us
            in with the promise of integrated messaging and social networking,
            creating a web of connections that SMS can’t match. The convenience
            of services that combine messaging with payments, gaming, and
            shopping makes traditional texts seem ancient in comparison.
          </Description>
          <Description>
            In our globally connected world, internet-based messaging is a siren
            song—cheaper, especially for international communication, and packed
            with engaging features like memes, stickers, and GIFs. The younger
            generations are captivated, leaving the simple text message behind
            like a relic of the past.
          </Description>
          <Description>
            Businesses have joined the exodus too, turning to apps and social
            media for customer service, marketing, and engagement, making SMS
            feel like a forgotten whisper.
          </Description>
          <Description>
            Yet, is it truly dead? In regions with limited internet access or
            for purposes like two-factor authentication and emergency alerts,
            text messaging lingers on, a ghostly reminder of what once was. Is
            the humble SMS gone for good, or does it still have a place in our
            ever-evolving digital landscape? The answer may surprise you.
          </Description>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default SingleBlog;
