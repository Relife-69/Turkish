import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import Subscription from "../Subscription/Subscription";
import {
  ContextContainer,
  Description,
  Heading,
  Heading1,
  Heading2,
  Image1,
  Image2,
  Image3,
  MainContainer,
  PictureContainer,
  PictureContainer2,
  TextContainer,
} from "./StyledPricing";
import Pic from "../../Components/Images/Background.png";
import Pic1 from "../../Components/Images/13.png";
import Pic2 from "../../Components/Images/14.png";
import Pic3 from "../../Components/Images/15.png";
import Pic4 from "../../Components/Images/16.png";
const Pricing = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <TextContainer>
            <Heading>PRICING</Heading>
            <Heading1>Pricing - Accounts Starting at $9.95 Per Month</Heading1>
            <Heading1>Best Prices in the Industry!</Heading1>
            <Heading2>As Low as 5 Cents ($0.05 U.S.) Per Reminder</Heading2>
            <Description>
              We specialize in Appointment Reminders so you don’t pay for extra
              services that you don’t need.
            </Description>
            <Description>
              Never pay for failed appointment reminders and roll failed texts
              to calls at no extra cost!
            </Description>
            <Description>
              No Hidden Fees: Businesses can plan their budgets effectively
              without worrying about unexpected charges.
            </Description>
            <Description>
              No Contracts! There are No Contracts so you can Cancel Any
              Time and you can change tiers any time with the push of a button.
            </Description>
            <Description>
              Volume Discounts: For over 5k Reminders per month.
            </Description>
            <Description>
              In 2024 we conducted an in-depth comparison of the most popular
              appointment reminder services and easily came out on top for
              pricing, features, and customer service!
            </Description>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Pic} />
            <Image2 src={Pic2} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer>
          <PictureContainer2>
            <Image1 src={Pic} />
            <Image3 src={Pic1} />
          </PictureContainer2>
          <TextContainer>
            <Heading>Choose Your Level (Tier)</Heading>
            <Heading1>Starting at Only $9.95 Per Month</Heading1>
            <Description>
              We have 4 different account tiers so you can choose the right one
              for your company. AppointmentReminders.com structures
              its appointment reminder pricing to offer a range of plans that
              cater to various business sizes and needs, from small practices to
              large enterprises. This flexibility ensures that businesses only
              pay for what they need, making the service accessible to a wider
              range of customers.
            </Description>
            <Description>
              Choose from one of our packages starting at only $9.95 per month.
              Our Highly-Secure, HIPAA Compliant packages start at only $99.95
              per month.
            </Description>
            <Description>
              As a business grows, it can move to a higher tier plan that meets
              its expanding needs without experiencing a sharp increase in
              costs. This scalability helps maintain cost efficiency as
              businesses evolve.
            </Description>
            <Description>
              We offer free Hands-On Account Set-Up and Support from
              our Headquarters in Denver, CO with ALL Account Tiers!
            </Description>
          </TextContainer>
        </ContextContainer>
        <ContextContainer>
          <TextContainer>
            <Heading>No Contracts and No Risk!</Heading>
            <Heading1>No Contracts, No Hidden Fees, Free 30 Day Trial</Heading1>
            <Description>
              There are No Hidden Fees, setup charges, cancellation charges or
              contracts.
            </Description>
            <Description>
              All appointment reminder account tiers come with a 30 Day Trial –
              no credit card needed (up to 30 reminders)
            </Description>
            <Description>
              We don’t believe that there is any benefit to holding a company to
              a contract if the service is not a good fit.  Our high quality
              appointment reminder service speaks for itself.
            </Description>
            <Description>
              We are sure that our services will benefit your company by
              decreasing no-shows and increasing your customers satisfaction! If
              for any reason you are unsatisfied, you don’t pay! It’s that
              simple!
            </Description>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Pic} />
            <Image2 src={Pic4} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer>
          <PictureContainer2>
            <Image1 src={Pic} />
            <Image3 src={Pic3} />
          </PictureContainer2>
          <TextContainer>
            <Heading>What is Included?</Heading>
            <Heading1>
              When we say "Reminders Per Month", what do we mean? 
            </Heading1>
            <Heading1>No Hidden Fees - Full Transparency</Heading1>
            <Description>
              All 2 Way communication is included in the price of 1 appointment
              reminder (could be up to 3 text messages)Example –We send a text
              reminder with appointment info and ask for a confirmation such as
              “reply 1 to confirm this appointment”They reply to the text with
              “1” to confirmWe send another text telling them that their
              appointment is confirmed
            </Description>
            <Description>
              Text Size Limit: Each 160 Character Count  Text Message (Including
              Spaces and Characters) constitutes 1 Reminder. However, you can
              send longer text messages for additional reminder counts.
            </Description>
            <Description>
              Email Size Limit: There is no size limit for emails and you can
              include a logo and company branding.
            </Description>
            <Description>
              Call Length Limit: There is no call length limit and you can
              generate calls from YOUR caller ID.
            </Description>
            <Description>
              Each Call, Text (160 Character Count), or Email for an appointment
              is 1 Reminder.
            </Description>
            <Description>
              Never pay for failed appointment reminders and roll failed texts
              to calls at no extra cost!
            </Description>
            <Description>
              Left Over Reminders: Do Not Roll Over to the next month.
            </Description>
            <Description>
              Sending Multiple Reminders: for one appointment counts as multiple
              reminders.
            </Description>
            <Description>
              Sending Manual Text Messages: (Sending a message and getting a
              reply) count as 1 Reminder.
            </Description>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Subscription />
      <Footer />
    </>
  );
};

export default Pricing;
