import styled from "styled-components";
export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 30px;
  width: 100%;
`;
export const ContextContainer = styled.div`
  width: 80%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
`;
export const TextContainer = styled.div`
  width: 650px;
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
`;
export const Heading = styled.h1`
  font-size: 34px;
  font-weight: 700;
  color: #1376f8;
`;
export const Heading1 = styled.h1`
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
  margin-bottom: 10px;
`;
export const Heading2 = styled.h1`
  font-size: 24px;
  font-weight: 500;
  margin: 0%;
  margin-bottom: 10px;
`;
export const Description = styled.li`
  font-size: 18px;
  font-weight: 400;
  padding-left: 10px;
  margin: 0%;
`;
export const PictureContainer = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: center;
  justify-content: end;
`;
export const Image1 = styled.img`
  width: 410px;
  height: 410px;
  border-radius: 50%;
  border: none;
  position: absolute;
`;
export const Image3 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 80px;
  position: relative;
  left: 50px;
`;
export const PictureContainer2 = styled.div`
  display: flex;
  width: 600px;
  height: 600px;
  align-items: center;
  justify-content: start;
`;
export const Image2 = styled.img`
  width: 500px;
  height: 500px;
  border-radius: 50%;
  border: none;
  top: 80px;
  position: relative;
  right: 50px;
`;
