import React from "react";
import Navbar from "../../Components/Header/Navbar";
import Footer from "../../Components/Footer/Footer";
import {
  MainContainer,
  ContextContainer,
  Description,
  Heading,
  Heading1,
  Heading2,
  Image1,
  Image2,
  Image3,
  PictureContainer,
  PictureContainer2,
  TextContainer,
} from "./StyledAboutus";
import Pic from "../../Components/Images/Background.png";
import Pic1 from "../../Components/Images/17.png";
import Pic2 from "../../Components/Images/18.png";
import Pic3 from "../../Components/Images/19.png";

const Aboutus = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <Heading>
          <span>About </span> Us
        </Heading>
        <ContextContainer>
          <TextContainer>
            <Heading1>
              Mission Statement: Offer secure, reliable Automated Appointment
              Reminders for Businesses at affordable prices.
            </Heading1>
            <Heading2>
              AppointmentReminders.com – Appointment Reminders for Businesses is
              a U.S. company headquartered in Denver, CO. We operate in the U.S.
              and Canada.
            </Heading2>
            <Heading1>
              Our specialty is HIPAA Compliant appointment reminders
            </Heading1>
            <Description>
              As a result, our data and transmissions are very secure. Whether
              you have a small practice or a very large practice spanning
              multiple locations, we have a plan that is right for you.We have
              been in operation since 2012. Since this time we have grown our
              automated appointment reminder system substantially and continue
              to improve our capabilities.
            </Description>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Pic} />
            <Image2 src={Pic1} />
          </PictureContainer>
        </ContextContainer>
        <ContextContainer>
          <PictureContainer2>
            <Image1 src={Pic} />
            <Image3 src={Pic2} />
          </PictureContainer2>
          <TextContainer>
            <Heading1>
              However, our automated appointment reminder system is perfect for
              all types of companies
            </Heading1>
            <Description>
              We work with many types of companies and industries and because of
              this, our automated appointment reminders are highly configurable.
              Some of our clients are small home-based companies such as private
              instructors, therapists, plumbers, lawn care, stylists, auto care,
              etc… and others are large medical practices.
            </Description>
          </TextContainer>
        </ContextContainer>
        <ContextContainer>
          <TextContainer>
            <Heading1>
              We do not require contracts, and do not have any setup fees.
            </Heading1>
            <Description>
              If you are not happy with us for any reason you are free to go
              elsewhere without ant contractual obligations. However, most of
              our clients tend to stick around because our automated appointment
              reminder service works!
            </Description>
            <Description>
              We also have a strict no-sharing policy when it comes to
              information about your company or your customers. Not only do we
              take measures to keep your data private and secure, we also will
              never share data with any 3rd parties such as mailing lists,
              advertisers, or media groups. 
            </Description>
            <Description>
              Most of all, we take your privacy and security very seriously. We
              only store information that is necessary to for our automated
              appointment reminders and only keep this information while you are
              using the service.
            </Description>
            <Description>
              We’d love for you to give us a shot and that is why we offer a 30
              day trial with no credit card needed.  While in the trial, we will
              help you set up your company. This ensures that you know how to
              use the service and make sure everything is correct.
            </Description>
            <Description>
              Please feel free to contact us with ANY questions that you have
              and we will get back to you right away!
            </Description>
          </TextContainer>
          <PictureContainer>
            <Image1 src={Pic} />
            <Image2 src={Pic3} />
          </PictureContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Aboutus;
