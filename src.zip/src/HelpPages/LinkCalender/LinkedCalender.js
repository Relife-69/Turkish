import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledLinkedCalender";

const LinkedCalender = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              <span>Google Calendar – Linking a Google Calendar</span>
            </HeadingContainer>
            <Heading>Google Calendar – Linking a Google Calendar</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> How Does it Work?</TextList>
              <TextList>Linking a Google Calendar</TextList>
              <TextList>Sharing Your Google Calendar With Us</TextList>
              <TextList>Obtaining Your Google Calendar ID</TextList>
              <TextList>Adding Your Google Calendar to Our Site</TextList>
              <TextList>Google Calendar Link Settings</TextList>
              <TextList>Google Calendar Read Settings</TextList>
              <TextList>Google Calendar Write Settings</TextList>
              <TextList>Save Your Settings</TextList>
            </TextMenu>
            <TextHeading>How Does it Work? </TextHeading>
            <Text>
              By linking a Google Calendar to our site, it will allow you to
              send out Reminders either by reading the first and last name of
              your customer from the appointment title, or adding a simple tag
              such as (Text admin 000000000000) in the event description.
            </Text>
            <Text>
              Currently we only support Google Calendar but you can also link
              any calendar that syncs to Google such as Week or Cozi. Linking a
              calendar is not supported in express accounts. If you have an
              express account and wish to send Google Calendar reminders, you
              will need to upgrade to a standard account.
            </Text>
            <TextHeading>Linking a Google Calendar</TextHeading>
            <Image src={User} />
            <TextHeading>Sharing Your Google Calendar With Us</TextHeading>
            <Text>
              The first step is to share your Google Calendar with us so we can
              read from it and/or write back to it.
            </Text>
            <Text>Its easy and should only take a few minutes.</Text>
            <RequirmentsList>
              1. Log into your Google account and go to the Calendars page.
            </RequirmentsList>
            <Image src={User} />
            <RequirmentsList>
              2. Click on “Settings and Sharing” for the calendar you want to
              share with us. (You can share unlimited calendars with us)
            </RequirmentsList>
            <Image src={User} />
            <ListContainer>
              <RequirmentsList>
                3. Scroll down until you find “Share with Specific People”.
              </RequirmentsList>
              <RequirmentsList>
                Click “Add People” and add the email address
                arcalendarshare@gmail.com.
              </RequirmentsList>
              <RequirmentsList>
                If you only want us to read from it, select “See all event
                details”. If you want us to write back or change event colors
                select “Make changes to events”.
              </RequirmentsList>
              <RequirmentsList>Then hit “Send”.</RequirmentsList>
            </ListContainer>
            <Image src={User} />
            <TextHeading>Obtaining Your Google Calendar ID </TextHeading>
            <Text>
              Scroll down a little further on this page and you will see a
              section that says “Integrate Calendar”. You will see a subheading
              that says “Calendar ID”. Please copy this calendar ID to your
              clipboard.
            </Text>
            <Text>
              Make sure you copy the entire ID but not the words “Calendar ID”
              and also none of the brackets.
            </Text>
            <Image src={User} />
            <TextHeading>Adding Your Google Calendar to Our Site </TextHeading>
            <Text>
              To get to the “Calendars” page, ensure that you are logged into
              your account. Then go to the “Navigation Menu”, and select “My
              Data Sources” / “Google Calendars”.
            </Text>
            <Image src={User} />
            <Text>
              When you get to the “Calendars” page, you will be presented with a
              list of all your current linked calendars. If you have not added
              any calendars then the list will be empty. You can link as many
              calendars as you want. There is no limit.
            </Text>
            <Text>Click on “Link a Google Calendar”</Text>
            <Image src={User} />
            <TextHeading>Google Calendar Link Settings</TextHeading>
            <ListContainer>
              <RequirmentsList>
                Calendar Name – Enter a friendly name for your calendar
              </RequirmentsList>
              <RequirmentsList>
                Calendar ID – Paste the Calendar ID from the “Obtaining Your
                Google Calendar ID” step.
              </RequirmentsList>
              <RequirmentsList>
                Active – You can uncheck this box if you want to disable the
                calendar but leave it linked.
              </RequirmentsList>
              <Image src={User} />
              <Text>Google Calendar Link Settings</Text>
            </ListContainer>
            <TextHeading>Google Calendar Read Settings</TextHeading>
            <ListContainer>
              <RequirmentsList>
                Read TAGs: Will look for information inside the arrows brackets.
                Click here for more info on calendar tags.
              </RequirmentsList>
              <RequirmentsList>
                Match Name: Will look for the First and Last name of your
                customer in the appointment title. Click here for more info on
                name matching.
              </RequirmentsList>
              <RequirmentsList>
                Default Reminder Type: Choose the default Reminder Type to
                associate with this calendar. You can still send different
                Reminder Types by using Calendar TAGS.
              </RequirmentsList>
              <Image src={User} />
              <Text>Google Calendar Read Settings</Text>
            </ListContainer>
            <TextHeading>Google Calendar Write Settings</TextHeading>
            <Text>
              This section will allow you to choose whether you want us to write
              back to your Google Calendar. Make sure when you shared your
              calendar with us you allowed arcalendarshare@gmail.com to “make
              changes to events”.
            </Text>
            <ListContainer>
              <RequirmentsList>
                Write Customers Responses to Event Description: Will write your
                customer’s response back to your Google Calendar event
                Description
              </RequirmentsList>
              <RequirmentsList>
                Change Event Color – Will change the color of your Google
                Calendar event based on the customers response to your reminder.
              </RequirmentsList>
              <RequirmentsList>
                First Expected Response Color – Set it to this color if the
                response matches the first expected response (from the Reminder
                Types page).
              </RequirmentsList>
              <RequirmentsList>
                Second Expected Response Color – Set it to this color if the
                response matches the second expected response (from the Reminder
                Types page).
              </RequirmentsList>
              <RequirmentsList>
                Third Expected Response Color – Set it to this color if the
                response matches the third expected response (from the Reminder
                Types page). Expected Response Color – Set it to this color if
                the response matches the first expected response (from the
                Reminder Types page).
              </RequirmentsList>
              <Image src={User} />
            </ListContainer>
            <TextHeading>Save Your Settings</TextHeading>
            <Text>
              Click the “Save and Relink Calendar Button”. We will attempt to
              link/relink your calendar with these settings.
            </Text>
            <Text>
              <Link>
                Click Here for help postings about how to add contacts and setup
                appointment reminders through calendars
              </Link>
            </Text>
            <Text>
              If you run into any trouble Linking a Calendar, please contact us
              and we will help you!
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default LinkedCalender;
