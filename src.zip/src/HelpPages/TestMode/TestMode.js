import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTestMode";

const TestMode = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Account Settings
              <MdKeyboardArrowRight />
              <span>Test Mode (Disabling Live Reminders)</span>
            </HeadingContainer>
            <Heading>Test Mode (Disabling Live Reminders)</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> To put your account in “Test Mode”</TextList>
              <TextList>
                If you have Test Mode enabled then no reminders will be sent.
              </TextList>
              <TextList>Why should I use Test Mode?</TextList>
              <TextList>
                Can I send reminders to myself while I am in Test Mode?
              </TextList>
              <TextList>
                Will appointment reminders that I create during Test Mode be
                available in Live Mode?
              </TextList>
            </TextMenu>
            <TextHeading>To put your account in “Test Mode” </TextHeading>
            <Text>
              Under the “My Account” menu, select “Test Mode/Live Mode”.
            </Text>
            <Text>Then simply enable “Test Mode”.</Text>
            <Image src={User} />
            <TextHeading>
              If you have Test Mode enabled then no reminders will be sent.
            </TextHeading>
            <TextHeading>Why should I use Test Mode?</TextHeading>
            <ListContainer>
              <RequirmentsList>
                Test Mode allows you to upload files, test reminders, or connect
                calendars without having to worry about accidentally sending
                reminders to your customers.
              </RequirmentsList>
              <RequirmentsList>
                Also, if you ever have issues with the incorrect reminders going
                out or anything else, you can put your account into test mode to
                temporarily disable them.
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              Can I send reminders to myself while I am in Test Mode?
            </TextHeading>
            <Text>
              Yes, you can test all of your reminders by triggering them in the
              <Link to="/reminder_type_help"> Reminder Types page.</Link>
            </Text>
            <TextHeading>
              Will appointment reminders that I create during Test Mode be
              available in Live Mode?{" "}
            </TextHeading>
            <Text>
              Yes. You should ensure that you have deleted any unwanted
              reminders before switching back to live mode.
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default TestMode;
