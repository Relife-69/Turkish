import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledAddingCustomers";

const AddingCustomers = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              Google Calendar
              <MdKeyboardArrowRight />
              <span>
                Google Calendar – Scheduling Appointments & Adding Customers
              </span>
            </HeadingContainer>
            <Heading>
              Google Calendar – Scheduling Appointments & Adding Customers
            </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                {" "}
                Scheduling Reminders From a Linked Google Calendar
              </TextList>
              <TextList>
                Method #1: Sending Appointment Reminders to Customers who are
                already in your Customer List
              </TextList>
              <TextList>
                Method #2: Using “Calendar Tags” in the event title or event
                description{" "}
              </TextList>
              <TextList>
                Example #1 : The minimal amount of info we need!
              </TextList>
              <TextList>
                Example #2 : Sending a “Text Message” reminder
              </TextList>
              <TextList>Example #3 : Sending a “Phone Call” reminder</TextList>
              <TextList>Example #4 : Sending a “Email” reminder</TextList>
              <TextList>
                Example #5 : Tell the system which “Reminder Type” to send out
                with “RemID=”
              </TextList>
              <TextList>Example #6 : Passing in Custom Fields. </TextList>
              <TextList>
                Custom Fields are parameters that can be passed in specific to a
                reminder such as a balance due or a room number.
              </TextList>
            </TextMenu>
            <Text>
              Schedule appointments through your Linked Google Calendars Have
              reminders go out automatically. You can also click on the link
              below for a Video Tutorial on the subject.
            </Text>
            <TextHeading>
              Scheduling Reminders From a Linked Google Calendar{" "}
            </TextHeading>
            <Image src={User} />
            <Text>
              Once you have added at least one linked google calendar through
              the website, you may immediately start using it to send your
              appointment reminder calls, texts, or emails.
            </Text>
            <Text>
              You may use your linked Google Calendars to Create Appointments
              with a Reminder and Add Customers. *You may also do this through
              the website or through import files.
            </Text>
            <Text>
              If you have an established customer base that does not change too
              often you can upload your Contact List to our site and then use
              your linked Google Calendars to schedule appointments with a
              reminder.
            </Text>
            <Text>
              If you have lot’s of new customers all the time then you should
              probably get use to adding customers on-the-fly with “Calendar
              Tags” as you schedule Appointments through your Google Calendar.
            </Text>
            <Text>You can also use a combination of both methods.</Text>
            <TextHeading>
              Method #1: Sending Appointment Reminders to Customers who are
              already in your Customer List
            </TextHeading>
            <Text>
              To determine who to send appointment reminders to, we look at the
              Event Title and the Event Description. If you have uploaded your
              contact list to our site, or manually added customers through the
              web portal, then we are able to send reminders based solely on
              whether we find a First and Last name that matches a customer in
              your contact list.
            </Text>
            <Text>
              In the example below, since the Customer “Mark Twain” already
              exists in the contact list, the only thing we need to do in order
              to send a reminder is to make sure that we add the name “Mark
              Twain” in the event title (or description) which we have done.
            </Text>
            <Text>
              To use this method check the box that says “Match Name: Look for
              the First and Last Name of your customer in the appt title” when
              you link your Google Calendar.
            </Text>
            <Image src={User} />
            <Text>First and Last Name in Title</Text>
            <TextHeading>
              Method #2: Using “Calendar Tags” in the event title or event
              description
            </TextHeading>
            <Text>
              A “Calendar Tag” is simply some keywords that are added between
              the triangular brackets (arrow brackets) and must exist in your
              calendars event title or description. You can have other text in
              the title or description as well. We only read the text between
              the brackets.
            </Text>
            <TextHeading>
              Example #1 : The minimal amount of info we need!{" "}
            </TextHeading>
            <Text>(Mark Johnson 3031234567)</Text>
            <Text>
              At a minimum, we need First Name+Last Name+Phone Number. It will
              add a customer named Mark Johnson into your customer list, set his
              Primary Phone Number as 3031234567, and send him a your default
              reminder (set up in the “Reminder Types” page).
            </Text>
            <TextHeading>
              Example #2 : Sending a “Text Message” reminder
            </TextHeading>
            <Text>If it finds the following in the Event Description</Text>
            <Text>(Mark Johnson 3031234567)</Text>
            <Text>
              It will add a customer named Mark Johnson into your customer list,
              set his Primary Phone Number as 3031234567, and send him a Text
              reminder. Important! If you use this method you can only have 1
              text reminder type set up in the “Reminder Types” page. Otherwise,
              the system will not know which text message to send out.
            </Text>
            <TextHeading>
              Example #3 : Sending a “Phone Call” reminder{" "}
            </TextHeading>
            <Text>If it finds the following in the Event Description</Text>
            <Text>(Call Mark Johnson 3031234567)</Text>
            <Text>
              It will add a customer named Mark Johnson into your customer list,
              set his Primary Phone Number as 3031234567, and send him a Call
              reminder. Important! If you use this method you can only have 1
              call reminder type set up in the “Reminder Types” page. Otherwise,
              the system will not know which call to send out.
            </Text>
            <TextHeading>Example #4 : Sending a “Email” reminder</TextHeading>
            <Text>If it finds the following in the Event Description</Text>
            <Text>(Email Mark Johnson 3031234567 markjohnson@yahoo.com)</Text>
            <Text>
              It will add a customer named Mark Johnson into your customer list,
              set his Primary Phone Number as 3031234567, set his email address
              to markjohnson@yahoo.com and send him an Email reminder.
              Important! If you use this method you can only have 1 email
              reminder type set up in the “Reminder Types” page. Otherwise, the
              system will not know which email to send out.
            </Text>
            <TextHeading>
              Example #5 : Tell the system which “Reminder Type” to send out
              with “RemID=”
            </TextHeading>
            <Text>If it finds the following in the Event Description</Text>
            <Text>(Mark Johnson 3031234567 RemID=17)</Text>
            <Text>
              It will add a customer named Mark Johnson into your customer list,
              set his Primary Phone Number as 3031234567 and send him an
              reminder where the reminder type id is 17. You can locate the
              Reminder Type ID on the “Reminder Types” page. You can also use
              the “Reminder Description” in place of the Reminder Type ID. This
              would read something like (Mark Johnson 3031234567 RemID=”My
              Reminder Type”). Please note the quotes around “My Reminder Type”.
            </Text>
            <TextHeading>Example #6 : Passing in Custom Fields.</TextHeading>
            <TextHeading>
              Custom Fields are parameters that can be passed in specific to a
              reminder such as a balance due or a room number.
            </TextHeading>
            <ListContainer>
              <Text>
                CustomField1= If it finds this TAG it will send whatever you
                have here (must be in double quotes e.g. CustomField1=”Your
                balance is $20″)
              </Text>
              <Text>
                CustomField2= If it finds this TAG it will send whatever you
                have here (must be in double quotes e.g. CustomField2=”Your
                balance is $20″)
              </Text>
              <Text>
                CustomField3= If it finds this TAG it will send whatever you
                have here (must be in double quotes e.g. CustomField3=”Your
                balance is $20″)
              </Text>
              <Text>
                YOU MUST HAVE CUSTOM FIELDS IN YOUR REMINDER TYPE IN ORDER TO
                USE THEM
              </Text>
            </ListContainer>
            <Text>
              Example 2 Below shows how to schedule an appointment through a
              Linked Google Calendar and add a TAG to allow the customer to be
              added.
            </Text>
            <Image src={User} />
            <Text>
              To use this method check the box that says “Read TAGs: Read what
              is inside the arrow brackets in the appt title or description”
              when you link your Google Calendar.
            </Text>
            <Text>Combining Title and Tags</Text>
            <Text>
              If you already have a customer in your contacts that matches a
              name in the title or description of your linked calendars event
              and you want to specify the reminder type (instead of using their
              default type) then you may add their name to the title of the
              event and specify the reminder type in a tag like in arrow
              bracket(RemId=17).
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default AddingCustomers;
