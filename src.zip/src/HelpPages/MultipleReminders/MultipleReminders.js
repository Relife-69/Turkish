import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledMultipleReminders";

const MultipleReminders = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Appointment Reminders
              <MdKeyboardArrowRight />
              <span>Creating Multiple Reminders for an Appointment</span>
            </HeadingContainer>
            <Heading>Creating Multiple Reminders for an Appointment </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>Scenarios for Creating Multiple Reminders</TextList>
              <TextList>Ok, so how do I actually do it?</TextList>
            </TextMenu>
            <TextHeading>Scenarios for Creating Multiple Reminders</TextHeading>
            <ListContainer>
              <RequirmentsList>
                You may want to send a reminder 1 week prior to the appointment
                and then another one the day before the appointment.
              </RequirmentsList>
              <RequirmentsList>
                You may want to send a text message and a call reminder for the
                same appointment.
              </RequirmentsList>
              <RequirmentsList>
                Set up a text reminder and if that fails (unable to deliver)
                send a call reminder.
              </RequirmentsList>
              <RequirmentsList>
                Send a reminder and then based on the response, send a different
                reminder. For example if someone confirms their appointment,
                maybe don’t send another reminder but if they don’t reply to the
                1st reminder, send another one the next day
              </RequirmentsList>
              <RequirmentsList>
                Send a text reminder for an appointment and then send an email
                or text after the appointment pointing them to a survey about
                the appointment.
              </RequirmentsList>
              <Text>
                These are just a few examples of some ways that you may use this
                functionality. However, our system really allows you to
                customize these settings as much as you want.
              </Text>
            </ListContainer>
            <TextHeading>Ok, so how do I actually do it?</TextHeading>
            <Text>
              To create multiple reminders for an appointment, you will need to
              set up a <Link> “Trigger”</Link>. Triggers allow you to create
              multiple reminders for an appointment or send text or email alerts
              when certain conditions are met. In addition to creating multiple
              reminders, triggers can also do a lot of other things including
              alerting you when people reply to the reminders, or do not respond
              to the reminders.
            </Text>
            <Text>
              <Link>Click Here For the forum posting on Creating Triggers</Link>
            </Text>
            <Image src={User} />
            <Text>Trigger A Failed Text To Roll To A Call</Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default MultipleReminders;
