import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTriggerTime";
const TriggerTime = () => {
  return (
    <>
    <Navbar />
     <MainContainer>
       <ContextContainer>
         <HelpSidebar />
         <TextContainer>
           <HeadingContainer>
             Home <MdKeyboardArrowRight />
             Docs <MdKeyboardArrowRight />
             Triggers

 
             <MdKeyboardArrowRight />
             <span>How to Send an Appointment One Hour Prior to Appointment Time</span>
           </HeadingContainer>
           <Heading>HOW TO SEND AN APPOINTMENT ONE HOUR PRIOR TO APPOINTMENT TIME
           </Heading>
           <TextMenu>
             <HeadingContainer> Table of Contents </HeadingContainer>
             <TextList>Step 1: Create or Modify a Reminder Type<br/>
Step 2: Schedule the Reminder<br/>
Step 3: Check the Reminder Status</TextList>
             
          
            
           </TextMenu>
           <h1>Youtube Video</h1>
           <Text>With appointment reminders.com, you have the ability to send multiple reminders for an appointment. For example, you can send a reminder a week prior, another one two days prior, and even send one on the day of the actual appointment.<br/>

If you choose to send one on the day of the appointment, our service even lets you decide how many hours prior to the appointment time you want to send the reminder. This is a great way to send your customers a last minute reminder for their appointment.<br/>

In this tutorial, I will guide you through the process of sending a reminder one hour before the appointment.
 
 
           </Text>
           
           
           <TextHeading>
           Step 1: Create or Modify a Reminder Type

        
           </TextHeading>
           <Text>
           The first thing we need to do is set up or modify an existing reminder type. <br/>

Navigate to the reminder types page by hovering over the navigation menu and then selecting Reminder Settings, General Reminder Settings, Reminder Types. Then click on “Create a New Reminder Type”. If you already have one set up then you can just modify it.

<br/>For Description select something like “Text One Hour Before Appointment Time” just so the name of the Reminder Type matches what you are doing.

<br/>For Outreach Type select whether this will be a Text Message, Email, or Call. 

<br/>For Time Frame Options only select “On Appointment Date”. Then select 1 for “Hours Before Appointment Time”. You can set this to any amount prior to the appointment time.  Keep in mind that your “Reminder Settings” will override this setting.

<br/>Choose whether to use the default caller ID for this Reminder Type and choose your reminder content based on the settings. You can see in the preview pane what the reminder content will say.

<br/>Click submit to save it. If you want to review or change these settings, you can do this by clicking on the “Settings” button. If you want to review or change the content, you can do this by clicking on the “Content Button”. 
 
<h1>Image1</h1>
           </Text>
           <TextHeading>Step 2: Schedule the Reminder
           </TextHeading>
           <Text>
           Now you can send this reminder in several ways. For Example, you can trigger this reminder when another reminder is added – say a text message 2 days prior to the appointment. You can also just schedule this reminder through a linked Google Calendar, Upload files, or scheduling it through the website.

           <br/>For this tutorial, I will just show you how to schedule it through the website.

           <br/>I will go to the Customers Page by hovering over the navigation menu and then going to “My Customers, Customers/Patients”. Then I will find the customer I want to send the reminder to, click on View/Add reminders. 
           <h1>Image2</h1>
           </Text>
           
           <Text>
           Then click “Add New Reminder”. Then I will select the Reminder Type I just created, choose the appropriate Appointment Date and Time and press save.

<br/>Now this reminder will be sent one hour before the customers appointment date and time.
<h1>Image3</h1>
 
           </Text>
 
           <TextHeading> Step 3: Check the Reminder Status

           </TextHeading>
 
           <Text>
           As always, you can check the status and the results in the “Reminders” screen.

           <h1>Image4</h1>
 
           </Text>
           
          
 
           <FeelingContainer>
             <Feelingtext>How You Are Feeling??</Feelingtext>
             <IconContainer>
               <Icon>
                 <FaFaceGrinHearts />
               </Icon>
               <Icon>
                 <FaFaceSmile />
               </Icon>
               <Icon>
                 <FaFaceTired />
               </Icon>
             </IconContainer>
           </FeelingContainer>
           <ShareContainer>
             Share This Article :
             <SocialImage src={Facebook} alt="Facebok" target="blank" />
             <SocialImage src={Twitter} alt="Twitter" target="blank" />
             <SocialImage src={Instagram} alt="Instagram" target="blank" />
             <SocialImage src={Linkedin} alt="Linked" target="blank" />
           </ShareContainer>
         </TextContainer>
       </ContextContainer>
     </MainContainer>
     <Footer />
   </>
  )
}

export default TriggerTime
