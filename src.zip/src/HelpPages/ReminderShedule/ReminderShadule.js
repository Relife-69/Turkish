import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledReminderShedule";

const ReminderShadule = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Account Settings
              <MdKeyboardArrowRight />
              <span>Reminder Schedule – Days and Times to Send Reminders</span>
            </HeadingContainer>
            <Heading>
              Reminder Schedule – Days and Times to Send Reminders
            </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                {" "}
                The Reminder Schedule page allows you to set the days and times
                that your reminders will be sent.
              </TextList>
              <TextList>
                {" "}
                On the “Reminder Schedule” screen you will see the following
                settings
              </TextList>
              <TextList>Additional Notes</TextList>
            </TextMenu>

            <TextHeading>
              The Reminder Schedule page allows you to set the days and times
              that your reminders will be sent.
            </TextHeading>
            <Text>
              By default, your reminders will be sent Mon-Fri 9AM-8PM.
            </Text>
            <Text>
              Go to the “Reminder Schedule” page to change the days and times
              that your reminders will be sent. To get to the “Reminder
              Schedule” page, ensure that you are logged into your account. Then
              in the “Navigation Menu” select “Reminder Settings” – “General
              Reminder Settings” – “Reminder Schedule”
            </Text>
            <Image src={User} />
            <TextHeading>
              TOn the “Reminder Schedule” screen you will see the following
              settings:
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                Day of Week: Mon-Sun. Put a check box on the days that you want
                reminders to be sent.
              </RequirmentsList>
              <RequirmentsList>
                Start time: This is the time of day that your reminders will
                start. *It is not possible to start them before 8AM.
              </RequirmentsList>
              <RequirmentsList>
                End time: This is the time of day that your reminders will stop
                being sent. *It is not possible to end them later than 9PM.
              </RequirmentsList>
              <RequirmentsList>
                If Reminder Is Scheduled to Go Out on A Disabled Day…
              </RequirmentsList>
              <RequirmentsList1>
                Send on First Previous Enabled Day (Example, if you do not send
                reminders on Saturday and Sunday, the reminder would go out on
                Friday).
              </RequirmentsList1>
              <RequirmentsList1>
                Use ‘Days Before Appt’ Settings From Reminder Type (This uses
                the “Before Appt Date – Days Prior” setting from your Reminder
                Type. Example, if this is set to 2 and you have Saturday and
                Sunday disabled, the reminder would go out on Thursday).
              </RequirmentsList1>
            </ListContainer>
            <Image src={User} />
            <TextHeading>Additional Notes</TextHeading>

            <ListContainer>
              <RequirmentsList>
                These are global settings and will affect ALL your reminders.
              </RequirmentsList>
              <RequirmentsList>
                To change your Timezone, you can do this by editing your
                Company.
              </RequirmentsList>
              <RequirmentsList>
                The Start Time and End Time represent a window of time that we
                can send out your reminders. Usually, all of your reminders will
                go out within an hour of the start time. However, if you
                schedule an appointment in the middle of the day and it is
                within this window, your reminders will still go out.
              </RequirmentsList>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default ReminderShadule;
