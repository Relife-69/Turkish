import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledPayments";

const Payment = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Account Settings
              <MdKeyboardArrowRight />
              <span>Payment and Billing Information</span>
            </HeadingContainer>
            <Heading>Payment and Billing Information</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> What Type of Payment Do We Accept?</TextList>
              <TextList> Is My Payment Information Safe?</TextList>
              <TextList>
                This site is protected by Trustwave's Trusted Commerce program
              </TextList>
              <TextList>Authorize.Net Verified Merchant </TextList>
              <TextList>When Do We Bill? </TextList>
              <TextList>Adding/Editing Billing Info </TextList>
              <TextList>Billing Statements </TextList>
              <TextList>How to Print/Save an Invoice </TextList>
              <TextList>Pricing </TextList>
            </TextMenu>
            <TextHeading>What Type of Payment Do We Accept?</TextHeading>
            <Text>
              With most accounts we will just store your credit card on file. We
              accept the following cards:
            </Text>
            <ListContainer>
              <RequirmentsList1>Visa</RequirmentsList1>
              <RequirmentsList1>MasterCard</RequirmentsList1>
              <RequirmentsList1>American Express</RequirmentsList1>
              <RequirmentsList1>Discover</RequirmentsList1>
              <RequirmentsList1>Diners Club</RequirmentsList1>
              <RequirmentsList1>JCB</RequirmentsList1>
            </ListContainer>
            <Text>
              With larger accounts, we can bill through electronic invoicing and
              accept checks.
            </Text>
            <TextHeading>Is My Payment Information Safe?</TextHeading>
            <Text>
              Yes! Any time you add or edit payment information you are
              connected directly to Authorize.Net’s site through an encrypted
              connection. We do not store any payment information on our site or
              servers.
            </Text>
            <Text>
              When you add payment information, we will bill automatically every
              month to the card that you have on file with Authorize.net. This
              is the best way to pay for your services. As always, there are no
              contracts and you are free to{" "}
              <Link to="/account_cancel_help" target="blank">
                {" "}
                cancel your services{" "}
              </Link>
              at any time.
            </Text>
            <TextHeading>
              This site is protected by Trustwave's Trusted Commerce program
            </TextHeading>
            <Image src={User} />
            <TextHeading>Authorize.Net Verified Merchant </TextHeading>
            <Image src={User} />
            <TextHeading>When Do We Bill? </TextHeading>
            <Text>
              We bill at the end of the billing cycle (monthly). We do this
              because the total amount due can change depending on how many
              reminders you use for the month.
            </Text>
            <TextHeading>Adding/Editing Billing Info </TextHeading>
            <Text>
              To add or edit your billing info, select “Billing Info” from the
              “My Account” menu.
            </Text>
            <Image src={User} />
            <Text>On this page you can view your current billing info.</Text>
            <Text>
              To add or edit your card, click on “View/Edit Payment Method”.
            </Text>
            <Text>
              Clicking this link will take you to the Authorize.net page where
              you can add or edit your card.
            </Text>
            <Image src={User} />
            <Text>
              Complete adding your card on Authorize.net’s site. When you are
              done, be sure to press “Continue”. This will bring you back to our
              site and complete the verification process.
            </Text>
            <Image src={User} />
            <TextHeading>Billing Statements </TextHeading>
            <Text>
              To view your Billing Statements, select “Billing Statements” from
              the “My Account Menu”.
            </Text>
            <Image src={User} />
            <Text>
              On this page, you can see a list of all of your past billing
              statements. This includes how many reminders you used.
            </Text>
            <Image src={User} />
            <TextHeading>How to Print/Save an Invoice </TextHeading>
            <Text>
              To view details or print an invoice, click on “View Details”.
            </Text>
            <Text>
              This will open your invoice up in a print friendly format.
            </Text>
            <Image src={User} />
            <TextHeading>Pricing</TextHeading>
            <Text>
              <Link to="/pricing">
                For more information about pricing, please click here
              </Link>
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Payment;
