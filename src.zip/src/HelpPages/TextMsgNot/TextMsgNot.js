import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTextMsgNot";
const TextMsgNot = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Text Messages
              <MdKeyboardArrowRight />
              <span>Why Text Messages Don’t Originate From My Caller ID</span>
            </HeadingContainer>
            <Heading>
              Why Text Messages Don’t Originate From My Caller ID
            </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                This post contains information on Caller IDs for text messages.
              </TextList>
              <TextList>
                Why can't I use my Caller ID for Text Messages?
              </TextList>
              <TextList>
                If I can't use my Caller ID, how do I know when people reply to
                my text messages?
              </TextList>
              <TextList>
                You can check the response to text messages in a few ways:
              </TextList>
            </TextMenu>
            <TextHeading>
              This post contains information on Caller IDs for text messages.
            </TextHeading>
            <Text>
              We use an internal Caller ID (long-code) for text messages (SMS).
              <br />
              SMS (texts) originate from one of our telephone numbers or a short
              code. However, with a premium account, we are able to send SMS
              messages from a long code (10 digit phone number) that is
              dedicated to your account. This number would be unique to your
              account and could have the same area code as your business. If
              people try to call into this number, they would hear a customized
              voice message of your choosing. There is no additional cost for
              this functionality. This is only available with Premium Accounts.
            </Text>
            <TextHeading>
              Why can’t I use my Caller ID for Text Messages?
            </TextHeading>
            <Text>
              While we do allow you to set up and use your Caller ID (or
              several) to send you calls, text messages don’t have this option.
              <br />
              The reason is this:
              <br />
              If you set up your text message reminder type to accept a
              response, that response will be stored in your account and you can
              access it through the reminders tab or see it in the reports that
              are emailed to you. If it originated from your phone number you
              would run into a couple issues.
              <br />
              This number may not be capable of receiving text messages.
              <br />
              You would receive all the responses through text messages and
              would have no idea who they came from.
            </Text>
            <TextHeading>
              If I can’t use my Caller ID, how do I know when people reply to my
              text messages?
            </TextHeading>
            <Text>
              <h3>
                You can check the response to text messages in a few ways:{" "}
              </h3>
              You can always check the responses on
              <Link> the “Reminders” page</Link>.<br />
              <Link>Set up triggers </Link> to notify you via text message or
              email if people respond a certain way to your reminders.
              <br />
              You can <Link> receive nightly reports</Link> with all the info
              about the reminders that went out that day, including responses to
              the reminders.
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default TextMsgNot;
