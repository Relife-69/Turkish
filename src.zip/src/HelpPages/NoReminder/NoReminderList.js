import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledNoReminderList";

const NoReminderListHelp = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Appointment Reminders
              <MdKeyboardArrowRight />
              <span>No Reminder List – How it Works</span>
            </HeadingContainer>
            <Heading>No Reminder List – How it Works</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                The No Reminder List can be added to by 2 different methods
              </TextList>
              <TextList>
                To modify the No Reminder List manually follow these
                instructions:
              </TextList>
              <TextList>
                How someone can remove themselves by replying to a reminder:
              </TextList>
              <TextList>Email Type Reminders:</TextList>
              <TextList> Text Message Type Reminders:</TextList>
              <TextList>Ok, so how do I actually do it?</TextList>
            </TextMenu>
            <Text>
              The No Reminder List is a list of your customers who have
              requested to NOT have reminders sent to them, or to request a
              certain outreach method not be used (call, text messages, or
              email).
            </Text>
            <TextHeading>
              The No Reminder List can be added to by 2 different methods
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                You can edit the No Reminder List directly through the web
                interface
              </RequirmentsList>
              <RequirmentsList>
                The No Reminder List can be modified when customers opt out of a
                reminder that is sent to them
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              To modify the No Reminder List manually follow these instructions:
            </TextHeading>
            <Text>
              Go to the “No Reminder List” page. To get to the “No Reminder
              List” page, ensure that you are logged into your account. Then
              from the “Navigation Menu” select “My Customers” / “No Reminder
              List”.
            </Text>
            <Image src={User1} />

            <Text>
              This page will show you all of your customers in the no reminders
              list.
            </Text>
            <Text>To add a new record, click on “Add new record”</Text>
            <ListContainer>
              <RequirmentsList>
                Phone Number : The phone number for your customer
              </RequirmentsList>
              <RequirmentsList>
                Email Address : The email address of your customer
              </RequirmentsList>
              <RequirmentsList>
                Do Not Call : If checked, this customer will not receive any
                call type reminders
              </RequirmentsList>
              <RequirmentsList>
                Do Not Text : If checked, this customer will not receive any
                text message type reminders
              </RequirmentsList>
              <RequirmentsList>
                Do Not Email : If checked, this customer will not receive any
                email type reminders
              </RequirmentsList>
            </ListContainer>
            <Image src={User} />
            <TextHeading>
              How someone can remove themselves by replying to a reminder:{" "}
            </TextHeading>
            <TextHeading>Email Type Reminders: </TextHeading>
            <Text>
              There is automatically a link added at the bottom called
              “Unsubscribe”. If a customer clicks on the link, they will be
              unsubscribed from email reminders. This is a requirement of
              sending auto-generated emails and there is no way to remove this
              link.
            </Text>
            <TextHeading>Text Message Type Reminders: </TextHeading>
            <Text>
              If someone responds “stop” to a text message, they will be
              unsubscribed from text reminders. If you want people to be aware
              of this option then you will need to add it to your text message
              (e.g. text ‘stop’ to unsubscribe).
            </Text>
            <TextHeading>Call Type Reminders: </TextHeading>
            <Text>
              If someone presses ‘9’ in response to a call type reminder, they
              will be unsubscribed from calls. If you want people to be aware of
              this option then you will need to add it to your call type
              reminder (e.g. press ‘9’ to unsubscribe).
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default NoReminderListHelp;
