import styled from "styled-components";

export const MainContainer = styled.div`
  width: 380px;
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  background-color: white;
  gap: 15px;
  border: 1px solid silver;
  border-radius: 8px;
  padding: 15px 0px;
`;

export const MainMenu = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  padding: 10px 15px;
  cursor: pointer;
  &:hover {
    background-color: #1376f8;
    color: white;
  }
`;

export const MenuItem1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
`;
export const MenuItems2 = styled.div`
  width: 30px;
  height: 30px;
  background-color: #1376f8;
  color: white;
  border-radius: 50%;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const MenuList = styled.div`
  display: ${({ showMenu }) => (showMenu ? "flex" : "none")};
  width: 100%;
  align-items: start;
  justify-content: start;
  padding: 10px 15px;
  cursor: pointer;
  gap: 8px;
  flex-direction: column;
`;
export const List = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
  gap: 8px;
  a {
    color: black;
    text-decoration: none;
    &:hover {
      color: #1376f8;
    }
  }
`;
