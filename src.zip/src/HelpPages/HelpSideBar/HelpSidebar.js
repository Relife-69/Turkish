import React, { useState } from "react";
import { PiFilesFill } from "react-icons/pi";
import { Link } from "react-router-dom";
import { TbScript } from "react-icons/tb";
import {
  MainContainer,
  MainMenu,
  MenuItem1,
  MenuItems2,
  MenuList,
  List,
} from "./StyledHelpSidebar";

const HelpSidebar = () => {
  const [showMenu, setShowMenu] = useState();
  const toggleMenu = (menu) => {
    setShowMenu(showMenu === menu ? null : menu);
  };

  return (
    <>
      <MainContainer>
        <MainMenu onClick={() => toggleMenu("Tutorials")}>
          <MenuItem1>
            <PiFilesFill />
            Tutorials{" "}
          </MenuItem1>
          <MenuItems2>8</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Tutorials"}>
          <List>
            <TbScript />
            <Link to="/linked_calender_help">
              Google Calendar – Linking a Google Calendar
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/shedule_adding_customer_help">
              Google Calendar – Scheduling Appointments & Adding Customers
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/trigger_create_and_edit_help">
              Triggers – Creating and Editing{" "}
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/website_overview_help">
              Website Overview and New Company Walkthrough{" "}
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/first_reminder_help">Sending Your First Reminder </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/text_fail_help">
              How to Roll Failed Text Messages to a Call{" "}
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/custom_feilds_help">Custom Fields </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/trigger_time_help">
              How to Send an Appointment One Hour Prior to Appointment Time{" "}
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Account Settings")}>
          <MenuItem1>
            <PiFilesFill />
            Account Settings
          </MenuItem1>
          <MenuItems2>5</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Account Settings"}>
          <List>
            <TbScript />
            <Link to="/help_add_user">
              How to Add Additional Users to Your Account
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/account_cancel_help">How Do I Cancel My Account?</Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/payments_help">Payment and Billing Information</Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/reminder_shedule_help">
              Reminder Schedule – Days and Times to Send Reminders
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/test_mode_help">
              Test Mode (Disabling Live Reminders)
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Connecting")}>
          <MenuItem1>
            <PiFilesFill />
            Connecting Your Data{" "}
          </MenuItem1>
          <MenuItems2>6</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Connecting"}>
          <List>
            <TbScript />
            <Link to="/appointment_reminder_help">
              Appointment Reminders Upload Service
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/reminder_website_help">
              Adding Appointments Through the Website Interface
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/linked_calender_help">
              Google Calendar – Linking a Google Calendar
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/integration_help">Integrating Into Your EMR</Link>
          </List>
          <List>
            <TbScript />
            <Link to="/data_extract_help">
              Data Extract – What Data Do We Need?
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/custom_feilds_help">Custom Fields</Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Google")}>
          <MenuItem1>
            <PiFilesFill />
            Google Calendar{" "}
          </MenuItem1>
          <MenuItems2>3</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Google"}>
          <List>
            <TbScript />
            <Link to="/calender_event_view_help">
              Google Calendar – Event View
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/linked_calender_help">
              Google Calendar – Linking a Google Calendar
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/shedule_adding_customer_help">
              Google Calendar – Scheduling Appointments & Adding Customers
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Email")}>
          <MenuItem1>
            {" "}
            <PiFilesFill />
            Email Reminders
          </MenuItem1>
          <MenuItems2>1</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Email"}>
          <List>
            <TbScript />
            <Link to="/email_customization_help">Email Customization</Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Appointment")}>
          <MenuItem1>
            {" "}
            <PiFilesFill />
            Appointment Reminders{" "}
          </MenuItem1>
          <MenuItems2>7</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Appointment"}>
          <List>
            <TbScript />
            <Link to="/multiple_reminders_help">
              Creating Multiple Reminders for an Appointment
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/no_reminder_list_help">
              No Reminder List – How it Works
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/reminder_type_help">
              Reminder Types – Creating and Editing
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/call_reminder_help">
              Repeating a Phone Call Reminder Message
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/text_block_help">
              Text Blocks – Creating and Editing
            </Link>
          </List>
          <List>
            <TbScript />
            <Link to="/first_reminder_help">Sending Your First Reminder</Link>
          </List>
          <List>
            <TbScript />
            <Link to="/custom_feilds_help">Custom Fields</Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Import")}>
          <MenuItem1>
            <PiFilesFill />
            Import Files
          </MenuItem1>
          <MenuItems2>3</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Import"}>
          <List>
            <TbScript />
            <Link to="/create_and_upload_list_help">
              Contact Lists – Creating and Uploading
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/import_files_structure_and_content_help">
              Import Files – Structure and Content
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/custom_feilds_help">Custom Fields</Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Customers")}>
          <MenuItem1>
            <PiFilesFill />
            Customers/Patients
          </MenuItem1>
          <MenuItems2>3</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Customers"}>
          <List>
            <TbScript />
            <Link to="/web_portal_help">
              Adding Customers Through The Web Portal
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/distribution_list_help">Distribution Lists</Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/export_contact_help">
              Export a Contact List From Outlook or Google
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Text")}>
          <MenuItem1>
            <PiFilesFill />
            Text Messages
          </MenuItem1>
          <MenuItems2>3</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Text"}>
          <List>
            <TbScript />
            <Link to="/text_to_c&p_help">
              How To Send Text Messages to Customers/Patients
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/text_message_don't_help">
              Why Text Messages Don’t Originate From My Caller ID
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/text_fail_help">
              How to Roll Failed Text Messages to a Call
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Reports")}>
          <MenuItem1>
            <PiFilesFill />
            Reports
          </MenuItem1>
          <MenuItems2>4</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Reports"}>
          <List>
            <TbScript />
            <Link to="/report_real_time_help">
              The Reminders Screen – Real Time Reporting on Your Reminders
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/report_download_programatically_help">
              Reports – Downloading Programmatically
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/report_nightly_email_help">
              Reports – Nightly Emailed Reports{" "}
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/report_structure_content_help">
              Reports – Structure and Content{" "}
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Spanish")}>
          <MenuItem1>
            <PiFilesFill />
            Spanish
          </MenuItem1>
          <MenuItems2>1</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Spanish"}>
          <List>
            <TbScript />
            <Link to="/spanish_help">Spanish Mapping</Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Triggers")}>
          <MenuItem1>
            <PiFilesFill />
            Triggers
          </MenuItem1>
          <MenuItems2>3</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Triggers"}>
          <List>
            <TbScript />
            <Link to="/trigger_create_and_edit_help">
              Triggers – Creating and Editing
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/text_fail_help">
              How to Roll Failed Text Messages to a Call
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/trigger_time_help">
              How to Send an Appointment One Hour Prior to Appointment Time{" "}
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Call Reminders")}>
          <MenuItem1>
            {" "}
            <PiFilesFill />
            Phone Call Reminders{" "}
          </MenuItem1>
          <MenuItems2>4</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Call Reminders"}>
          <List>
            <TbScript />
            <Link to="/caller_help">
              Caller IDs – Creating, Validating & Using
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/CreatingandEditingVF">
              Voicefiles – Creating and Editing
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/pre_recorded_library_help">
              Voice Files – Our Prerecorded Library
            </Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/text_fail_help">
              How to Roll Failed Text Messages to a Call
            </Link>
          </List>
        </MenuList>
        <MainMenu onClick={() => toggleMenu("Customization")}>
          <MenuItem1>
            {" "}
            <PiFilesFill />
            Customization{" "}
          </MenuItem1>
          <MenuItems2>2</MenuItems2>
        </MainMenu>
        <MenuList showMenu={showMenu === "Customization"}>
          <List>
            <TbScript />
            <Link to="/email_customization_help">Email Customization</Link>
          </List>
          <List>
            {" "}
            <TbScript />
            <Link to="/custom_feilds_help">Custom Fields</Link>
          </List>
        </MenuList>
      </MainContainer>
    </>
  );
};

export default HelpSidebar;
