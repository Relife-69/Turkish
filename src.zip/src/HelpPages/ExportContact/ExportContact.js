import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledExportContact";

const ExportContact = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Customers/Patients
              <MdKeyboardArrowRight />
              <span>Export a Contact List From Outlook or Google</span>
            </HeadingContainer>
            <Heading>Export a Contact List From Outlook or Google</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>How to Export From Outlook</TextList>
              <TextList>
                To Import Your Outlook Contact List Into Our Site
              </TextList>
              <TextList>To Export Your Contact List From Google</TextList>
              <TextList>
                To Import Your Google Contact List into Our Site
              </TextList>
            </TextMenu>

            <TextHeading>How to Export From Outlook</TextHeading>
            <Text>
              Follow these steps to export your contact list from Outlook into a
              CSV file. Once created, you can simply upload it to your
              appointmentreminders.com account to start sending reminders to
              your contacts.
              <br />
              1. Open up Outlook
              <br />
              2. Choose “File”
              <h1>Image 1</h1>
              3. Choose “Open and Export”
              <h1>Image 2</h1>
              4. Select the “Import/Export Option
              <h1>Image 3</h1>
              5. Choose “Export to a file”
              <h1>Image 4</h1>
              6. Choose the “Comma Separated Values” (CSV) Option
              <br />
              7. Choose the “Contacts” folder
              <h1>Image 4</h1>
              8. Choose where to save your file. For this example I am saving it
              in c:\Temp\Contacts.csv
              <br />
              9. Hit Next and Finish (Make sure the “Export Contacts From
              Folder: Contacts” is Selected)
            </Text>

            <TextHeading>
              To Import Your Outlook Contact List Into Our Site
            </TextHeading>

            <Text>
              Click the exported .csv file to open it up.
              <br />
              Change the header name for “Mobile Phone” to “PriPhone”.
              <br />
              Change the header name for “Home Phone” to “SecPhone”.
              <br />
              <Link>Upload your contact list as explained in this post.</Link>
            </Text>

            <TextHeading>To Export Your Contact List From Google</TextHeading>

            <Text>
              You can quickly export your contact list from Google into a CSV
              file. Here’s how:
              <br />
              1. Sign in to Gmail.
              <br />
              2. Click Gmail at the top-left corner of your Gmail page, then
              choose Contacts.
              <br />
              3. From the More actions drop-down menu, select Export….
              <h1>Image 5</h1>
              4. Click “Export” on the left side of the screen
              <h1>Image 6</h1>
              5. Choose “Google CSV” and press Export.
              <h1>Image 7</h1>
            </Text>

            <TextHeading>
              To Import Your Google Contact List into Our Site
            </TextHeading>

            <Text>
              1. Open up the .csv file that you just downloaded
              <br />
              2. Change the column name “Given Name” to “FirstName”
              <br />
              3. Change the column name “Family Name” to “LastName”
              <br />
              4. Change the column name “Phone 1 – Value” to “PriPhone”
              <br />
              5. Change the column name “Phone 2 – Value” to “SecPhone”
              <br />
              6. Upload your contact list as explained in this post.
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default ExportContact;
