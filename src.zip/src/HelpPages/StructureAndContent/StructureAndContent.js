import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  RequirmentsList2,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledStructureAndContent";

const StructureAndContent = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Import Files
              <MdKeyboardArrowRight />
              <span>Import Files – Structure and Content</span>
            </HeadingContainer>
            <Heading>Import Files – Structure and Content</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                How to Create Import Files that can be uploaded to our site
              </TextList>
              <TextList>
                Here are a few additional ways to add appointments (reminders).
              </TextList>
              <TextList>Customers can also be added several ways. </TextList>
              <TextList>Creating and Importing a "Contact List".</TextList>
              <TextList>
                Click Here to Download Our Contact List Template
              </TextList>
              <TextList>
                Creating and Importing an "Import File With Appointment
                Information".
              </TextList>
              <TextList>
                Click Here to Download Our Import File Template
              </TextList>
              <TextList>Additional Must Know Info about Import Files</TextList>
            </TextMenu>
            <TextHeading>
              How to Create Import Files that can be uploaded to our site
            </TextHeading>
            <Text>
              You can read through this posting to learn how to create your
              import files. Learn how to upload excel and csv files with your
              customer and/or appointment information.
            </Text>
            <Text>
              Import Files can contain either “Contact Information”,
              “Appointment Information”, or Both. Importing your contacts and/or
              your appointment information through import files is simply one
              way of many to add information to your account.
            </Text>
            <TextHeading>
              Here are a few additional ways to add appointments (reminders).
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                <Link>
                  You can add appointments through the website interface.
                </Link>
              </RequirmentsList>
              <RequirmentsList>
                They can be uploaded to our site through import files (.csv,
                .xls). (This Post)
              </RequirmentsList>
              <RequirmentsList>
                <Link>They can be added on-the-fly through calendars.</Link>
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              Customers can also be added several ways.{" "}
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                <Link>
                  1. You can add customers through the website interface.
                </Link>
              </RequirmentsList>
              <RequirmentsList>
                2. They can be uploaded to our site through import files.
              </RequirmentsList>
              <RequirmentsList>
                <Link>3. They can be added on-the-fly through calendars.</Link>
              </RequirmentsList>
              <Text>
                Here is a link to a tutorial that will explain the basics of
                creating and uploading import files. For more info and
                templates, read through this posting.
              </Text>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>Creating and Importing a “Contact List”.</TextHeading>
            <Text>
              You can <Link>import a contact list </Link> to our site with all
              of your existing customers information.
            </Text>
            <TextHeading>
              <Link>Click Here to Download Our Contact List Template</Link>
            </TextHeading>
            <Text>
              1. Create an Excel File with the following Headers. *Note, the
              headers are required for a ‘Contact Info Only’ import file.
            </Text>
            <ListContainer>
              <RequirmentsList>
                FirstName (**OPTIONAL: The first name of your customer)
              </RequirmentsList>
              <RequirmentsList>
                LastName (**OPTIONAL: The last name of your customer)
              </RequirmentsList>
              <RequirmentsList>
                FullName (**OPTIONAL: The full name of your customer separated
                by a space)
              </RequirmentsList>
              <RequirmentsList>
                PriPhone (REQUIRED: The 10 digit primary phone number of your
                customer)
              </RequirmentsList>
              <RequirmentsList>
                SecPhone (OPTIONAL: The 10 digit secondary phone number of your
                customer)
              </RequirmentsList>
              <RequirmentsList>
                EmailAddress (*OPTIONAL: Your customers email address)
              </RequirmentsList>
              <RequirmentsList>
                CustID (**OPTIONAL: Your alphanumeric customer ID if you use
                one)
              </RequirmentsList>
            </ListContainer>
            <Text>
              *NOTE : Email Address is optional. However, if you have an email
              type reminder scheduled for a customer with no email address, the
              reminder will not be sent.
            </Text>
            <Text>
              **NOTE : FirstName OR LastName is required if you do not enter a
              CustomerID
            </Text>
            <Text>
              **NOTE : If you cannot split the customer name into First and
              Last, then you will use the “FullName” field.
            </Text>
            <Text>
              2. Verify that every row contains the required fields listed
              above. In Example 1 Below, all 3 rows are valid.
            </Text>
            <Text>3. Save the file as a CSV (Comma Delimited) .csv file</Text>
            <Image src={User1} />

            <TextHeading>
              Creating and Importing an “Import File With Appointment
              Information”.
            </TextHeading>
            <Text>
              You can import files though our site with customer and appointment
              information
            </Text>
            <TextHeading>
              <Link>Click Here to Download Our Import File Template</Link>
            </TextHeading>
            <RequirmentsList>
              Go to the Import Files page on the Website. To get to the “Import
              Files” page, ensure that you are logged into your account. Then
              from the “Navigation Menu”, choose “My Data Sources” / “Import
              Files”.
            </RequirmentsList>
            <Image src={User1} />
            <ListContainer>
              <RequirmentsList>
                1. Create an Excel File with the following Headers. *Note, the
                headers are optional but if there are no headers then the
                columns must appear in the exact order below.
              </RequirmentsList>
              <RequirmentsList1>
                FirstName (**OPTIONAL : The first name of your customer)
              </RequirmentsList1>
              <RequirmentsList1>
                LastName (**OPTIONAL : The last name of your customer)
              </RequirmentsList1>
              <RequirmentsList1>
                FullName (**OPTIONAL: The full name of your customer separated
                by a space)
              </RequirmentsList1>
              <RequirmentsList1>
                PriPhone (**OPTIONAL : The 10 digit primary phone number of your
                customer)
              </RequirmentsList1>
              <RequirmentsList1>
                SecPhone (OPTIONAL : The 10 digit secondary phone number of your
                customer)
              </RequirmentsList1>
              <RequirmentsList1>
                EmailAddress (OPTIONAL : Your customers email address)
              </RequirmentsList1>
              <RequirmentsList1>
                CustID (**OPTIONAL : Your alphanumeric customer ID if you use
                one)
              </RequirmentsList1>
              <RequirmentsList1>
                ApptDate (REQUIRED : Appointment Date in the format of
                MM/DD/YYYY)
              </RequirmentsList1>
              <RequirmentsList1>
                ApptTime (REQUIRED : Appointment time in any of these formats:
                HHMM in 24 hour format, HHMMam/pm, HHMMa/p, HH:MMam/pm,
                HH:MMa/p)
              </RequirmentsList1>
              <RequirmentsList1>
                ApptEndTime (**OPTIONAL : Appointment time in any of these
                formats: HHMM in 24 hour format, HHMMam/pm, HHMMa/p, HH:MMam/pm,
                HH:MMa/p)
              </RequirmentsList1>
              <RequirmentsList1>
                ApptDateTime (You may use this field to pass in a DateTime
                variable instead of ApptDate+ApptTime but it must be a valid
                datetime field)
              </RequirmentsList1>
              <RequirmentsList1>
                ReminderType OPTIONAL – This field can contain any of the
                following values:
              </RequirmentsList1>
              <RequirmentsList2>
                Leave Blank (If you leave it blank then it will send the default
                reminder type) *See the “Setting up default reminder types”
                section.
              </RequirmentsList2>
              <RequirmentsList2>
                ‘Call’, ‘Text’, or ‘Email’ (If you enter one of these values
                then it will send the first reminder type that matches the
                outreach method that you specify). If you are planning on using
                this then it is wise to only create one reminder type of each
                outreach method (call, text, and email).
              </RequirmentsList2>
              <RequirmentsList2>
                ReminderTypeID (When you create a reminder type you will see the
                reminder type ID). If you specify the ReminderTypeID then it
                will send the reminder type that matches the ReminderTypeID.
              </RequirmentsList2>
              <RequirmentsList2>
                ReminderTypeDescription (When you create a reminder type you
                will see the reminder type Description). If you specify the
                Reminder Type Description then it will send the reminder type
                that matches the Reminder Type Description.
              </RequirmentsList2>
              <RequirmentsList2>
                ‘Cancelled’ (If you send this string then the reminder will not
                go out) **NOTE- If you pass in CustID and the CustID matches a
                record in your customer list then you do not need to send Name,
                Phone, or Email info.
              </RequirmentsList2>
              <RequirmentsList1>
                CustomField1 OPTIONAL – If you use custom fields in your
                reminder types, add them here
              </RequirmentsList1>
              <RequirmentsList1>
                CustomField2 OPTIONAL – If you use custom fields in your
                reminder types, add them here
              </RequirmentsList1>
              <RequirmentsList1>
                CustomField3 OPTIONAL – If you use custom fields in your
                reminder types, add them here
              </RequirmentsList1>
              <RequirmentsList>
                2. Verify that every row contains the required fields listed
                above. *Note Email Address is optional. However, if you have an
                email type reminder scheduled for a customer with no email
                address, the reminder will not be sent. In Example 2 Below, all
                3 rows are valid. Example 2.
              </RequirmentsList>
              <Image src={User1} />
              <RequirmentsList>
                3. Save the file as a CSV (Comma Delimited) .csv file
              </RequirmentsList>
            </ListContainer>

            <TextHeading>
              Additional Must Know Info about Import Files
            </TextHeading>
            <Text>
              Please keep the following IMPORTANT INFORMATION in mind when
              creating an import file
            </Text>
            <ListContainer>
              <RequirmentsList>
                If you DO NOT specify the <Link> Reminder Type </Link> in the
                import file, your default reminder type will be used.
              </RequirmentsList>
              <RequirmentsList>
                Appointment Time and Appointment Date MUST be in the format
                specified above.
              </RequirmentsList>
              <RequirmentsList>
                If the FirstName and LastName and Phone Number (Pri or Sec)
                Matches a Record in the Contact List, EmailAddress and
                CustomerID will be Updated.
              </RequirmentsList>
              <RequirmentsList>
                If the FirstName and LastName Matches a Record in the Contact
                List but Phone Number (Pri or Sec) do not match, an additional
                record will be created. This is important to know because it
                would certainly be possible to have several customers with the
                same first and last name. It’s usually not a problem if you
                upload nightly files with Appointment Info since we always match
                those with all 3 fields. However, if you use a calendar this
                could be a problem since we only match by First and Last name in
                the calendar title. If this is the case, you would either need
                to store a Unique FirstName and LastName for customers with the
                same name or pass a CustomerID through Calendar TAGS.
              </RequirmentsList>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default StructureAndContent;
