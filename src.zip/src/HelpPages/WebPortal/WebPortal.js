import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  RequirmentsList2,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledWebPortal";

const WebPortal = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Customers/Patients
              <MdKeyboardArrowRight />
              <span>Adding Customers Through The Web Portal</span>
            </HeadingContainer>
            <Heading>Adding Customers Through The Web Portal</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>Learn how to add customers using the website</TextList>
              <TextList>
                The “Customers” page of the website will display a list of your
                current customers.
              </TextList>
              <TextList>
                To add an new customer, click the “Add New Customer” button.
              </TextList>
            </TextMenu>
            <TextHeading>
              Learn how to add customers using the website{" "}
            </TextHeading>
            <Text>
              Customers can be added several ways. In this topic we will show
              you how to add customers through the website interface.
            </Text>
            <ListContainer>
              <RequirmentsList>
                1: You can add customers through the website interface.
              </RequirmentsList>
              <RequirmentsList>
                2:{" "}
                <Link>
                  {" "}
                  They can be uploaded to our site through import files.
                </Link>
              </RequirmentsList>
              <RequirmentsList>
                3: <Link> They can be added on-the-fly through calendars.</Link>
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              The “Customers” page of the website will display a list of your
              current customers.{" "}
            </TextHeading>
            <Text>
              To get to the “Customers” page, ensure that you are logged into
              your account. Then from the “Navigation Menu” go to “My Customers”
              / “Customers/Patients”.
            </Text>
            <Image src={User1} />

            <TextHeading>
              To add an new customer, click the “Add New Customer” button.
            </TextHeading>
            <Text>You will see the following fields:</Text>
            <ListContainer>
              <RequirmentsList>
                Last Name (Required): Customers Last Name
              </RequirmentsList>
              <RequirmentsList>
                First Name (Required): Customers First Name
              </RequirmentsList>
              <RequirmentsList>
                Pri Phone (Required): Customers Primary Phone Number
              </RequirmentsList>
              <RequirmentsList>
                Sec Phone (Optional): Customers Secondary Phone Number
              </RequirmentsList>
              <RequirmentsList>
                Email Address (Optional): Customers Email Address *Note: If you
                do not enter an email address, you will not be able to send
                email reminders.
              </RequirmentsList>
              <RequirmentsList>
                Customer ID (Optional): If you have a Customer ID that your
                company uses to identify customers then you may send it to us.
              </RequirmentsList>
              <RequirmentsList>
                Spanish: The default language preference for the customer
                (English or Spanish)
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />

            <Text>
              <Link>
                Click Here For info on adding appointments though the website
              </Link>
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default WebPortal;
