import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledRealTimeReport";
const RealTimeReport = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Reports
              <MdKeyboardArrowRight />
              <span>
                The Reminders Screen – Real Time Reporting on Your Reminders
              </span>
            </HeadingContainer>
            <Heading>
              The Reminders Screen – Real Time Reporting on Your Reminders
            </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                Narrow Down Your Results by Changing the Following Fields:
              </TextList>
              <TextList>Understanding The Rows in Your Results:</TextList>
              <TextList>
                Your results will contain a row for each reminder that matches
                the search fields that you have entered:
              </TextList>
              <TextList>
                Viewing The Actual Reminder Text That Was Sent
              </TextList>
              <TextList>Replying to a Customers Reply (Text Message).</TextList>
              <TextList>Deleting Unsent Reminders</TextList>
              <TextList>Additional Ways to View Reminders</TextList>
            </TextMenu>
            <b>
              The Reminders Page will let you view results on the reminders that
              you have scheduled and sent.
            </b>

            <Text>
              It includes details on the delivery result and the response to the
              reminders in real time. You can also save the results to an excel
              file from this page. *Note – to schedule nightly reports that will
              be emailed to you, see the ‘Reports’ page. To get to the
              “Reminders Page”, ensure that you are logged into your account.
              Then under the “Navigation Menu” select “Reporting” / “Reminders
              Page”.
            </Text>
            <h1>image 1</h1>
            <span>
              By default, the Reminders Page will show you all of your reminders
              with appointment dates during the next 30 days. You can change
              this time frame, return results for a specific Reminder Type,
              narrow by customer name, and more!
            </span>
            <TextHeading>
              Narrow Down Your Results by Changing the Following Fields:
            </TextHeading>
            <Text>
              <b>Appointment Start Date:</b> Enter the start date to view
              reminders with appointments starting on this date
              <br />
              <b>Appointment End Date:</b> Enter the end date to view reminders
              with appointments ending before or on this date
              <br />
              <b>Last Name:</b> Leave blank to return all results or enter a
              Last Name to narrow the results
              <br />
              <b>Reminders to Show:</b> (All, Complete, or Incomplete): Choose
              the status of the reminders that you want to view
              <br />
              <br />
              <b>All:</b> View ALL of your reminders
              <br />
              <b>Complete:</b> View reminders that have been sent (or attempted
              to be sent and failed)
              <br />
              <b>Incomplete:</b> View reminders that are scheduled
              <br />
              <b>Replies By Appt:</b> Will show you if your customer has replied
              to an appointment, even if you send{" "}
              <Link> multiple reminders for an appointment</Link>. <br />
              <br />
              <b>Reminder Types:</b> Choose “ALL” or choose a specific reminder
              type
              <br />
              <b>Order By:</b> Click on the column headers to re-sort your list.
              <br />
              <b>Export to Excel:</b> Click this button to export your reminder
              results into a .csv file that can easily be opened in excel or any
              text reader.
            </Text>

            <TextHeading>Understanding The Rows in Your Results:</TextHeading>
            <h3>
              Your results will contain a row for each reminder that matches the
              search fields that you have entered:
            </h3>
            <Text>
              Click on “Increase Table Width” to show you more details.
              <br />
              Blue Rows: Blue rows indicate reminders that were “successful”. By
              “successful”, we mean that as far as we can tell, the reminder was
              delivered to the recipient.
              <br /> <b>Red Rows:</b> Red rows indicate that the reminder
              failed. For text messages, it usually means a non-mobile or bad
              number and for calls it means no-answer, or a bad number.
              <br />
              <b>Customer & Appt Info:</b> Name, Phone Number, Customer ID, Appt
              Date & Time, and Reminder Type are included in the results.
              <br />
              <b>Result:</b> Shows the delivery result.
              <br />
              <b>Stop Reason:</b> Shows the reason that the reminder was
              stopped. Stop Date Passed indicates that the reminder was probably
              scheduled after the acceptable time frame to send the reminders
              <br />
              <b>Response:</b> Shows the persons response to the reminder.
              <br /> <b>Reminder Start & Stop Date:</b> This is the acceptable
              date frame to send the reminder.
            </Text>

            <h1>Image 1</h1>

            <TextHeading>
              Viewing The Actual Reminder Text That Was Sent
            </TextHeading>
            <Text>
              You can view the actual message that was sent to your customer by
              clicking on the magnifying glass icon.
              <h1>Image 2</h1>
            </Text>

            <TextHeading>
              Replying to a Customers Reply (Text Message).
            </TextHeading>
            <Text>
              You can easily reply back to a customer by clicking on the “sms”
              icon/ This will allow you to send a text message back to the
              customer. More on this in{" "}
              <Link> the “Text Messages to Customers” post</Link>.
              <h1>Image 3</h1>
            </Text>

            <TextHeading>Deleting Unsent Reminders</TextHeading>
            <Text>
              You can delete any unsent reminders from this screen as well. Just
              select “delete” and then press “delete checked items”. *Note – You
              can’t delete reminders that were already sent.
              <h1>Image 4</h1>
            </Text>

            <TextHeading>Additional Ways to View Reminders</TextHeading>
            <Text>
              The Reminders Page allows you to view reminders and their status
              in real time. You can also download CSV files with the reminder
              results. Additionally, you can
              <Link> set up nightly or weekly reports </Link> to be emailed to
              you.
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default RealTimeReport;
