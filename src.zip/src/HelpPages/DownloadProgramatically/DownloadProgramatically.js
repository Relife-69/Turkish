import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledDownloadProgramatically";
const DownloadProgramatically = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Reports
              <MdKeyboardArrowRight />
              <span>Reports – Downloading Programmatically</span>
            </HeadingContainer>
            <Heading>Reports – Downloading Programmatically</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                To download reports programmatically you will need to build your
                URL as follows.
              </TextList>
              <TextList>
                You may also send the following optional parameters
              </TextList>
              <TextList>
                Sending these parameters will limit your result set
              </TextList>
              <TextList>
                We provide code examples in C# and VB.NET that you can download
                here.
              </TextList>
              <TextList>
                We also provide an installable windows service that uploads and
                downloads files using this method. Check out our Upload Service
                Here.
              </TextList>
            </TextMenu>
            <span>
              We provide the ability for you to download reports with your
              appointment information programmatically by calling a secure URL,
              passing in your credentials, and downloading your file(s). This
              allows you to write your own data integration tool to download
              your appointment reminder status on a regular schedule. To do this
              you will need to build your URL as follows.
            </span>
            <TextHeading>
              To download reports programmatically you will need to build your
              URL as follows.
            </TextHeading>

            <Text>
              WebsiteURL = “https://secureserver.appointmentreminders.com”
              <br />
              Port = “:443” – Always use port 443
              <br />
              PageName = “Reports.aspx”
              <br />
              username = Your Account Username
              <br />
              password = Your Account Password
              <br />
              ReportType = “Report Type : Reminder Results or Reminder Summary
              or Daily Failed Reminders”
              <br />
              startdate = Start date of the report (e.g. 4/20/2013)
              <br />
              enddate = End date of the report )e.g. 4/21/2013)
            </Text>

            <h3>You may also send the following optional parameters</h3>
            <Text>
              CustomerID
              <br />
              FirstName
              <br />
              LastName
              <br />
              ReminderComplete (True/False)
            </Text>
            <h3>Sending these parameters will limit your result set</h3>
            <Text>
              “https://secureserver.appointmentreminders.com:443/Reports.aspx?ReportType=Reminder
              Results&username=MyUser&password=MyPassword&startdate=4/20/2013&enddate=4/21/2013”
              <br />
              Once you are connected you can use the .Net WebClient or any other
              Web Client to upload your file.You can also use a similar process
              to<Link> upload files</Link>. By utilizing 2 way programmatic
              communication, you can build a customized interface to{" "}
              <Link>integrate with whatever scheduling software or EMR</Link>{" "}
              that you are using.
            </Text>
            <h2>
              We provide code examples in C# and VB.NET that you can
              <Link> download here</Link>.<br />
              <br />
              We also provide an installable windows service that uploads and
              downloads files using this method. Check out our Upload Service
              Here.
            </h2>

            <a href="#">
              Reports are in .csv format. For more information on the Report
              structure, see our posting here
            </a>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default DownloadProgramatically;
