import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledNightlyEmail";
const NightlyEmail = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Reports
              <MdKeyboardArrowRight />
              <span>Reports – Nightly Emailed Reports</span>
            </HeadingContainer>
            <Heading>Reports – Nightly Emailed Reports</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                If you are looking for real-time reminder results you can always
                check The “Reminders” page.
              </TextList>
              <TextList>
                There are a few different reports that are available to you:
              </TextList>
              <TextList>
                To Create a new report click on “Add New Report”.
              </TextList>
            </TextMenu>
            <span>
              You can set up nightly, weekly, or monthly emailed reports with
              details of your reminders.
            </span>
            <TextHeading>
              If you are looking for real-time reminder results you can always
              check <a href="#">The “Reminders” page.</a>
            </TextHeading>
            <TextHeading>
              There are a few different reports that are available to you:
            </TextHeading>

            <Text>
              The report types are…
              <br />
              Reminder Results : Contains the results of the reminders that were
              sent.
              <br />
              Reminder Summary : Contains the number and type of reminders that
              were sent.
              <br />
              Failed Reminders : This report is sent at the end of the day
              (whenever your reminders stop) and gives you a list of the
              reminders that were not delivered.
              <br />
              <a href="#">
                Click Here for details on the information and structure of these
                reports
              </a>
              <br />
              When you go to the “Reports” page, you will see a list of all of
              the reports that you have set up. To get to the “Reports” page,
              ensure that you are logged into your account. Then from the
              “Navigation Menu”, select “Reporting” / “Emailed Reports”.
            </Text>

            <h1>Image 1</h1>

            <Text>
              By default, a daily Reminder Summary and a daily Reminder Results
              report is created but not enabled. You can keep, edit, or delete
              these default reports.
            </Text>
            <h1>image 2</h1>

            <Text>
              Report Type: This is the Report Type (Summary, Results, etc…)
              <br />
              Report Name: This is the name you choose to call the report.
              <br />
              Email to: This is where the Report will be emailed to. To email to
              additional addresses, create a new row for each report.
              <br />
              Frequency: This is how often the report will be emailed (Daily,
              Weekly, or Monthly).
              <br />
              Active: Whether or not this report will currently be sent.
              <br />
              HPAA Compliant: If this box is checked then the report will not
              include any PHI info such as names or phone numbers. They will
              only be identifiable by Customer ID.
              <br />
              Last Run Date: Date that the report was last generated.
              <br />
              Action: Edit or Delete this report. You can also press “Send Now”
              to send the report right away.
            </Text>

            <TextHeading>
              To Create a new report click on “Add New Report”.
            </TextHeading>
            <a href="#">Click Here For info on reports structure and content</a>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default NightlyEmail;
