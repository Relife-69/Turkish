import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledFirstReminderHelp";

const FirstReminderHelp = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Appointment Reminders
              <MdKeyboardArrowRight />
              <span>Sending Your First Reminder</span>
            </HeadingContainer>
            <Heading>Sending Your First Reminder</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                In this tutorial, I will show you how to add your first customer
                and send out your first reminder
              </TextList>
              <TextList>Step 1 - Navigate To Customers Page</TextList>
              <TextList>Step 2 - Add A Customer</TextList>
              <TextList>Step 3 - Schedule A Reminder</TextList>
              <TextList>Step 5 - Viewing The Results</TextList>
            </TextMenu>
            <Text>
              How to add a customer and send a reminder through the website
            </Text>
            <TextHeading>
              In this tutorial, I will show you how to add your first customer
              and send out your first reminder
            </TextHeading>
            <Image src={User1} />
            <Text>
              There are many ways to do this: including{" "}
              <Link> uploading files </Link>,{" "}
              <Link>linking your calendar </Link>, and more! This tutorial will
              guide you through simply adding a customer and{" "}
              <Link>scheduling a reminder right through the website.</Link>
            </Text>
            <TextHeading>Step 1 - Navigate To Customers Page </TextHeading>
            <Text>
              Lets go ahead and add a customer and schedule our first reminder.
              Hover over the “Navigation Menu”, then select “My Customers” and
              then Customers/Patients. This shows you a list of all of your
              customers. Since you have just created this account, there are no
              customers yet. Let’s go ahead and add a new customer now.
            </Text>
            <Image src={User1} />
            <TextHeading>Step 2 - Add A Customer</TextHeading>
            <Text>
              Click on the “Add New Customer/Patient” button. Go ahead and add
              yourself. Enter your first and last name, phone number, and your
              email address. Note that the only required fields here are First
              Name, Last Name and Primary Phone Number.
            </Text>
            <Text>
              However, if you are going to be sending text reminders, ensure
              that you enter a cell phone number and if you are going to be
              sending email reminders ensure that you enter an email address.
              Customer ID is optional. You can enter this if you have a customer
              ID for your customer. For now, we will leave this field blank.
            </Text>
            <Text>
              The Spanish check box is used for Spanish Speaking customers which
              we will cover in another tutorial. Go ahead and click on “Save”.
            </Text>
            <Image src={User1} />
            <Text>
              You can see that you have been added to the list. Let’s go ahead
              and schedule a new appointment for this customer.
            </Text>
            <TextHeading>Step 3 - Schedule A Reminder </TextHeading>
            <Text>
              Click on View/Add Reminders on the far-right side. This gives you
              a list of all the appointments that are scheduled for this
              customer. As you can see, there are no appointments yet. Click on
              the “Add New Reminder” button now.
            </Text>
            <Text>
              Click on the drop down list for “Reminder Type Name”. Depending on
              your configuration settings, you should have several reminders
              listed. If there is a “Text Message” type reminder, choose that
              one for now, otherwise choose a “Call” or “Email” type reminder.
              We will cover how to edit these and create new reminder types in
              another tutorial. For “Appointment Date/Time”, go ahead and select
              tomorrow’s date at 10:30 AM. You can leave Appointment End
              Date/Time blank and also leave the custom fields blank.
            </Text>
            <Text>
              After you enter this information click the “Save” button. Now you
              can see that your appointment has been added for this customer.
            </Text>
            <Image src={User1} />
            <TextHeading>Step 5 - Viewing The Results</TextHeading>
            <Text>
              If you hover over the “Navigation Menu”, then select “Reporting”
              and then Reminders Page, you can see all of the reminders that are
              scheduled. We will cover this page in more detail in another
              tutorial but for now, take a look at the reminder that we just
              created. Here you can see the details of this reminder as well as
              the Reminder Result. Most likely you should have received the
              reminder by now. If not, you should get it in the next few
              minutes.
            </Text>
            <Image src={User1} />
            <Text>
              If you have confirmations set up, go ahead and confirm the
              reminder. Shortly, you will see that your reminder has changed to
              blue. You can click on the magnifying glass for further details
              about the reminder. Or you can click the SMS button to reply to
              the reminder Via SMS.
            </Text>
            <Text>
              Congratulations! You have successfully scheduled an appointment
              and sent a reminder!
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default FirstReminderHelp;
