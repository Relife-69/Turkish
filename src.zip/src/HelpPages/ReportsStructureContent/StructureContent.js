import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledStructureContent";
const StructureContent = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Reports
              <MdKeyboardArrowRight />
              <span>Reports – Structure and Content</span>
            </HeadingContainer>
            <Heading>Reports – Structure and Content</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                We have several reports that can be emailed to you on a nightly
                basis
              </TextList>
              <TextList>The Report Types are:</TextList>
              <TextList>Reminder Results Report :</TextList>
              <TextList>Reminder Summary Report :</TextList>
              <TextList>Failed Reminders Report :</TextList>
            </TextMenu>
            <TextHeading>
              We have several reports that can be emailed to you on a nightly
              basis{" "}
            </TextHeading>
            <h3>The Report Types are: </h3>

            <Text>
              Reminder Results : Contains the results of the reminders that were
              sent.
              <br />
              Reminder Summary : Contains the number and type of reminders that
              were sent.
              <br />
              Failed Reminders : This report is sent at the end of the day
              (whenever your reminders stop) and gives you a list of the
              reminders that were not delivered.
              <br />
              All reports are in .csv format so they are easily opened in Excel
              or parsed and stored back into your Scheduling Software. Below you
              find an explanation of all of the fields as well as links to
              sample files.
            </Text>

            <h5>Reminder Results Report : </h5>
            <Text>
              Contains the results of the reminders that were sent.
              <br />
              Typically you would view this report on a nightly basis so you can
              view the results of your reminders.
              <br />
              Last Name : Customers Last Name
              <br />
              First Name : Customers First Name
              <br />
              Customer ID : Your Customer ID if you use one
              <br />
              Appointment Date : Customers Appointment Date
              <br />
              Appointment Time : Customers Appointment Time
              <br />
              Delivery Result : The Delivery Result of the Reminder
              <br />
              Customer Response : How the Customer responded to the Reminder
              <br />
              Reminder Description : The Name of the Reminder Type
            </Text>
            <h1>image 1</h1>
            <span>Download a Sample Reminder Results Report Here.</span>

            <h5>Reminder Summary Report :</h5>
            <Text>
              Contains the number and type of reminders that were sent.
              <br />
              Typically you would view this report on a monthly basis so you can
              see how many Reminders were sent out.
              <br />
              This screenshot shows the report opened in Notepad, however it can
              also be viewed in Excel.
              <br />
              Total Reminders : Total number of Reminders that were sent.
              <br />
              Calls : Total number of Calls
              <br />
              Text Messages : Total number of Text Messages
              <br />
              Emails : Total number of Emails
            </Text>
            <h1>image 2</h1>
            <span>Download a Sample Reminder Summary Report Here.</span>

            <h5>Failed Reminders Report :</h5>
            <Text>
              List of reminders that could not be delivered. This would most
              likely be due to ‘no answers’ or ‘busy’ but it will also show
              reminders that could not be sent due to other reason such as not
              having valid payment info on your account (business accounts) or
              exceeding your monthly limit of reminders (free accounts)
              <br />
              This report is sent on a daily basis after the StopTime for your
              reminder schedule has passed. *You will only see reminders that
              have been flagged to stop outreach. In other words if it is still
              ok to send the reminder tomorrow, the failed reminder will not be
              on the report.
              <br />
              Last Name : Customers Last Name
              <br />
              First Name : Customers First Name
              <br />
              Customer ID : Your Customer ID if you use one
              <br />
              Appointment Date : Customers Appointment Date
              <br />
              Appointment Time : Customers Appointment Time
              <br />
              Delivery Result : The Delivery Result of the Reminder
              <br />
              Customer Response : How the Customer responded to the Reminder
              <br />
              Reminder Description : The Name of the Reminder Type
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default StructureContent;
