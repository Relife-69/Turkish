import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledSpanish";
const Spanish = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Spanish
              <MdKeyboardArrowRight />
              <span>Spanish Mapping</span>
            </HeadingContainer>
            <Heading>Spanish Mapping</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                Spanish Mapping allows you to set up a Spanish version of a
                “Reminder Type”
              </TextList>
              <TextList>
                How to set up and map Spanish reminders to your English
                reminders.
              </TextList>
              <TextList>Additional details about Spanish Reminders</TextList>
            </TextMenu>
            <TextHeading>
              Spanish Mapping allows you to set up a Spanish version of a
              “Reminder Type”{" "}
            </TextHeading>
            <h1>Youtube Video</h1>

            <TextHeading>
              How to set up and map Spanish reminders to your English reminders.
            </TextHeading>
            <Text>
              First Steps:
              <br />
              Before you create a Spanish mapping, you need to create 2 reminder
              types: One in English and an Identical one in Spanish.
              <br />
              Click here for help on Reminder Types
              <br />
              Also make sure that you have your customers language preference
              defined in the customer list. Click here for help on Customers
              <br />
              When you click on “Spanish Mapping”, you will be taken to a screen
              that shows all of the mappings that you have set up. To get to the
              “Spanish Mapping page” page, ensure that you are logged into your
              account. Then under the “Navigation Menu”, click on “Reminder
              Settings” / “General Reminder Settings” / “Spanish Mapping”.
              <h1>image 1</h1>
            </Text>

            <Text>
              English Reminder Type: This is the English Version of the reminder
              type that you are setting up a mapping for.
              <br />
              Spanish Reminder Type: This is the Spanish Version of the reminder
              type that you are setting up a mapping for.
              <h1>Image 2</h1>
            </Text>

            <TextHeading>
              Additional details about Spanish Reminders
            </TextHeading>
            <Text>
              You do not have to specifically schedule Spanish reminders to your
              customers whose preferred language is Spanish. You only need to
              schedule the English version of the reminder as long as you have
              it set up in the mapping table.
              <br />
              With call type reminders only, once you have the mapping set up,
              if you send the English version of the call, it will add the
              following message…
              <br />
              Press4ForOtherLanguage.wav : por favor, presione quatro para
              escuchar este llamado en español.. You do not need to add this
              voice file, it will do it automatically. Then if the caller
              presses 4, they will hear the Spanish version of the call. This
              will also set the person’s preferred language to Spanish for
              future calls.
              <br />
              With call type reminders only, once you have the mapping set up,
              if you send the Spanish version of the call (or person’s preferred
              language is Spanish), it will add the following message…
              <br />
              Press4ForOtherLanguage.wav : Please press 4 to hear this call in
              English.. You do not need to add this voice file, it will do it
              automatically. Then if the caller presses 4 they will hear the
              English version of the call. This will also set the person’s
              preferred language to English for future calls.
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Spanish;
