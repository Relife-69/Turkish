import React from "react";
import Navbar from "../../Components/Header/Navbar";
import { PiFilesFill } from "react-icons/pi";
import { Link } from "react-router-dom";
import { TbScript } from "react-icons/tb";
import {
  MainContainer,
  ContextContainer,
  DocumentContainer,
  HeadingContiner,
  HeadingItem1,
  HeadingItems2,
  MenuList,
  List,
} from "./StyledHelpHome";

const HelpHome = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span>Tutorials</span>
              </HeadingItem1>
              <HeadingItems2>8</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/linked_calender_help">
                  Google Calendar – Linking a Google Calendar
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/shedule_adding_customer_help">
                  Google Calendar – Scheduling Appointments & Adding Customers
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/trigger_create_and_edit_help">
                  Triggers – Creating and Editing{" "}
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/website_overview_help">
                  Website Overview and New Company Walkthrough{" "}
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/first_reminder_help">
                  Sending Your First Reminder{" "}
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/text_fail_help">
                  How to Roll Failed Text Messages to a Call{" "}
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/custom_feilds_help">Custom Fields </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/trigger_time_help">
                  How to Send an Appointment One Hour Prior to Appointment Time{" "}
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Appointment Reminders</span>
              </HeadingItem1>
              <HeadingItems2>7</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/multiple_reminders_help">
                  Creating Multiple Reminders for an Appointment
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/no_reminder_list_help">
                  No Reminder List – How it Works
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/reminder_type_help">
                  Reminder Types – Creating and Editing
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/call_reminder_help">
                  Repeating a Phone Call Reminder Message
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/text_block_help">
                  Text Blocks – Creating and Editing
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/first_reminder_help">
                  Sending Your First Reminder
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/custom_feilds_help">Custom Fields</Link>
              </List>
            </MenuList>
          </DocumentContainer>

          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Connecting Your Data</span>
              </HeadingItem1>
              <HeadingItems2>6</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/appointment_reminder_help">
                  Appointment Reminders Upload Service
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/reminder_website_help">
                  Adding Appointments Through the Website Interface
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/linked_calender_help">
                  Google Calendar – Linking a Google Calendar
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/integration_help">Integrating Into Your EMR</Link>
              </List>
              <List>
                <TbScript />
                <Link to="/data_extract_help">
                  Data Extract – What Data Do We Need?
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/custom_feilds_help">Custom Fields</Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Account Settings</span>
              </HeadingItem1>
              <HeadingItems2>5</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/help_add_user">
                  How to Add Additional Users to Your Account
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/account_cancel_help">
                  How Do I Cancel My Account?
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/payments_help">Payment and Billing Information</Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/reminder_shedule_help">
                  Reminder Schedule – Days and Times to Send Reminders
                </Link>
              </List>
              <List>
                <TbScript />
                <Link to="/test_mode_help">
                  Test Mode (Disabling Live Reminders)
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Google Calendar</span>
              </HeadingItem1>
              <HeadingItems2>3</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/calender_event_view_help">
                  Google Calendar – Event View
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/linked_calender_help">
                  Google Calendar – Linking a Google Calendar
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/shedule_adding_customer_help">
                  Google Calendar – Scheduling Appointments & Adding Customers
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Email Reminders</span>
              </HeadingItem1>
              <HeadingItems2>1</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/email_customization_help">Email Customization</Link>
              </List>
            </MenuList>
          </DocumentContainer>

          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Import Files</span>
              </HeadingItem1>
              <HeadingItems2>3</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/create_and_upload_list_help">
                  Contact Lists – Creating and Uploading
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/import_files_structure_and_content_help">
                  Import Files – Structure and Content
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/custom_feilds_help">Custom Fields</Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Customers/Patients</span>
              </HeadingItem1>
              <HeadingItems2>3</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/web_portal_help">
                  Adding Customers Through The Web Portal
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/distribution_list_help">Distribution Lists</Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/export_contact_help">
                  Export a Contact List From Outlook or Google
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Text Messages</span>
              </HeadingItem1>
              <HeadingItems2>3</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/text_to_c&p_help">
                  How To Send Text Messages to Customers/Patients
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/text_message_don't_help">
                  Why Text Messages Don’t Originate From My Caller ID
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/text_fail_help">
                  How to Roll Failed Text Messages to a Call
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span>Reports</span>
              </HeadingItem1>
              <HeadingItems2>4</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/report_real_time_help">
                  The Reminders Screen – Real Time Reporting on Your Reminders
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/report_download_programatically_help">
                  Reports – Downloading Programmatically
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/report_nightly_email_help">
                  Reports – Nightly Emailed Reports{" "}
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/report_structure_content_help">
                  Reports – Structure and Content{" "}
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span>Spanish</span>
              </HeadingItem1>
              <HeadingItems2>1</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/spanish_help">Spanish Mapping</Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span>Triggers</span>
              </HeadingItem1>
              <HeadingItems2>3</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/trigger_create_and_edit_help">
                  Triggers – Creating and Editing
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/text_fail_help">
                  How to Roll Failed Text Messages to a Call
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/trigger_time_help">
                  How to Send an Appointment One Hour Prior to Appointment Time{" "}
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span> Phone Call Reminders</span>
              </HeadingItem1>
              <HeadingItems2>4</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/caller_help">
                  Caller IDs – Creating, Validating & Using
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/CreatingandEditingVF">
                  Voicefiles – Creating and Editing
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/pre_recorded_library_help">
                  Voice Files – Our Prerecorded Library
                </Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/text_fail_help">
                  How to Roll Failed Text Messages to a Call
                </Link>
              </List>
            </MenuList>
          </DocumentContainer>
          <DocumentContainer>
            <HeadingContiner>
              <HeadingItem1>
                <PiFilesFill />
                <span>Customization</span>
              </HeadingItem1>
              <HeadingItems2>2</HeadingItems2>
            </HeadingContiner>
            <MenuList>
              <List>
                <TbScript />
                <Link to="/email_customization_help">Email Customization</Link>
              </List>
              <List>
                {" "}
                <TbScript />
                <Link to="/custom_feilds_help">Custom Fields</Link>
              </List>
            </MenuList>
          </DocumentContainer>
        </ContextContainer>
      </MainContainer>
    </>
  );
};

export default HelpHome;
