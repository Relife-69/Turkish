import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: aliceblue;
  padding: 30px 0px;
`;
export const ContextContainer = styled.div`
  width: 90%;
  display: flex;
  align-items: start;
  justify-content: space-around;
  gap: 40px;
  flex-wrap: wrap;
`;

export const DocumentContainer = styled.div`
  width: 450px;
  padding: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border: none;
  flex-direction: column;
  background-color: white;
  border-radius: 8px;
`;

export const HeadingContiner = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  border-bottom: 1px solid #1376f8;
  padding-bottom: 15px;
`;

export const HeadingItem1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 32px;
  span {
    color: #1376f8;
    font-size: 28px;
  }
`;
export const HeadingItems2 = styled.div`
  width: 40px;
  height: 40px;
  background-color: #1376f8;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
`;
export const MenuList = styled.div`
  display: flex;
  width: 100%;
  align-items: start;
  justify-content: start;
  padding: 10px 15px;
  cursor: pointer;
  gap: 8px;
  flex-direction: column;
`;
export const List = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
  gap: 8px;
  a {
    color: black;
    text-decoration: none;
    &:hover {
      color: #1376f8;
    }
  }
`;
