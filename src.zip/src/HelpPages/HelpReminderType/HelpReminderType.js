import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import User2 from "../Images/User2.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  RequirmentsList2,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledHelpReminderType";

const HelpReminderType = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Appointment Reminders
              <MdKeyboardArrowRight />
              <span>Reminder Types – Creating and Editing</span>
            </HeadingContainer>
            <Heading>Reminder Types – Creating and Editing</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                Reminder Types Contain the Content of Your Reminders
              </TextList>
              <TextList>The Reminder Types Screen</TextList>
              <TextList>Creating a New Reminder Type</TextList>
              <TextList>Content Settings:</TextList>
              <TextList>Changing the Reminder Type Settings</TextList>
              <TextList>Changing the Reminder Type Content</TextList>
              <TextList>Adding or Modifying a Text Block</TextList>
              <TextList>Adding or Modifying a Voice File</TextList>
              <TextList>Cloning a Reminder Type</TextList>
              <TextList>Testing a Reminder Type</TextList>
              <TextList>One other thing!!!</TextList>
            </TextMenu>
            <Image src={User1} />
            <TextHeading>
              Reminder Types Contain the Content of Your Reminders
            </TextHeading>
            <Text>You can think of them as “Templates”.</Text>
            <Text>
              A Reminder Type can be a Call, Text, or Email. You can have as
              many Reminder Types as you like – there is no limit. You will
              define the content of your Reminders on the “Reminder Types” page.
              To get to the “Reminder Types” page, ensure that you are logged
              into your account. Then from the “Navigation Menu”, select
              “Reminder Settings” / “General Reminder Settings” / “Reminder
              Types (Templates)”.
            </Text>
            <Image src={User2} />
            <TextHeading>The Reminder Types Screen</TextHeading>
            <Text>
              The Reminder Types Screen shows you all of your reminder types.
              When you created your account, we automatically added some
              reminder types based on the preferences that you chose.
            </Text>
            <ListContainer>
              <Text>
                You can add as many Reminder Types as you want! There is no
                limit and no charge for additional Reminder Types.
              </Text>
              <Text>
                You may choose to keep it simple and Just have Three Reminder
                Types, one for each Outreach Method (Call, Text & Email). Or
                maybe just Call and Text.
              </Text>
              <Text>
                This is a basic set up. However, you may also choose to add
                additional Reminder Types to tailor your reminder messages even
                further.
              </Text>
              <Text>
                For example if you run a Medical Office, you may have Three
                Reminder Types to remind people for a Checkup. One for each
                Outreach Method (so they will be reminded in their preferred
                Outreach Method (Calls, Texts, or Emails).
              </Text>
              <Text>
                In addition, you may choose to set up an additional Three
                Reminder Types to remind people for Examinations where fasting
                or other requirements are necessary.
              </Text>
            </ListContainer>
            <Text>
              Also, if you are sending multiple reminders for one appointment,
              you would need to create separate Reminder Types for each
              outreach.
            </Text>
            <ListContainer>
              <RequirmentsList>
                Create a New Reminder Type Button – Takes you to a screen where
                you can create a new Reminder Type.
              </RequirmentsList>
              <RequirmentsList>
                Rem Type ID: This is the Unique “Reminder Type ID” that you may
                use in your import files or calendars to trigger a specific
                Reminder Type.
              </RequirmentsList>
              <RequirmentsList>
                Description: This is the Name that you choose to call your
                Reminder Type. “Sun Prairie Dental Demo Reminder Call” is a good
                name because it tells you that its a “Reminder” and a “Call”.
              </RequirmentsList>
              <RequirmentsList>
                Default: You should always have a “Default” Reminder Type.
                Typically this would be your text message. If you send files or
                use a calendar and do not specify the Reminder Type ID, we send
                the default Reminder Type.
              </RequirmentsList>
              <RequirmentsList>
                Text/Email/Call: This is the Outreach Method of the Reminder
                Type.
              </RequirmentsList>
              <RequirmentsList>
                Delete: Delete this Reminder Type.
              </RequirmentsList>
              <RequirmentsList>
                Settings: Click this link to choose setting such as when to send
                your reminder and what replies you will expect, and more!
              </RequirmentsList>
              <RequirmentsList>
                Content: Click this button to go to a page where you can edit
                the content of your Reminder Types.
              </RequirmentsList>
              <RequirmentsList>
                Clone: Use this button to create a copy of a Reminder Type. Then
                you can edit it and change it.
              </RequirmentsList>
              <RequirmentsList>
                Test: Use this button to send a test reminder to your phone or
                email.
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>Creating a New Reminder Type </TextHeading>
            <Text>
              To create a new Reminder Type, click on the “Create a New Reminder
              Type” button.
            </Text>
            <Text>
              This takes you to a screen where you can create a new Reminder
              Type.
            </Text>
            <ListContainer>
              <RequirmentsList>
                Enter a Description/Name : Enter a good name for your Reminder
                Type such as “Text 5 Days Prior”.
              </RequirmentsList>
              <RequirmentsList>
                Outreach Type: Select whether this Reminder Type is a Call,
                Text, or Email.
              </RequirmentsList>
              <RequirmentsList>
                Language: Set the primary language (English or Spanish). If you
                select Spanish, all dynamic content will be read in Spanish
                (such as date-time etc…).
              </RequirmentsList>
              <RequirmentsList>
                Set as Default Reminder: Select whether this is your “Default
                Reminder”.
              </RequirmentsList>
              <RequirmentsList>
                Time Frame Options: Chose the acceptable time frame to send this
                reminder.
              </RequirmentsList>
              <RequirmentsList1>
                Before Appt Date: Select this button if you want to send your
                reminder BEFORE the appt date (most typical). Then select how
                many days prior to the appt (From _ Days Prior) and how many
                days (To_Days Prior). Example – If you set this to “From 2 Days
                Prior” and “To 1 Days Prior”, and the appointment is on Friday,
                the reminder would be sent on Wednesday. However, if it’s not
                scheduled until Thursday, it would be send on Thursday. You can
                schedule it as many days in advance as you want and we will not
                send it until 2 days prior to the appointment.
              </RequirmentsList1>
              <RequirmentsList1>
                On Appt Date: Select this if you want the reminder to be sent ON
                the appt date. If this is selected, then you can choose how many
                hours prior to the appointment you want it to go out. Select
                zero to send it AT the Appt Time.
              </RequirmentsList1>
              <RequirmentsList1>
                After Appt Date: Select this box if its ok to send AFTER the
                appt date. This would not be typical but can be used to send
                follow up texts etc after the appointment. Example, you can send
                a link to a survey 7 days after the appointment.
              </RequirmentsList1>
              <RequirmentsList>
                Caller ID: Select which Caller ID to use. Typically you would
                use the default. Example – If you have multiple locations, you
                can create a separate Caller ID for each location so the calls
                originate from that particular locations office number.
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>Content Settings:</TextHeading>
            <Text>
              Choose the most appropriate content settings for your reminder. We
              will automatically create a reminder with these settings. You can
              customize the content and the settings further after creation.
            </Text>
            <Text>
              You can see the reminder text in the preview window below as you
              change the settings. Don’t worry if this is not exactly what you
              want. Just find the most appropriate settings and then we can fine
              tune it in the next step.
            </Text>
            <Text>Press “Submit” to create your new “Reminder Type”.</Text>
            <Image src={User1} />
            <TextHeading>Changing the Reminder Type Settings:</TextHeading>
            <Text>
              To change the Reminder Type settings such as when to send the
              reminder, or what responses to expect, click on “Settings” from
              the main Reminder Types screen.
            </Text>
            <Image src={User1} />
            <Text>
              This will pull up the same screen as “Create New Reminder Type”
              settings, with the addition of the “Expect Responses” area.
            </Text>
            <ListContainer>
              <RequirmentsList>
                Expect Responses – Choose whether you are expecting your
                customers to reply to this reminder.
              </RequirmentsList>
              <RequirmentsList>
                Responses – Choose the responses that you are expecting (up to
                3).
              </RequirmentsList>
              <Text>Press “Submit” to save the settings.</Text>
            </ListContainer>
            <Image src={User} />
            <TextHeading>Changing the Reminder Type Content </TextHeading>
            <Text>
              To change the actual content of your reminder, such as the text
              message that will be sent, or the voice files used, etc… click on
              “Content” from the main “Reminder Types” screen.
            </Text>
            <Image src={User} />
            <Text>
              This screen gives you complete control of your reminder type
              content.
            </Text>
            <ListContainer>
              <RequirmentsList>Message Area:</RequirmentsList>
              <RequirmentsList1>
                If the Outreach Method for this Reminder Type is “Call” then you
                can select from the following:
              </RequirmentsList1>
              <RequirmentsList2>
                Machine Only: Only play this message if an Answering Machine
                answers the call.
              </RequirmentsList2>
              <RequirmentsList2>
                Person Only: Only play this message if a Person Answers the
                call.
              </RequirmentsList2>
              <RequirmentsList2>
                Person or Machine: Play this message if a Person or a Machine
                answers the call.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 1: Play this message if the Person presses a “1” on
                the telephone keypad. *Only applicable if you are expecting a
                response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 2: Play this message if the Person presses a “2” on
                the telephone keypad. *Only applicable if you are expecting a
                response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 3: Play this message if the Person presses a “3” on
                the telephone keypad. *Only applicable if you are expecting a
                response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList1>
                If the Outreach Method for this Reminder Type is “Text Message”
                then you can select from the following:
              </RequirmentsList1>
              <RequirmentsList2>
                Message Content: Add this message to the Text Message content.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 1: Send a Text Message with this message if the
                person texts back with the First Expected Response (response
                word is in the reply text). *Only applicable if you are
                expecting a response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 2: Send a Text Message with this message if the
                person texts back with the Second Expected Response (response
                word is in the reply text). *Only applicable if you are
                expecting a response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 3: Send a Text Message with this message if the
                person texts back with the Third Expected Response (response
                word is in the reply text). *Only applicable if you are
                expecting a response to this Reminder Type.
              </RequirmentsList2>
              <RequirmentsList1>
                If the Outreach Method for this Reminder Type is “Email” then
                you can select from the following:
              </RequirmentsList1>
              <RequirmentsList2>
                Message Content: Add this message to the Email content.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 1: Display this message if the person presses the
                Button 1.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 2: Display this message if the person presses the
                Button 2.
              </RequirmentsList2>
              <RequirmentsList2>
                Response to 3: Display this message if the person presses the
                Button 3.
              </RequirmentsList2>
              <RequirmentsList>
                Message Type: Some Message Types are only available with certain
                Outreach Methods (Call, Text or Email):
              </RequirmentsList>
              <RequirmentsList1>
                Custom Voicefile: This is a Voicefile that you have either
                recorded or that you have had our In-House Voice Talent Record
                for you. *Calls only
              </RequirmentsList1>
              <RequirmentsList1>
                Dynamic Field: Choose from Appointment Date, Appointment Time,
                Company Name, Company Phone Number, Customer First & Last Name.
              </RequirmentsList1>
              <RequirmentsList1>
                Stock Voicefile: You can select from our library of pre-recorded
                Professional Voicefiles. *Calls Only
              </RequirmentsList1>
              <RequirmentsList1>
                Text Block: Select from Text Blocks that you have either created
                or are Stock.
              </RequirmentsList1>
              <RequirmentsList1>
                Line Break: Adds a line break to your Email Message. *Email only
              </RequirmentsList1>
              <RequirmentsList>
                File Selected: After you select the Message Type, you can Select
                the File from this list.
              </RequirmentsList>
              <RequirmentsList>
                File Text/Content: Displays the Content of the File Selected.
              </RequirmentsList>
              <Text>
                Additional Controls You can use the controls on the left side of
                the table to do the following:
              </Text>
              <RequirmentsList>Add a Row Below</RequirmentsList>
              <RequirmentsList>Delete the Current Row</RequirmentsList>
              <RequirmentsList>Move rows up or down</RequirmentsList>
              <Text>
                You can have a maximum of 20 Rows in your Reminder Type.
              </Text>
            </ListContainer>
            <TextHeading>Adding or Modifying a Text Block </TextHeading>
            <Text>
              To add or edit a text block, you can go to the{" "}
              <Link>“Text Blocks” </Link>page and add or edit your text blocks,
              then come back to this page (if you added one) and choose it from
              the text blocks list.
            </Text>
            <TextHeading>Adding or Modifying a Voice File </TextHeading>
            <Text>
              To add or edit a voice file, you can go to the{" "}
              <Link> “Voice Files” </Link>page and add or edit your voice files
              , then come back to this page (if you added one) and choose it
              from the voice files list.
            </Text>
            <Image src={User} />

            <TextHeading>Cloning a Reminder Type </TextHeading>
            <Text>
              Instead of creating a Reminder Type from scratch, you may want to
              just start with one you have already created and then modify it.
            </Text>
            <Text>
              In this case, just press the “Clone” button. Then you can rename
              it and edit it appropriately.
            </Text>
            <Image src={User} />
            <TextHeading>Testing a Reminder Type</TextHeading>
            <Text>
              It is always a good idea to test your Reminder Type to make sure
              it functions the way you want it to.
            </Text>
            <Text>
              Press this button if you want the system to text, call, or email
              you an example of this reminder type.
            </Text>
            <Image src={User} />
            <Text>
              Enter your phone number or email address to send yourself an
              example reminder.
            </Text>
            <Text>Press “Submit” to send.</Text>
            <Image src={User} />
            <TextHeading>One other thing!!!</TextHeading>
            <Text>
              We understand that this can be incredibly confusing and if you
              ever need help setting up your Reminder Types or anything else, we
              are happy to help you with it.{" "}
              <Link to="/contactus"> Just click here to contact us!</Link>
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default HelpReminderType;
