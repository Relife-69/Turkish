import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledCustomFeild";


const CustomFeilds = () => {
  return (
    <>
    <Navbar />
    <MainContainer>
      <ContextContainer>
        <HelpSidebar />
        <TextContainer>
          <HeadingContainer>
            Home <MdKeyboardArrowRight />
            Docs <MdKeyboardArrowRight />
            Appointment Reminders

            <MdKeyboardArrowRight />
            <span>Custom Fields</span>
          </HeadingContainer>
          <Heading>Custom Fields</Heading>
          <TextMenu>
            <HeadingContainer> Table of Contents </HeadingContainer>
            <TextList> What are Custom Fields? </TextList>
            <TextList>
            How Many Custom Fields can I Have?
            </TextList>
            <TextList> Adding Custom Fields to Your Reminder Types </TextList>
            <TextList> Step 1 - Add your custom field to the Reminder Type </TextList>
            <TextList>
            Step 2 - Add your Custom Field when you schedule your reminder

            </TextList>

{/* Box */}
            <TextList >Method 1 - Add custom fields when you schedule a reminder through the website
 
            </TextList>
            <TextList> Method 2 - Add custom fields when you upload a file
            </TextList>
            <TextList>
            Method 3 - Add custom fields when you schedule through Google Calendar
            </TextList>
            <TextList> Step 3 - Checking the Reminder Results
            </TextList>
          </TextMenu>
          {/* Video Here */}
          <TextHeading>What are Custom Fields?
          </TextHeading>
          <Text>
          Custom Fields are open text fields that may change on an individual basis.

Examples are things like “Payment Due Amount”, “Room Number”, “Doctor’s Name”, etc…

These are a type of Dynamic field which could also be like Appointment Date or Time, Company Name, Company Phone Number or Customer Name.

Custom Fields allow you to put ANY text value in when you schedule the reminder. Custom Fields will be added BY YOU when you schedule the reminder or upload a file.
          </Text>
          
          <TextHeading>
          How Many Custom Fields can I Have? 
          </TextHeading>
          <Text>
          We allow up to 3 Custom Fields and each custom field can be up to 2000 characters long.


          </Text>
          <TextHeading>How do you add Custom Fields?          </TextHeading>
          <Text>
          Custom Fields can be added on the Fly whether you schedule your reminders through the website, use a linked calendar, or upload files!


          </Text>
          <TextHeading>Adding Custom Fields to Your Reminder Types
          </TextHeading>
         <h4> Step 1 - Add your custom field to the Reminder Type </h4>

          <Text>
          Before you can use Custom Fields, you need to add them to your Reminder Types.<br/>

In the following example, I am using “PAYMENT AMOUNT” as the Custom Field for demonstration purposes.<br/>

You can see in the Reminder Content below that I am inserting a Custom Field where I want the payment amount to be.

          </Text>

          <h4> Step 2 - Add your Custom Field when you schedule your reminder 
          </h4>

          <Text>
          You can fill the value of your custom field when you schedule your reminder whether you use Google Calendar, Upload Files, or schedule through the website.


          </Text>
          {/* Image Here */}
          <Text>
          All 3 ways are shown below…

</Text>
          <TextHeading>Method 1 - Add custom fields when you schedule a reminder through the website
          </TextHeading>
          <ListContainer>
            <Text>To schedule a reminder for an existing customer, simply go to the customers page, choose the customer to send the reminder to and press “View/Add Reminders”.

</Text>
<h1>Image1</h1>
           
<Text>Then press the “Add New Reminder” button.

</Text><h1>Image2</h1>
<Text>Select the correct “Reminder Type”. In this case it is the “Payment Due Demo”. Then select the appointment date and fill in the “Custom Field 1” with the payment amount.
</Text><h1>Image3</h1>
<hr/>



          </ListContainer>



          <TextHeading>Method 2 - Add custom fields when you upload a file 

          </TextHeading>
          <ListContainer>
            <Text>To schedule a reminder by uploading a file, we can start with our template and then just modify as needed.

<br/> We need to know the Reminder Type ID first. This can be found on the Reminder Types page.

</Text>
<h1>Image1</h1>
           
<Text>Now we create our file and we put “15968” for the Reminder Type and “$75” for CustomField1. Then we simply upload the file through the import files page.



</Text><h1>Image2</h1>




          </ListContainer>

          <TextHeading>Method 3 - Add custom fields when you schedule through Google Calendar


</TextHeading>
<ListContainer>
  <Text>To schedule a reminder with Custom Fields through Google Calendar, we first need to connect the calendar. Once we have the calendar connected, we can simply schedule a reminder and add a Google Calendar Tag.


</Text>
<h1>Image1</h1>
 
<Text>Now in the Calendars Page, we can see that Reminder has been added with the appropriate details





</Text><h1>Image2</h1>




</ListContainer>

{/* Box */}

<TextHeading>Step 3 - Checking the Reminder Results



</TextHeading>

  <Text>Now after the Reminder has been sent, we can see the results and the full message in the Reminders Page.




</Text>
<h1>Image1</h1>
          <FeelingContainer>
            <Feelingtext>How You Are Feeling??</Feelingtext>
            <IconContainer>
              <Icon>
                <FaFaceGrinHearts />
              </Icon>
              <Icon>
                <FaFaceSmile />
              </Icon>
              <Icon>
                <FaFaceTired />
              </Icon>
            </IconContainer>
          </FeelingContainer>
          <ShareContainer>
            Share This Article :
            <SocialImage src={Facebook} alt="Facebok" target="blank" />
            <SocialImage src={Twitter} alt="Twitter" target="blank" />
            <SocialImage src={Instagram} alt="Instagram" target="blank" />
            <SocialImage src={Linkedin} alt="Linked" target="blank" />
          </ShareContainer>
        </TextContainer>
      </ContextContainer>
    </MainContainer>
    <Footer />
  </>
  )
}

export default CustomFeilds
