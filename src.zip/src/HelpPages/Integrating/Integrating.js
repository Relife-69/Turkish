import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledIntegrating";

const Integrating = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              <span>Integrating Into Your EMR</span>
            </HeadingContainer>
            <Heading>Integrating Into Your EMR</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> What we Need</TextList>
              <TextList>File Format</TextList>
              <TextList>Results and Replies</TextList>
              <TextList>How to Send and Receive Files</TextList>
              <TextList>
                If you would like to utilize our integration service, please
                contact us. We will need to know the following info to get
                started
              </TextList>
            </TextMenu>
            <Text>
              We provide the ability to integrate with most EMRs and scheduling
              software.
            </Text>
            <TextHeading>What we Need</TextHeading>
            <Text>
              Essentially all we need is a file with the following information:
            </Text>
            <ListContainer>
              <RequirmentsList>Customer First Name</RequirmentsList>
              <RequirmentsList>Customer Last Lame</RequirmentsList>
              <RequirmentsList>Primary Phone Number</RequirmentsList>
              <RequirmentsList>Appointment Date</RequirmentsList>
              <RequirmentsList>Appointment Time</RequirmentsList>
              <Text>You can also add additional information such as:</Text>
            </ListContainer>
            <ListContainer>
              <RequirmentsList> Customer ID (Optional)</RequirmentsList>
              <RequirmentsList>Appointment Type (Optional)</RequirmentsList>
              <RequirmentsList>
                Secondary Phone Number (Optional)
              </RequirmentsList>
              <RequirmentsList>Email Address (Optional)</RequirmentsList>
              <RequirmentsList>Language (English/Spanish)</RequirmentsList>
            </ListContainer>
            <TextHeading>File Format</TextHeading>
            <Text>
              We can work with most file formats including csv, pdf, and excel.
            </Text>
            <Text>Below is an example of a typical file.</Text>
            <Text>
              <Link>Below is an example of a typical file.</Link>
            </Text>
            <Image src={User} />
            <TextHeading>Results and Replies</TextHeading>
            <Text>
              We also provide the ability to programmatically download results
              and replies. In addition to these downloads, you can view them
              directly in our portal
            </Text>
            <Image src={User} />
            <TextHeading>How to Send and Receive Files</TextHeading>
            <Text>
              We provide several ways for you to send and receive files
              including:
            </Text>
            <ListContainer>
              <RequirmentsList>SFTP</RequirmentsList>
              <RequirmentsList>
                <Link>Utilize our Upload Service</Link>
              </RequirmentsList>
              <RequirmentsList>
                Upload Manually through the portal
              </RequirmentsList>
              <RequirmentsList>Utilize our API</RequirmentsList>
            </ListContainer>
            <TextHeading>
              If you would like to utilize our integration service, please
              contact us. We will need to know the following info to get started
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                What type of scheduling software do you use?
              </RequirmentsList>
              <RequirmentsList>
                Where is the data located (Onsite or Offsite)
              </RequirmentsList>
              <RequirmentsList>Who manages the data?</RequirmentsList>
              <RequirmentsList>
                Who is the main account contact?
              </RequirmentsList>
              <RequirmentsList>
                Do you have an IT Group Internal or External that manages your
                software?
              </RequirmentsList>
              <RequirmentsList>
                Who is the main technical contact?
              </RequirmentsList>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Integrating;
