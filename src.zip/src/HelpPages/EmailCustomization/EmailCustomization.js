import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledEmailCustomization";

const EmailCustomization = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Customization
              <MdKeyboardArrowRight />
              <span>Email Customization</span>
            </HeadingContainer>
            <Heading>Email Customization </Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                Customize your email reminders by adding your Logo, Colors, Web
                URL & Phone Number
              </TextList>
              <TextList>
                When you go to the Email Customization page, you are presented
                with the following screen:
              </TextList>
              <TextList>Example of an Email Reminder</TextList>
            </TextMenu>
            <TextHeading>
              Customize your email reminders by adding your Logo, Colors, Web
              URL & Phone Number
            </TextHeading>
            <Text>
              To get to the Company Customization page, ensure that you are
              logged into your account. Then go to the “Navigation Menu” / ”
              Reminder Settings” / “Email Reminder Settings” / “Email
              Customization”
            </Text>
            <Image src={User} />
            <TextHeading>
              When you go to the Email Customization page, you are presented
              with the following screen:
            </TextHeading>
            <RequirmentsList>
              Company Logo: Select your company logo image file.
            </RequirmentsList>
            <RequirmentsList>
              Include Logo in Emails?: If you do not want to include a logo in
              your emails, select “no”.
            </RequirmentsList>
            <RequirmentsList>
              Company URL: Enter the URL of your Companies website. The Web URL
              will be displayed at the bottom of your Email Reminders.
            </RequirmentsList>
            <RequirmentsList>
              Branding Color: Choose or Enter your Companies Branding Color. The
              Branding Color will be used as your border color.
            </RequirmentsList>
            <Image src={User} />
            <TextHeading>Example of an Email Reminder</TextHeading>
            <Text>
              The following <Link> email reminder </Link>shows the use of a
              Logo, Colored Border, Company Name, Company Phone, and Company
              URL.
            </Text>
            <Image src={User} />
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default EmailCustomization;
