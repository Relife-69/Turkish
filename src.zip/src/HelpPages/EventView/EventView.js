import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledEventView";

const EventView = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              Google Calendar
              <MdKeyboardArrowRight />
              <span>Google Calendar – Event View</span>
            </HeadingContainer>
            <Heading>Google Calendar – Event View</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> How to Get To Event View</TextList>
              <TextList>Viewing Event Details</TextList>
              <TextList>
                Some Additional Notes on the Calendar Event View
              </TextList>
            </TextMenu>
            <TextHeading>How to Get To Event View </TextHeading>
            <ListContainer>
              <RequirmentsList>
                From the “Navigation Menu”, click on “My Data Sources”, and then
                “Google Calendars”.
              </RequirmentsList>
              <RequirmentsList>
                Click on the “View Calendar” button for the calendar that you
                want to view.
              </RequirmentsList>
            </ListContainer>
            <Image src={User} />
            <ListContainer>
              <RequirmentsList>
                Events in Blue show the{" "}
                <Link>appointments from your Google Calendar </Link>that we were
                able to add reminders for.
              </RequirmentsList>
              <RequirmentsList>
                Events in Red show the appointments from your Google Calendar
                that we were not able to add reminders for.
              </RequirmentsList>
              <RequirmentsList1>
                Make sure these events have either a Calendar Tag or the Contact
                Name is in the title or description.
              </RequirmentsList1>
            </ListContainer>
            <Image src={User} />
            <TextHeading>Viewing Event Details</TextHeading>
            <Text>
              When you hover over an Event you can see details about it. The
              details shows the following info
            </Text>
            <ListContainer>
              <RequirmentsList>Event Title</RequirmentsList>
              <RequirmentsList>Tag (If we found one)</RequirmentsList>
              <RequirmentsList>Appt Time</RequirmentsList>
              <RequirmentsList>Whether we added a reminder</RequirmentsList>
              <RequirmentsList>
                Contact Found in Title: This is true if we located the contact
                in the title of the event and it matched an existing contact.
              </RequirmentsList>
              <RequirmentsList>
                Contact Found in Tag: This is true if we found the contact info
                in a Calendar Tag in the description.
              </RequirmentsList>
              <RequirmentsList>
                Reminder Type : This is the Reminder Type for the reminder that
                we added. Go to the Reminder Types page to find the Reminder
                Type.
              </RequirmentsList>
            </ListContainer>
            <Image src={User} />

            <TextHeading>
              Some Additional Notes on the Calendar Event View{" "}
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                You will only be able to see events in the calendar view
                starting on a date greater than today (aka tomorrow), and you
                will only be able to see events that are less than 30 days into
                the future.
              </RequirmentsList>
              <RequirmentsList>
                If you wish to view past appointment reminders, you can do that
                in the reminders screen.
              </RequirmentsList>
              <RequirmentsList>
                You may add events to your Google Calendar as many days in the
                future as you want, we just don’t sync them for more than 30
                days out.
              </RequirmentsList>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default EventView;
