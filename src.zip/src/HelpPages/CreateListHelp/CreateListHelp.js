import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledCreateListHelp";

const CreateListHelp = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Import Files
              <MdKeyboardArrowRight />
              <span>Contact Lists – Creating and Uploading</span>
            </HeadingContainer>
            <Heading>Contact Lists – Creating and Uploading</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>Create & Upload a Contact List</TextList>
              <TextList>
                To manually upload your contact list through our website (import
                files) follow these steps
              </TextList>
              <TextList>Import Status</TextList>
              <TextList>Determining the Import Results</TextList>
              <TextList>Further Details</TextList>
            </TextMenu>
            <TextHeading>Create & Upload a Contact List</TextHeading>
            <Text>
              Before you can upload your contact list, you need to create or
              export one. Your contact list will be a .csv file that contains
              your customer information. You can
            </Text>
            <ListContainer>
              <RequirmentsList>
                <Link>export a list from Google or Outlook</Link>
              </RequirmentsList>
              <RequirmentsList>
                <Link>
                  reate your own list (see the Create an Import File with
                  Contact Information Only section).
                </Link>
              </RequirmentsList>
              <RequirmentsList>
                <Link>Download a Sample List HERE</Link>
              </RequirmentsList>
              <Text>
                Please keep in mind that this is optional and there are other
                ways of creating appointments and adding customers such as
              </Text>
            </ListContainer>
            <ListContainer>
              <RequirmentsList>
                <Link>using “Calendar Tags” </Link>if you are using a Google
                Calendar
              </RequirmentsList>
              <RequirmentsList>
                <Link>
                  uploading files with appointment information (see the
                  uploading files with appointment information section).
                </Link>
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <Text>Sample Contact List</Text>
            <TextHeading>
              To manually upload your contact list through our website (import
              files) follow these steps{" "}
            </TextHeading>
            <RequirmentsList>
              Go to the Import Files page on the Website. To get to the “Import
              Files” page, ensure that you are logged into your account. Then
              from the “Navigation Menu”, choose “My Data Sources” / “Import
              Files”.
            </RequirmentsList>
            <Image src={User1} />
            <ListContainer>
              <RequirmentsList>Click on “Upload New File”</RequirmentsList>
              <RequirmentsList>
                Choose the Contact List (.csv file) on your Hard Drive
              </RequirmentsList>
              <RequirmentsList>
                Under “Select File to Upload”, press the “Choose File” button.
                Navigate to the file on your computer and select it. Then click
                “Evaluate File”.
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />

            <TextHeading>Import Status</TextHeading>
            <Text>You will see the status of your import file:</Text>
            <ListContainer>
              <RequirmentsList>
                Upload Progress: Shows whether we received the file
              </RequirmentsList>
              <RequirmentsList>
                Evaluation Progress: We attempt to evaluate the file for
                validation
              </RequirmentsList>
              <RequirmentsList>
                Import Progress: Shows the status of the final import of your
                list
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>Determining the Import Results </TextHeading>
            <Text>
              If the file was not successfully processed, please check the
              format to make sure it is correct. If the file was successfully
              processed, you can see how many contacts it found and added in the
              list.
            </Text>
            <Image src={User1} />
            <TextHeading>Further Details </TextHeading>
            <Text>
              You can click on the “View Details” button for details on exactly
              what was imported. You can also go to the “Customers Page” to see
              all of your customers.
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default CreateListHelp;
