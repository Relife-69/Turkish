import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: aliceblue;
  padding: 30px 0px;
`;
export const ContextContainer = styled.div`
  width: 90%;
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 40px;
  flex-wrap: wrap;
`;

export const TextContainer = styled.div`
  padding: 20px;
  width: 800px;
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 15px;
  flex-wrap: wrap;
  flex-direction: column;
`;

export const HeadingContainer = styled.h1`
  display: flex;
  font-size: 18px;
  font-weight: 400;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  gap: 5px;
  span {
    color: #1376f8;
  }
  a {
    color: black;
  }
`;

export const Heading = styled.h1`
  font-size: 38px;
  font-weight: 700;
`;

export const TextMenu = styled.ul`
  background-color: white;
  border: none;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: start;
  padding: 20px;
`;

export const TextList = styled.a`
  text-decoration: none;
  color: black;
  font-size: 16px;
  cursor: pointer;
  font-weight: 300;
  &:hover {
    color: #1376f8;
  }
`;

export const Text = styled.p`
  font-size: 16px;
  font-weight: 300;
`;

export const TextHeading = styled.h1`
  font-size: 32px;
  font-weight: 600;
`;

export const ListContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 5px;
`;

export const RequirmentsList = styled.li`
  font-size: 16px;
  font-weight: 300;
  padding-left: 12px;
`;
export const RequirmentsList1 = styled.li`
  font-size: 16px;
  font-weight: 300;
  padding-left: 25px;
  list-style: circle;
`;
export const RequirmentsList2 = styled.li`
  font-size: 16px;
  font-weight: 300;
  padding-left: 40px;
  list-style: square;
`;
export const Image = styled.img`
  width: 40%;
  height: 50%;
  border-radius: 10px;
`;

export const FeelingContainer = styled.div`
  width: 100%;
  height: 40px;
  align-items: center;
  display: flex;
  justify-content: space-around;
  background-color: white;
  padding: 30px 0px;
`;
export const Feelingtext = styled.div`
  font-size: 18px;
  font-weight: 300;
  width: 30%;
`;

export const IconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 30%;
`;

export const Icon = styled.div`
  font-size: 18px;
  font-weight: 300;
  background-color: #1376f8;
  color: white;
  padding: 8px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: white;
    color: #1376f8;
  }
`;

export const ShareContainer = styled.div`
  width: 100%;
  align-items: center;
  display: flex;
  justify-content: start;
  gap: 10px;
`;

export const SocialImage = styled.img`
  width: 30px;
  height: 30px;
  border-radius: 50%;
  cursor: pointer;
`;
