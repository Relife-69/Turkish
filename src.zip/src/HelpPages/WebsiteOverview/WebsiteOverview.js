import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  RequirmentsList2,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledWebsiteOverview";

const WebsiteOverview = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Tutorials
              <MdKeyboardArrowRight />
              <span>Website Overview and New Company Walkthrough</span>
            </HeadingContainer>
            <Heading>Website Overview and New Company Walkthrough</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                How to Configure your Company for the First Time{" "}
              </TextList>
              <TextList>Before you dive in, please let us help you!! </TextList>
              <TextList>Company & Website Overview </TextList>
              <TextList>Getting Started Tutorial</TextList>
              <TextList>1. Put Your Account Into Test Mode</TextList>
              <TextList>3. Add a Customer</TextList>
              <TextList>Customers can be added several ways.</TextList>
              <TextList>4. Schedule an Appointment for Your Customer</TextList>
              <TextList>5. Check the Results on the Reminders Page</TextList>
            </TextMenu>
            <TextHeading>
              How to Configure your Company for the First Time{" "}
            </TextHeading>
            <Text>
              You will soon learn just how easy and how flexible our Website is
              to use. To make the process even easier, we have created this
              Company Walk Through to help you set up your company. This Walk
              Through will take you through the following steps
            </Text>
            <ListContainer>
              <RequirmentsList>Customizing your Company</RequirmentsList>
              <RequirmentsList>
                Setting up <Link>Reminder Types</Link>
              </RequirmentsList>
              <RequirmentsList>
                Setting up <Link>Reports</Link>
              </RequirmentsList>
              <RequirmentsList>
                Adding <Link>Customers</Link>
              </RequirmentsList>
              <RequirmentsList>
                Adding<Link>Appointments</Link>
              </RequirmentsList>
              <RequirmentsList>
                <Link>Payment Information</Link>
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              Before you dive in, please let us help you!!{" "}
            </TextHeading>
            <Text>
              If you want to save yourself some time, let us set up your company
              with you! We will schedule a free quick web conference with you to
              help you get set up and answer any questions you have. Click here
              to create a ticket and let us know you want help getting started
              or email us at support@appointmentreminder.bot.
            </Text>
            <Text>…or if you insist on doing it yourself…</Text>
            <Image src={User1} />
            <Image src={User1} />

            <TextHeading>1. Put Your Account Into Test Mode</TextHeading>
            <Text>
              Before we get started setting up your company, go to the “My
              Account” menu and then go to “Test Mode/Live Mode” page. Go
              through the steps to put your account into test mode.
            </Text>
            <Text>
              Changing your account to test mode will ensure that no reminders
              go out until you have everything set up correctly. With test mode,
              you will still be able to test all of your reminder types, but no
              reminders will be sent out. *Don’t forget to switch back to ‘Live
              Mode’ when you are ready to go live.
            </Text>
            <TextHeading>
              2. Ensure That You Have Reminder Types Created
            </TextHeading>
            <Text>
              When your account was created, there should have been some
              Reminder Types created based on your preferences.
            </Text>
            <Text>
              <Link>See our posting on Reminder Types here.</Link>
            </Text>
            <TextHeading>3. Add a Customer </TextHeading>
            <TextHeading>Customers can be added several ways. </TextHeading>

            <ListContainer>
              <RequirmentsList>
                {" "}
                They can be manually
                <Link>added through the website interface. </Link>
              </RequirmentsList>
              <RequirmentsList>
                They can be uploaded to our site through{" "}
                <Link>import files.</Link>
              </RequirmentsList>
              <RequirmentsList>
                They can be
                <Link> added on-the-fly through calendars.</Link>
              </RequirmentsList>
              <Text>
                <Link>
                  For now, just go to the “Customers” page and add one.
                </Link>
              </Text>
            </ListContainer>
            <TextHeading>
              4. Schedule an Appointment for Your Customer
            </TextHeading>
            <Text>
              Just like adding Customers, Appointments can also be added several
              ways.
            </Text>
            <ListContainer>
              <RequirmentsList>
                {" "}
                They can be manually
                <Link>added through the website interface. </Link>
              </RequirmentsList>
              <RequirmentsList>
                They can be uploaded to our site through{" "}
                <Link>import files.</Link>
              </RequirmentsList>
              <RequirmentsList>
                They can be
                <Link> added on-the-fly through calendars.</Link>
              </RequirmentsList>
            </ListContainer>
            <TextHeading>
              5. Check the Results on the Reminders Page
            </TextHeading>
            <Text>
              Now you can go to the “Reminders” page to check the results. Make
              sure you put your account back into “Live Mode” or your reminders
              won’t be sent.
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default WebsiteOverview;
