import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTextFail";

const TextFail = () => {
  return (
    <>
    <Navbar />
    <MainContainer>
      <ContextContainer>
        <HelpSidebar />
        <TextContainer>
          <HeadingContainer>
            Home <MdKeyboardArrowRight />
            Docs <MdKeyboardArrowRight />
            Phone Call Reminders

            <MdKeyboardArrowRight />
            <span>How to Roll Failed Text Messages to a Call</span>
          </HeadingContainer>
          <Heading>HOW TO ROLL FAILED TEXT MESSAGES TO A CALL
          </Heading>
          <TextMenu>
            <HeadingContainer> Table of Contents </HeadingContainer>
            <TextList>Check out our Tutorial Video on YouTube! </TextList>
            <TextList>
            Step 1 - Ensure You Have a Text Message Reminder Type            </TextList>
            <TextList> Step 2 - Look at the Text Reminder Type Settings
            </TextList>
            <TextList> Step 3 - Look at the Text Reminder Type Content
            </TextList>
            <TextList>
            Step 4 - Create the Call Reminder Type


            </TextList>
            <TextList>
            Step 5 - Create the Trigger


            </TextList>

          
           
          </TextMenu>
          <Text>You can easily create a trigger to roll your failed text messages to automated calls.<br/>

          Rolling failed text messages to calls can provide several benefits:


          </Text>
          <Text>
          Increased Reliability: Ensures that the reminder reaches the recipient even if the initial method (text message) fails due to issues like network problems or incorrect phone numbers.
Reduced No-Shows: By ensuring the reminder is delivered through an alternative method, the system helps in reducing missed appointments, which can improve scheduling efficiency and reduce lost revenue.
Customer Satisfaction: Demonstrates a proactive approach to customer service by ensuring important information reaches the recipient, which can enhance the overall experience and satisfaction.
Backup Plan: Acts as a fail-safe mechanism to ensure critical communications are not lost if one method fails.
          </Text>
          
          <TextHeading>
          Check out our Tutorial Video on YouTube! 
          <h1>Youtube Video</h1>
          </TextHeading>
          <Text>
          Failed text messages don’t count against your monthly allotment of reminders so there is really no down side to rolling them to calls.



          </Text>
          <TextHeading>Step 1 - Ensure You Have a Text Message Reminder Type          </TextHeading>
          <Text>
          Before we create a trigger to roll failed texts to calls, we need to ensure that we have the appropriate reminder types set up.  For this scenario, we will need a text reminder type and a call reminder type.

To get to the reminder types page, hover over the navigation menu and then Reminder Settings, General Reminder Settings, Reminder Types (Templates)
<h1>Image1</h1>
          </Text>
          <TextHeading>Step 2 - Look at the Text Reminder Type Settings
          </TextHeading>
          <Text>
          For the sake of this tutorial, I will assume we have already created our text message reminder type. Lets take a quick look at it.<br/>

Click on the settings page to look at the settings. Your settings may be different than mine, but to run down the settings really quick…this is a text reminder, it is in English, and it is our default reminder.<br/>

The acceptable window to send this reminder is up to 2 days prior to the appointment and up to and including 1 day before the appointment.<br/>

This simply means that if you schedule this reminder prior to 2 days before the appointment, we will hold it in cue until 2 days prior. Also, if you schedule your reminder 1 day before the appointment, it can still go out.<br/>

Expected Response – we are expecting the recipient to text back with either a 1 or a 2.<br/>

And we are using our default caller ID to send this reminder.<br/>
<h1>Image2</h1>

          </Text>

          <TextHeading> Step 3 - Look at the Text Reminder Type Content 
          </TextHeading>

          <Text>
          Now let’s look at the content of this reminder. To do this click on “cancel” to go back to the reminder types screen. Now click on ”Content” for the text reminder type. 

Essentially, we are just reminding them on an upcoming appointment, we are including the appointment date and time, and we are prompting for either a 1 to confirm or a 2 to cancel. 

We are also sending an additional confirmation or cancellation message back depending on whether they text a 1 or a 2.

          </Text>
          <h1>Image3</h1>
         

          <TextHeading>Step 4 - Create the Call Reminder Type

          </TextHeading>
          <ListContainer>
            <Text>Now lets create an identical Automated Call. To do this, click cancel to go back to the reminder types screen. Now click the clone button for the text reminder type. Then click on Settings for the cloned reminder and we will change it to a call.

Lets change the name to Demo Call.

Then let’s change the Outreach type to Call.

For the keypresses, lets type “Confirm” for key press 1 and “Cancel” for keypress 2.

Now press Submit to save it.
<h1>Image4</h1>
</Text>

           
<Text>Let’s take a quick look at the content. Since we cloned the text reminder, the content is exactly the same as the text message. We need to make a slight adjustment to this so we only prompt for a confirmation or cancellation if a person answers the call. For the text block where we ask for a reply, change the Message Area from “Person or Machine” to “Person Only”. This way, we wont prompt an answering machine or voice mail for a reply.


<h1>Image5</h1>
</Text>
<TextHeading>Step 5 - Create the Trigger </TextHeading>
<Text>Now that we have our reminder types created, we can create the trigger.<br/>

To get to the triggers page, hover over the navigation menu and then Reminder Settings, General Reminder Settings, Triggers/Rules.<br/>

Click “Add a New Trigger”<br/>

For trigger name, type something like “Roll Failed Text to Call”.<br/>

For the Seed Reminder Type, select your text message reminder.<br/>

For Result to Trigger, select “Reminder Failed”.<br/>

For Triggered Action, select ”Schedule Reminder”.<br/>

And for Triggered Reminder Type, select your call type reminder.<br/>

Press “Submit” to save it.
</Text><h1>Image6</h1>
</ListContainer>
          <FeelingContainer>
            <Feelingtext>How You Are Feeling??</Feelingtext>
            <IconContainer>
              <Icon>
                <FaFaceGrinHearts />
              </Icon>
              <Icon>
                <FaFaceSmile />
              </Icon>
              <Icon>
                <FaFaceTired />
              </Icon>
            </IconContainer>
          </FeelingContainer>
          <ShareContainer>
            Share This Article :
            <SocialImage src={Facebook} alt="Facebok" target="blank" />
            <SocialImage src={Twitter} alt="Twitter" target="blank" />
            <SocialImage src={Instagram} alt="Instagram" target="blank" />
            <SocialImage src={Linkedin} alt="Linked" target="blank" />
          </ShareContainer>
        </TextContainer>
      </ContextContainer>
    </MainContainer>
    <Footer />
  </>
  )
}

export default TextFail
