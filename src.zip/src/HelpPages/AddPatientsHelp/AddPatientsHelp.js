import React from "react";

const AddPatientsHelp = () => {
  return <div></div>;
};

export default AddPatientsHelp;
