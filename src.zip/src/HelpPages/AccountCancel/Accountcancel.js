import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledAccountCancel";

const Accountcancel = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Account Settings
              <MdKeyboardArrowRight />
              <span>How Do I Cancel My Account?</span>
            </HeadingContainer>
            <Heading>How Do I Cancel My Account?</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> If Your Account is in a Trial Period</TextList>
              <TextList> To Cancel an Existing Account</TextList>
              <TextList>
                {" "}
                If you wish to leave your account open but want to ensure that
                no reminders go out you can do this by putting your account in
                ‘Test Mode’.{" "}
              </TextList>
            </TextMenu>
            <Text>
              With our services there are no contracts, set-up fees, or
              cancellation charges.
            </Text>
            <TextHeading>If Your Account is in a Trial Period </TextHeading>
            <Text>
              If you are in the trial period, and have not entered any payment
              information, you can simply let your account expire and you will
              not be charged.
            </Text>

            <TextHeading>To Cancel an Existing Account</TextHeading>
            <Text>
              If you are a current customer and wish to cancel your account, we
              make it super easy to do that. You just need to send an email to
              support@appointmentreminder.bot with the subject line of “Cancel
              Account”. This will create a ticket that will be a permanent
              record for you and us. Make sure you include the following
              information in the email:
            </Text>
            <ListContainer>
              <RequirmentsList1>Your company name</RequirmentsList1>
              <RequirmentsList1>
                Your name and contact info (in case we have questions)
              </RequirmentsList1>
              <RequirmentsList1>
                Reason for cancelling (optional)
              </RequirmentsList1>
              <Text>
                Once we receive the ticket we will respond quickly (usually
                within 2 business days). You will get an email back to let you
                know that we have received the request. If you have any
                questions you can always contact us.
              </Text>
            </ListContainer>
            <Text>
              *Please note – we charge at the end of the billing cycle so you
              may get one last monthly charge after your account is closed.
            </Text>
            <TextHeading>
              If you wish to leave your account open but want to ensure that no
              reminders go out you can do this by putting your account in ‘Test
              Mode’. #
            </TextHeading>
            <Image src={User} />
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Accountcancel;
