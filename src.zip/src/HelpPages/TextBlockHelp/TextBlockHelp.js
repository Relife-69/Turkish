import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTextBlockHelp";

const TextBlockHelp = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Appointment Reminders
              <MdKeyboardArrowRight />
              <span>Text Blocks – Creating and Editing</span>
            </HeadingContainer>
            <Heading>Text Blocks – Creating and Editing</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>What is a Text Block?</TextList>
              <TextList>The Text Blocks Screen</TextList>
              <TextList>Editing Text Blocks </TextList>
              <TextList>Creating a New Text Block</TextList>
              <TextList>How to Use a Text Block in Your Reminders</TextList>
            </TextMenu>
            <TextHeading>What is a Text Block?</TextHeading>
            <Text>
              A Text Block is simply a block of text that you can use when
              building your Reminder Types. You can use Text Blocks in Calls
              (Text to Speech), Text Messages, or Emails.
            </Text>
            <Text>
              To get to the “Text Blocks” page, ensure that you are logged into
              your account. Then under the “Navigation Menu”, select
            </Text>
            <Image src={User1} />
            <TextHeading>The Text Blocks Screen </TextHeading>
            <Text>
              The Text Blocks screen will show you a list of all of your text
              blocks.
            </Text>
            <TextHeading>Editing Text Blocks </TextHeading>
            <Text>
              You can edit existing text blocks. However, please note that if
              you change a text block, it will be changed in ALL the Reminder
              Types that you are using. For this reason, often it is better to
              create a new text block. There are some text blocks that you
              cannot edit.
            </Text>
            <Image src={User1} />
            <TextHeading>Creating a New Text Block </TextHeading>
            <Text>
              To create a new text block, just click on “Add New Record”. Then
              enter a name for your text block and the text block content.
            </Text>
            <Text>Press “Update” to save it.</Text>
            <Image src={User1} />
            <TextHeading>How to Use a Text Block in Your Reminders</TextHeading>
            <Text>
              Once you have created a text block, you can easily use it in your
              reminders. To do this, go to the <Link> “Reminder Types”</Link>
            </Text>
            <Text>
              {" "}
              page and then click on the “Content” button. This screen allows
              you to add text blocks to your reminders.
            </Text>
            <Text>
              <Link>
                Please see our help documentation on Reminder Types for more
                info.
              </Link>
            </Text>
            <Image src={User1} />
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default TextBlockHelp;
