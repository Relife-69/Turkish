import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledPreRecorded";
const PreRecordedLibrary = () => {
  return (
    <div>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Phone Call Reminders
              <MdKeyboardArrowRight />
              <span>Voice Files – Our Prerecorded Library</span>
            </HeadingContainer>
            <Heading>Voice Files – Our Prerecorded Library</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                Our extensive prerecorded voice file library contains most of
                the basic phrases that you might use in your reminders. Here are
                a few examples:
              </TextList>
              <TextList>
                Record Your Own Voicefiles or Request Professional Voicefiles
              </TextList>
            </TextMenu>
            <TextHeading>
              We offer an extensive library of prerecorded voice files that you
              can use in your Phone Call reminders free of charge
            </TextHeading>
            <Text>
              {" "}
              “I am calling to remind you of your upcoming appointment on…”
              <br />
              “If you wish to cancel or reschedule this appointment, please
              call…”
              <br />
              “To confirm this appointment, please press 1. To reschedule this
              appointment, please press 2.”
              <br />
              “You do not need to do anything to confirm this appointment.”
              <br />
              Numbers zero through fifty
              <br />
              Months January-December
              <br />
              Days of the Week
              <br />
              Days of the Month
              <br />
              AM, PM, Afternoon, Morning
              <br />
              More!
              <br />
              <a>
                Click here to download this list in an excel spreadsheet for
                easy reference
              </a>
            </Text>

            <TextHeading>
              Record Your Own Voicefiles or Request Professional Voicefiles
            </TextHeading>
            <Text>
              In addition to using this library of prerecorded voice files, we
              also offer the ability for you to record your own voice files over
              the phone. Recording your own voice files over the phone is simple
              and there is no charge for it. This can be done in the VoiceFiles
              section of the website. <br />
              To add any of these voice files in your reminders, simply edit
              your reminder type by clicking on the pencil icon in the “Reminder
              Types” tab and choose “Stock Voicefile” for message type. Go to
              the Reminder Types section for more information on this.
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </div>
  );
};

export default PreRecordedLibrary;
