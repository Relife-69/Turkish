import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledCreatingandEditingVF";
const CreatingandEditingVF = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Phone Call Reminders
              <MdKeyboardArrowRight />
              <span>Voicefiles – Creating and Editing</span>
            </HeadingContainer>
            <Heading>Voicefiles – Creating and Editing</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                The Voice Files Screen
                <br />
                Create a New Voice File
                <br />
                Recording a Voice File
                <br />
                Triggering a Call
                <br />
                Adding a Voice File to Your Reminders
              </TextList>
            </TextMenu>
            <Text>
              Voice Files are used in your Phone Call Reminders. There are
              several types of voice files that are available to you:
              <br />
              Stock Voice Files: We have a library of prerecorded voice files
              that are available for you to use in your reminders.
              <br />
              Record your own voice files: Trigger a phone call to yourself and
              create your own voice files for use in your reminders.
              <br />
              Use “Text to Speech”. To do this, you would create a “Text Block”
              instead of a Voice File.
              <br />
              To get to the “Voice Files” page, ensure that you are logged into
              your account. Then under the “Navigation Menu”, select “Reminder
              Settings” / “Call Reminder Settings” / “Voice Files”.
            </Text>
            <h1>image1</h1>

            <TextHeading>Create a New Voice File</TextHeading>
            <Text>
              To create a new voice file, click on “Create a New Voice file”.
              <br />
              Voice File Name: Choose a name for this Voice File.
              <br />
              Voice File Content: Enter the content of the Voice File.
              <br />
              Press “Update” to save.
              <br />
              Now, you can record it.
              <h1>image3</h1>
            </Text>
            <TextHeading>Triggering a Call</TextHeading>
            <Text>
              From this screen, you can enter your phone number and the system
              will call you and allow you to record the file.
              <br />
              Just enter your phone number and press “Call Me”.
              <br />
              Answer the call and go through the prompts to record the file.
              <h1>Image4</h1>
            </Text>
            <TextHeading>Adding a Voice File to Your Reminders</TextHeading>
            <Text>
              Once you have created a Voice File, you can easily use it in your
              call reminders. To do this, go to the “Reminder Types” page and
              then click on the “Content” button. This screen allows you to add
              Voice Files to your reminders.
              <h1>Image5</h1>
            </Text>

            <TextHeading>
              {" "}
              Step 3 - Look at the Text Reminder Type Content
            </TextHeading>

            <Text>
              Now let’s look at the content of this reminder. To do this click
              on “cancel” to go back to the reminder types screen. Now click on
              ”Content” for the text reminder type. <br />
              Essentially, we are just reminding them on an upcoming
              appointment, we are including the appointment date and time, and
              we are prompting for either a 1 to confirm or a 2 to cancel.{" "}
              <br />
              We are also sending an additional confirmation or cancellation
              message back depending on whether they text a 1 or a 2.
            </Text>
            <h1>Image6</h1>

            <Text>
              Now lets create an identical Automated Call. To do this, click
              cancel to go back to the reminder types screen. Now click the
              clone button for the text reminder type. Then click on Settings
              for the cloned reminder and we will change it to a call. Lets
              change the name to Demo Call. Then let’s change the Outreach type
              to Call. For the keypresses, lets type “Confirm” for key press 1
              and “Cancel” for keypress 2. Now press Submit to save it.
              <h1>Image4</h1>
            </Text>

            <Text>
              Let’s take a quick look at the content. Since we cloned the text
              reminder, the content is exactly the same as the text message. We
              need to make a slight adjustment to this so we only prompt for a
              confirmation or cancellation if a person answers the call. For the
              text block where we ask for a reply, change the Message Area from
              “Person or Machine” to “Person Only”. This way, we wont prompt an
              answering machine or voice mail for a reply.
              <h1>Image5</h1>
            </Text>
            <TextHeading>Step 5 - Create the Trigger </TextHeading>
            <Text>
              Now that we have our reminder types created, we can create the
              trigger.
              <br />
              To get to the triggers page, hover over the navigation menu and
              then Reminder Settings, General Reminder Settings, Triggers/Rules.
              <br />
              Click “Add a New Trigger”
              <br />
              For trigger name, type something like “Roll Failed Text to Call”.
              <br />
              For the Seed Reminder Type, select your text message reminder.
              <br />
              For Result to Trigger, select “Reminder Failed”.
              <br />
              For Triggered Action, select ”Schedule Reminder”.
              <br />
              And for Triggered Reminder Type, select your call type reminder.
              <br />
              Press “Submit” to save it.
            </Text>
            <h1>Image6</h1>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default CreatingandEditingVF;
