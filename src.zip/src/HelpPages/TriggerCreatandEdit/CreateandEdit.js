import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledCreatandEdit";
const CreateandEdit = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Triggers
              <MdKeyboardArrowRight />
              <span>Triggers – Creating and Editing</span>
            </HeadingContainer>
            <Heading>Triggers – Creating and Editing</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                What Are Triggers?
                <br />
                Triggers Tutorial
                <br />
                Roll Failed Text To Call Tutorial
                <br />
                What do I use Triggers for?
                <br />
                The Triggers Screen
                <br />
                Is there a charge to create Triggers?
                <br />
                Creating and Editing Triggers?
              </TextList>
            </TextMenu>
            <TextHeading>What Are Triggers? </TextHeading>
            <Text>
              Triggers allow you to create multiple reminders for an appointment
              or send text or email alerts when certain conditions are met.
            </Text>

            <h1>Youtube Video1 of Triggers Tutorial</h1>
            <h1>Youtube Video1 of Roll Failed Text To Call Tutorial</h1>

            <TextHeading>What do I use Triggers for?</TextHeading>
            <Text>
              Here are some examples of what you could use triggers for:
              <br />
              Roll failed text messages to calls
              <br />
              Roll failed calls to emails
              <br />
              Send one reminder a week prior and another a day prior to the
              appointment
              <br />
              Send a text or email alert to yourself when a customer cancels or
              confirms an appointment
              <br />
              Send a followup text, call, or email to a customer AFTER an
              appointment
              <br />
              More!
            </Text>
            <TextHeading>The Triggers Screen</TextHeading>
            <Text>
              To get to the Triggers Screen, ensure you are logged into your
              account. Then under the “Navigation Menu” select “Reminder
              Settings” / “General Reminder Settings” / “Triggers/Rules”.
              <h1>Image1</h1>
            </Text>

            <TextHeading>Is there a charge to create Triggers?</TextHeading>
            <Text>
              There is no charge to create them. However, if your trigger adds a
              reminder, you will be charged for that reminder. Text alerts and
              Email alerts count as a reminder and are subject to the same
              charges. *Note – You do not need to add triggers in order to see
              the results of the reminders. This information is all contained in
              our Reports, which there is no charge for. Text and Email alerts
              are really intended to give you instant feedback on a reminder so
              you can take immediate action if necessary.
            </Text>

            <TextHeading> Creating and Editing Triggers?</TextHeading>

            <Text>
              The Triggers Screen will allow you to create new triggers and edit
              existing ones.
              <br />
              Trigger Name: This is the name of your trigger. This will also be
              in the “View Triggered Alerts” page so choose something that makes
              logical sense such as “Customer Confirmed Appointment”.
              <br />
              Reminder Type Seed: This is the “Reminder Type” that will initiate
              the trigger. Choose from any “Reminder Types” that you have set
              up.
              <br />
              Result To Trigger: This is the result of the “Reminder Type Seed”
              that will initiate the trigger.
              <br />
              Reminder Sent Successfully: This will initiate the trigger if the
              reminder was sent successfully.
              <br />
              Reminder Attempted (Successful or Failed): This will initiate the
              trigger if the reminder was attempted and either failed or was
              successful.
              <br />
              Reminder Sent Successfully / No Response: This will initiate the
              trigger if the reminder was sent successfully but no response was
              given. (Waits 24 hours on Email & Text, Calls trigger immediately)
              <br />
              Reminder Sent Successfully / No Response / 2 hrs passed: This will
              initiate the trigger if the reminder was sent successfully but no
              response was given. (Waits 2 hours on ALL reminder types)
              <br />
              Reminder Failed: This will initiate the trigger if the reminder
              fails (possible reasons could be invalid mobile number, no answer,
              no email, etc…).
              <br />
              Appt Passed / No Response: This will initiate the trigger if the
              reminder was sent successfully but no response was given AND the
              appointment date and time has passed.
              <br />
              Response to 1: This will initiate the trigger if the reminder was
              sent successfully and the person responded with your “Response to
              1” value.
              <br />
              Response to 2: This will initiate the trigger if the reminder was
              sent successfully and the person responded with your “Response to
              2” value.
              <br />
              Response to 3: This will initiate the trigger if the reminder was
              sent successfully and the person responded with your “Response to
              3” value.
              <br />
              Triggered Action: This is what will happen if the trigger is
              initiated. Possible Options are:
              <br />
              Schedule Reminder: This will schedule a reminder for whatever you
              choose in the “Rem Type Triggered” field. This is the most common
              option and will allow you to set up multiple reminders for an
              appointment. All values from the original reminder type will be
              carried over such as (Name, Appointment Date & Time, etc).
              <br />
              Send Email Alert: This will send an email alert to the email
              address that you enter.
              <br />
              Send Text Alert: This will send a text alert to the phone number
              that you enter.
              <br />
              “Create New Trigger” Button: Click this button to add a new
              trigger
              <br />
              “View Triggered Alerts” This will show you a list of all text or
              email “Alerts” that were triggered. Scheduled Reminder Types will
              not be in this list.
              <h1>Image2</h1>
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default CreateandEdit;
