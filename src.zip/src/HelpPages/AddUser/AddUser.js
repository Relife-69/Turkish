import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledAddUser";

const AddUser = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Account Settings
              <MdKeyboardArrowRight />
              <span>How to Add Additional Users to Your Account</span>
            </HeadingContainer>
            <Heading>HOW TO ADD ADDITIONAL USERS TO YOUR ACCOUNT</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> There are 3 Types of Users </TextList>
              <TextList>
                {" "}
                The User that Created the Account is an Admin{" "}
              </TextList>
              <TextList> How to Create Additional Users </TextList>
            </TextMenu>
            <Text>
              {" "}
              Additional users are unique logins for multiple people or services
              that are using the same account. This way, each person that is
              accessing the account has their own login and permissions.
            </Text>
            <TextHeading>There are 3 Types of Users</TextHeading>
            <Text>
              1: Read Only – Read only users can only view the{" "}
              <Link> “Reminders” page. </Link>
              This allows them to check in real time, all the reminders in que,
              all sent reminders, and replies to the reminders. They can also
              save the results to a csv file.
            </Text>
            <Text>
              2: Admin – Admins have access to the entire site and have the same
              permissions as the main user.
            </Text>
            <Text>
              3: Data Integration – Data Integration users do not have access to
              the web site and cannot log in with their usernames. They can only
              upload and download files. This type of user would be ideal for
              use with our <Link> Upload Service.</Link>
            </Text>
            <TextHeading>
              The User that Created the Account is an Admin
            </TextHeading>
            <Text>
              When you create your account, you will create your Main username
              and password. This account will always be an “admin” account. Once
              you create this account, you will not be able to change the
              account username. However, you can change the password by using
              the “forgot password” checkbox on the login screen.
            </Text>
            <TextHeading>How to Create Additional Users #</TextHeading>
            <Text>
              In addition to your main account, you can add additional users
              with different access level permissions. To add additional users
              to your account, just click on the “Users” link in the “My
              Account” drop down.
            </Text>
            <Image src={User} />
            <Text>
              To add a new user, click on the “Add a New User” button.
            </Text>
            <Text>Enter the following information</Text>
            <ListContainer>
              <RequirmentsList>First Name</RequirmentsList>
              <RequirmentsList>Last Name</RequirmentsList>
              <RequirmentsList>Username</RequirmentsList>
              <RequirmentsList>Email Address</RequirmentsList>
              <RequirmentsList>Access Level</RequirmentsList>
              <RequirmentsList1>
                Read Only – Read only users can only view the “Reminders” page.
                This allows them to check in real time, all the reminders in
                que, all sent reminders, and replies to the reminders. They can
                also save the results to a csv file.
              </RequirmentsList1>
              <RequirmentsList1>
                Admin – Admins have access to the entire site and have the same
                permissions as the main user.
              </RequirmentsList1>
              <RequirmentsList1>
                Data Integration – Data Integration users do not have access to
                the web site and cannot log in with their usernames. They can
                only upload and download files.
              </RequirmentsList1>
              <Text>
                After you add the new user and click submit, the system will
                send a password reset link to the new user where they can choose
                a password. Only the user will be able to see their own
                password. To re-send this link, you can click on “Reset
                Password”.
              </Text>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default AddUser;
