import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledTextToCP";
const TextToCP = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Text Messages
              <MdKeyboardArrowRight />
              <span>How To Send Text Messages to Customers/Patients</span>
            </HeadingContainer>
            <Heading>How To Send Text Messages to Customers/Patients</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>Text Message Reminders</TextList>
              <TextList>Text Messages to Customers</TextList>
              <TextList>
                This post is about "Text Messages to Customers".
              </TextList>
              <TextList>Typical Uses</TextList>
              <TextList>
                Getting to the "Text Messages to Customers" screen:
              </TextList>
              <TextList>Sending Text Messages to a Distribution List</TextList>
              <span>
                With our system, you can send text messages directly to your
                customers or patients.
                <b />
                This is different from sending Text Message Reminders in that
                these text messages are similar to sending text messages from
                your phone.
                <b />
                Please see the chart below for further clarification:
              </span>
            </TextMenu>

            <TextHeading>Text Message Reminders</TextHeading>
            <Text>
              Created and set up on <Link>the “Reminder Types” screen</Link>
              <br />
              Scheduled ahead of time
              <br />
              Set up like a “Template”
              <br />
              More like a “typical” appointment reminder
              <br />
              Can view status and replies in<Link> the “Reminders” screen</Link>
            </Text>

            <TextHeading>Text Messages to Customers</TextHeading>

            <Text>
              Sent from the “Customer<Link> Text Messages</Link>” screen
              <br />
              Get sent immediately
              <br />
              You type the message before sending
              <br />
              More like a typical phone text message conversation
              <br />
              Viewed in the “Customer Text Message Screen” or “
              <Link>Reminders” screen</Link>.<br />
              Useful for a “Real Time” conversation with customers.
            </Text>

            <TextHeading>
              This post is about “Text Messages to Customers”.
            </TextHeading>
            <Link>
              Click Here for information on setting up “Text Message Reminders”.
            </Link>

            <h3>Typical Uses</h3>
            <Text>
              Some of the typical uses for “Text Messages to Customers”:
              <br />
              If the customer replies to to a reminder with a question, you can
              simply text back an answer here.
              <br />
              You can text customers/Patients from our system rather than using
              your private phone.
              <br />
              You can have patients notify you when they get to the building.
            </Text>

            <TextHeading>
              Getting to the “Text Messages to Customers” screen:
            </TextHeading>

            <Text>
              There are 2 ways to get o this page
              <br />
              1. From the “Navigation Menu”, select “Text Messages” / “To
              Customer/Patient”
              <h1>Image 1</h1>
              2. From the “Reminders” page, click on the “sms” icon for a
              specific customer.
              <h1>Image 2</h1>
              This screen will show you all of the text messages sent and
              received to the selected customer.
              <br />
              If you got here from the “Reminders” screen, the specific customer
              should already be selected.
              <br />
              If you got here through the menu, you need to select a customer in
              the drop down list.
              <br />
              The messages are read from bottom to top, with the most recent on
              top, opposite of a typical phone.
              <br />
              You can type a new message in the box or select a previous message
              from the “Start with a Previous Message” dropdown. You can edit
              this before sending.
              <br />
              When you press “Submit”, the message will be sent immediately.
              However, it may take a few moments for the screen to update.
              <h1>Image 3</h1>
              Important! It will be sent immediately (As long as this is during
              a day and time that we can send reminders according to your
              <Link> Reminder Schedule</Link>)<br />
              It will create a Reminder Type with the name “QuickText + Todays
              Date and Time” so you can view results in the Reminders Tab
              <br />
              You cannot use dynamic fields such as Appt Date or Appt Time in a
              Quick Text. To use these fields you have to create a Reminder Type
              and then schedule it to your customer.
            </Text>

            <TextHeading>
              Sending Text Messages to a Distribution List
            </TextHeading>
            <span>
              You can also send these type of text messages to a distribution
              list.<Link> Click Here for a posting on it</Link>.
            </span>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default TextToCP;
