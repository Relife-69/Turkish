import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledCalledID";
const Caller = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Phone Call Reminders
              <MdKeyboardArrowRight />
              <span>Caller IDs – Creating, Validating & Using</span>
            </HeadingContainer>
            <Heading>Caller IDs – Creating, Validating & Using</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                What is a Caller ID?
                <br />
                Viewing Your Caller IDs
                <br />
                Creating a new Caller ID
                <br />
                Verifying a Caller ID
              </TextList>
            </TextMenu>
            <TextHeading>What is a Caller ID? #</TextHeading>
            <Text>
              {" "}
              A caller ID is used so that we can send phone calls from your
              phone number. This increased the likelihood that your calls will
              be answered.
              <br />
              You will be able to associate your Caller ID with your phone call
              and email appointment reminders.
              <br />
              For phone call reminders, your call will originate from the Caller
              ID that you have associated with your reminder type. For email
              type reminders, your caller ID will be placed at the footer of
              your email message. You may add as many Caller IDs as you want but
              they must be numbers that you are able to answer and verify. Text
              Messages will not originate from your Caller IDs but from one of
              our long or short codes.
            </Text>

            <TextHeading>Viewing Your Caller IDs</TextHeading>
            <Text>
              To view your current Caller IDs, go the “Navigation Menu” /
              “Reminder Settings” / “Call Reminder Settings” –/ “CallerIDs”.
              This will bring you to a list of Caller IDs that you have created.
              <br />
              CallerID : The Caller ID phone number.
              <br />
              Verified : Whether this Caller ID has been verified.
              <br />
              Verify Now : Press this button to have the system call you at the
              number so you can verify the Caller ID.
              <br />
              Is Default : Whether this Caller ID is set as your default.
              <br />
              Action : Edit or Delete this Caller ID.
              <h1>image1</h1>
            </Text>

            <TextHeading>Creating a new Caller ID</TextHeading>
            <Text>
              To create a new Caller ID, click on the “Add New Caller ID”
              button.
              <br />
              Caller ID: Type in the 10 digit Caller ID.
              <br />
              Set as Default: Choose whether or not you want this to be your
              default caller ID.
              <br />
              Click “Update” to add it. The next step is to verify it.
            </Text>
            <TextHeading>Verifying a Caller ID</TextHeading>
            <Text>
              Click the “Verify” button to go to the verification screen.
              <br />
              The system will attempt to reach you at the phone number entered.
              Enter the code shown to verify the Caller ID.
              <br />
              Ext to Dial : If this main number requires an extension to be
              pressed, you may enter it here. You can also add spaces. Each
              space will add a half second of delay. You can add multiple
              extensions with spaces if needed (e.g. 123 456).
              <br />
              Your default Caller ID (If you have selected one) will be
              automatically associated with your Call and Email type appointment
              reminders.
              <br />
              For information on associating a CallerID that is not your
              default, please read our posting on Reminder Types HERE
            </Text>
            <h1>image2</h1>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default Caller;
