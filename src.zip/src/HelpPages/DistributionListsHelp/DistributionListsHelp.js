import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import User1 from "../Images/User1.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  RequirmentsList2,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledDistributionListsHelp";

const DistributionListsHelp = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Customers/Patients
              <MdKeyboardArrowRight />
              <span>Distribution Lists</span>
            </HeadingContainer>
            <Heading>Distribution Lists</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>What can I use Distribution Lists For?</TextList>
              <TextList>Creating Distribution Lists</TextList>
              <TextList>The Two Ways To Add a Distribution List </TextList>
              <TextList>
                First Way: Create a blank list and add any customers to that
                list.{" "}
              </TextList>
              <TextList>
                Second Way: Create one based on who has appts for a certain
                timeframe.{" "}
              </TextList>
              <TextList>
                Schedule a Reminder for the Distribution List{" "}
              </TextList>
              <TextList>Send a Text Message to a Distribution List </TextList>
              <TextList>Enter Your Text Message </TextList>
            </TextMenu>
            <TextHeading>What can I use Distribution Lists For?</TextHeading>
            <ListContainer>
              <RequirmentsList>
                Event Notices such as classes, flu shots, web posts, sales, etc…
              </RequirmentsList>
              <RequirmentsList>Weather Closures</RequirmentsList>
              <RequirmentsList>Changes in Coverage</RequirmentsList>
              <RequirmentsList>Office Closures</RequirmentsList>
              <RequirmentsList>
                Address and Phone Number Changes
              </RequirmentsList>
              <RequirmentsList>More!</RequirmentsList>
            </ListContainer>
            <TextHeading>Creating Distribution Lists</TextHeading>
            <Text>
              To get to the “Customers” page, ensure that you are logged into
              your account. Then from the “Navigation Menu” go to “My Customers”
              / “Customers/Patients”.
            </Text>
            <Image src={User1} />
            <Text>
              You will see a list of all of your distribution lists here. By
              default you will have an “All Customers” list.
            </Text>

            <TextHeading>The Two Ways To Add a Distribution List </TextHeading>
            <TextHeading>
              First Way: Create a blank list and add any customers to that list.{" "}
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                Click on “Add a New Distribution List” to add a new one.
              </RequirmentsList>
              <RequirmentsList>
                Enter a name for this list and press enter.
              </RequirmentsList>
              <Image src={User1} />

              <RequirmentsList>
                Click on “Modify List” to add or remove customers{" "}
              </RequirmentsList>
              <RequirmentsList>
                Check or Uncheck anyone you want to add or remove. You can use
                the filters to narrow down your list.{" "}
              </RequirmentsList>
              <RequirmentsList>Click Save</RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>
              Second Way: Create one based on who has appts for a certain
              timeframe.{" "}
            </TextHeading>
            <Text>
              This method allows you to automatically create a list based on
              upcoming appointments. An example would be sending a “closed due
              to weather” notice to anyone who has an appointment scheduled for
              tomorrow.
            </Text>
            <ListContainer>
              <RequirmentsList>
                From the main “Distribution Lists” page, scroll down to the
                bottom of the screen.
              </RequirmentsList>
              <RequirmentsList>
                Choose Start and End Dates for Appointments. For example if I
                want to create a list with everyone who has an appointment
                tomorrow, I would select tomorrows date for both Start and End
                Dates.
              </RequirmentsList>
              <Image src={User1} />
              <RequirmentsList>
                After you choose the Start and End Dates, press “Submit”. You
                will now see a new list.{" "}
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>
              Schedule a Reminder for the Distribution List
            </TextHeading>
            <Text>
              To schedule a reminder to the distribution list, click on
              “View/Add Reminders”.
            </Text>
            <Text>
              This page will show you all the reminders that you have scheduled
              to this distribution list.
            </Text>
            <Text>Click on “Add New Reminder” to schedule a new one.</Text>
            <ListContainer>
              <RequirmentsList>
                Select the “Reminder Type Name” from the list.
              </RequirmentsList>
              <RequirmentsList>
                Select the Appt Date and Time for the “Appointment”. *Note –
                this is not the Date and Time that the reminder will go out. The
                reminder will go out according to the settings for the reminder
                type and your schedule.
              </RequirmentsList>
              <RequirmentsList>
                Press “Update” to schedule the reminder.
              </RequirmentsList>
            </ListContainer>
            <Image src={User1} />
            <TextHeading>
              Send a Text Message to a Distribution List
            </TextHeading>
            <Text>
              To send a text message to a distribution list, click on “Send SMS”
              for the appropriate list.
            </Text>
            <Image src={User1} />
            <TextHeading>Enter Your Text Message </TextHeading>
            <Text>
              You can type a new message into the input box, or you can select a
              previous text message from the list. You can also edit the
              previous text message.
            </Text>
            <Text>
              Press “Submit” to send the message. The message should go out
              immediately as long as your reminder schedule allows it.
            </Text>
            <Image src={User1} />

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default DistributionListsHelp;
