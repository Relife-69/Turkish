import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledReminderWebsite";

const ReminderWebsite = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              <span>Adding Appointments Through the Website Interface</span>
            </HeadingContainer>
            <Heading>Adding Appointments Through the Website Interface</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList> Overview</TextList>
              <TextList>How to Add a Customer</TextList>
              <TextList>Create a Reminder For An Existing Customer</TextList>
            </TextMenu>
            <TextHeading>Overview </TextHeading>
            <Text>
              Before you can send out an appointment reminder, you need to add
              an appointment.
            </Text>
            <Text>There are several ways to do this.</Text>
            <ListContainer>
              <RequirmentsList1>
                You can add appointments through the website interface. (This
                Posting)
              </RequirmentsList1>
              <RequirmentsList1>
                They can be uploaded to our site through import files (.csv,
                .xls).
              </RequirmentsList1>
              <RequirmentsList1>
                They can be added on-the-fly through calendars.
              </RequirmentsList1>
            </ListContainer>
            <Text>
              In this posting I will simply show you how to add an appointment
              through the website..
            </Text>
            <Image src={User} />
            <TextHeading>How to Add a Customer</TextHeading>
            <Text>
              You will need to add a customer before you can schedule a reminder
              for them. Follow these steps to add a customer. If you have
              already added a customer then skip to the “Add an Appointment for
              an existing Customer” heading below.
            </Text>
            <Text>
              1. Go to the “Customers” page. To get to this page, scroll down
              from the “Navigation Menu” and click “My Customers” and then
              “Customers/Patients”.
            </Text>
            <Image src={User} />
            <Text>3. Add a new customer with the following info</Text>
            <ListContainer>
              <RequirmentsList>First Name</RequirmentsList>
              <RequirmentsList>Last Name</RequirmentsList>
              <RequirmentsList>Pri Phone (Main Phone Number)</RequirmentsList>
              <RequirmentsList>
                Sec Phone (Secondary Phone Number – Optional)
              </RequirmentsList>
              <RequirmentsList>
                Email Address (Optional – only needed if sending emails)
              </RequirmentsList>
              <RequirmentsList>
                Customer ID (Optional – Enter it if you have one that you want
                to use)
              </RequirmentsList>
              <RequirmentsList>
                Spanish (Check this box if you want to use a Spanish Reminder)
              </RequirmentsList>
            </ListContainer>
            <Image src={User} />

            <TextHeading>
              Create a Reminder For An Existing Customer
            </TextHeading>
            <Text>
              If you already have added a customer, simply go to the “Customers”
              page and find the customer. Then click on “View/Add Reminders” for
              that customer to add a new reminder.
            </Text>
            <Text>
              If you have any other appointments scheduled for this person you
              will see them here. Press the “Add New Reminder” button to
              schedule a new reminder.
            </Text>
            <Text>The following fields will be show:</Text>
            <ListContainer>
              <RequirmentsList>
                Reminder Type Name: The Description (Name) of the Reminder Type
                that will be sent to this Customer
              </RequirmentsList>
              <RequirmentsList>
                Appointment Date/Time: Date and Time of the Appointment
              </RequirmentsList>
              <RequirmentsList>
                Appointment End Date/Time: End Date and Time of the Appointment
                (Optional – use this if you are using an appointment window)
              </RequirmentsList>
              <RequirmentsList>
                Custom Fields: If you are using custom fields in your reminders,
                enter them here.
              </RequirmentsList>
            </ListContainer>
            <Image src={User} />
            <Text>Finally, Press “Update” to create the appointment</Text>
            <Text>
              You can see the appointment in the appointment list as well as on
              The “Reminders” Page.
            </Text>
            <Text>
              If you ever need to cancel an appointment/appointment reminder.
              You can do that as well from either of these screens as long as
              the reminder has not been sent out.
            </Text>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default ReminderWebsite;
