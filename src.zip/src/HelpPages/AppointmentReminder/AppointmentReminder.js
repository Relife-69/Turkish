import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledAppointReminder";

const AppointmentReminder = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              <span>Appointment Reminders Upload Service</span>
            </HeadingContainer>
            <Heading>Appointment Reminders Upload Service</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                What is the Appointment Reminders Upload Service?
              </TextList>
              <TextList>
                How to configure the AppointmentReminders.com Upload Service
              </TextList>
              <TextList>Configure your Upload Settings</TextList>
            </TextMenu>
            <TextHeading>
              What is the Appointment Reminders Upload Service?
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                The Appointment Reminders Upload Service is a downloadable
                application that can be installed on your local windows machine.
              </RequirmentsList>
              <RequirmentsList>
                It will allow you to automatically upload files to us when it
                sees a new file in the folder that you specify. The folder can
                be on a workstation, server, or shared drive.
              </RequirmentsList>
              <RequirmentsList>
                It will allow you to automatically{" "}
                <Link>download reports </Link>with reminder status and replies.
              </RequirmentsList>
            </ListContainer>
            <Text>
              The Appointment Reminders Upload Service is a downloadable
              application that can be installed on your local windows machine.
            </Text>
            <Text>
              It will allow you to automatically upload files to us when it sees
              a new file in the folder that you specify. The folder can be on a
              workstation, server, or shared drive.
            </Text>
            <Text>
              If you create a file that adheres to our file format, then there
              is no additional charge to use this application to upload files
              and download reports. If you are unable to create a file in this
              format, then we can build a custom parser on our end. There is a
              small monthly fee associated with custom parsing. We refer to this
              as our “Integration Service”. Please contact our tech team if you
              need this service.
            </Text>
            <Text>
              <Link>
                Click Here to Download the AppointmentReminders Upload Service
              </Link>
            </Text>
            <Text>
              This is a zip file and it contains the following help docs
            </Text>
            <ListContainer>
              <RequirmentsList>
                “How to Install the Appointment Reminders Windows Service.docx”
                This document will help you through the installation process.
              </RequirmentsList>
              <RequirmentsList>
                “How to configure the AppointmentReminders.com Upload Service”.
                This document will provide information on the configuration of
                the service.
              </RequirmentsList>
            </ListContainer>

            <TextHeading>
              How to configure the AppointmentReminders.com Upload Service #
            </TextHeading>
            <ListContainer>
              <Text>
                1. You can either edit the Config.ini directly or use the
                AppointmentRemindersCOM Configuration Utility which should have
                installed into your program files.
              </Text>
              <Text>
                2. Choose the INI file where you installed the application. It
                should be called Config.ini
              </Text>
              <TextHeading>3. Configure your Upload Settings</TextHeading>
              <Text>
                a. Use Custom Processing – Set this to “True” if we do any
                custom parsing of your file on our end (Integration Service). If
                you simply send us a file that adheres to our file format, set
                this to “False”
              </Text>
              <Text>
                b. AppointmentReminders.com Username – This is the username. We
                recommend creating a separate{" "}
                <Link> “Data Integration User” for this purpose.</Link>
              </Text>
              <Text>
                c. AppointmentReminders.com Password – This is the password of
                your account or user.
              </Text>
              <Text>
                d. Choose Import Folder – This is the folder where we will look
                for your imports. If you have multiple locations, they will be
                created as subfolders within this folder.
              </Text>
              <Text>
                e. Choose Log Folder – This is the folder where we will write
                log files. You can reference these log files if you have any
                issues with the service.
              </Text>
              <Text>
                f. Choose Processed Folder – This is the folder where we will
                copy your import files after we upload them.
              </Text>
              <Text>
                g. MULTIPLE LOCATIONS – If you have multiple locations, you can
                add them here. When you send us imports, you will save the
                import files in the specific location folders.
              </Text>
              <Text>4. Configure Your Download Settings</Text>
              <Text>
                a. Enable Downloads – You can check this box if you would like
                to automatically download reports. These reports can be opened
                in excel or programmatically parsed by your software.
              </Text>
              <Text>
                b. Choose Downloads Folder – Select the folder where you would
                like the reports saved.
              </Text>
              <Text>
                c. Reminder Results – Reminder Results – Contains the results of
                the reminders that were sent.
              </Text>
              <Text>
                d. Reminder Summary – Contains the number and type of reminders
                that were sent.
              </Text>
              <Text>
                e. Failed Reminders – This report is sent at the end of the day
                (whenever your reminders stop) and gives you a list of the
                reminders that were not delivered.
              </Text>
              <Text>
                f. Download Time – The automatic downloads will occur once per
                day. If you select a time that is 9AM or earlier, the reports
                will be for the previous day, otherwise they will contain the
                data for the current day.
              </Text>
              <Text>5. Logs</Text>
              <Text>
                a. You can open log files with this viewer. Log files contain
                information that may help in troubleshooting if you have any
                issues with the service.
              </Text>
            </ListContainer>
            <ListContainer>
              <Text>6. SAVE BUTTON</Text>
              <Text>
                a. Make Sure you click the SAVE button after your changes. The
                Save Button will save all of your values and then STOP and START
                the Appointment Reminders Upload Service.
              </Text>
            </ListContainer>
            <Text>
              Once you have set this up, whenever you place a file into your
              imports folder, it will be uploaded to our site. You can also
              check the downloads folder for reports if you have enabled them.
              If you have any issues or need help with this application, please
              let us know and we will be happy to walk you through it!
            </Text>

            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default AppointmentReminder;
