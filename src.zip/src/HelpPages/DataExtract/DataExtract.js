import React from "react";
import Navbar from "../../Components/Header/Navbar";
import HelpSidebar from "../HelpSideBar/HelpSidebar";
import { MdKeyboardArrowRight } from "react-icons/md";
import { Link } from "react-router-dom";
import User from "../Images/User.png";
import Facebook from "../Images/S1.png";
import Twitter from "../Images/S4.png";
import Instagram from "../Images/S2.png";
import Linkedin from "../Images/S3.png";
import Footer from "../../Components/Footer/Footer";
import { FaFaceGrinHearts } from "react-icons/fa6";
import { FaFaceSmile } from "react-icons/fa6";
import { FaFaceTired } from "react-icons/fa6";

import {
  MainContainer,
  ContextContainer,
  TextContainer,
  HeadingContainer,
  Heading,
  TextMenu,
  TextList,
  Text,
  TextHeading,
  Image,
  ListContainer,
  RequirmentsList,
  RequirmentsList1,
  FeelingContainer,
  Feelingtext,
  IconContainer,
  Icon,
  ShareContainer,
  SocialImage,
} from "./StyledDataExtrat";

const DataExtract = () => {
  return (
    <>
      <Navbar />
      <MainContainer>
        <ContextContainer>
          <HelpSidebar />
          <TextContainer>
            <HeadingContainer>
              Home <MdKeyboardArrowRight />
              Docs <MdKeyboardArrowRight />
              Connecting Your Data
              <MdKeyboardArrowRight />
              <span>Data Extract – What Data Do We Need?</span>
            </HeadingContainer>
            <Heading>Data Extract – What Data Do We Need?</Heading>
            <TextMenu>
              <HeadingContainer> Table of Contents </HeadingContainer>
              <TextList>
                {" "}
                This post has information on extracting data from any scheduling
                software
              </TextList>
              <TextList>What data you will need to pull</TextList>
              <TextList>The Following Info is optional</TextList>
              <TextList>
                If you would like to utilize our integration service, please
                contact us. We will need to know the following info to get
                started
              </TextList>
            </TextMenu>
            <TextHeading>
              This post has information on extracting data from any scheduling
              software
            </TextHeading>
            <Text>
              Overview: In order to pull data from your scheduling software, you
              will need to be able to pull the following information from your
              software. This will be used to create a file that can be uploaded
              to us.
            </Text>
            <Text>
              This topic serves as just a general overview on extracting data.
              We expect you to have questions about this and recommend that you
              contact us prior to set up any jobs to extract data.
            </Text>
            <TextHeading>What data you will need to pull</TextHeading>
            <ListContainer>
              <RequirmentsList>Customer First Name</RequirmentsList>
              <RequirmentsList>Customer Last Lame</RequirmentsList>
              <RequirmentsList>Primary Phone Number</RequirmentsList>
              <RequirmentsList>Appointment Date</RequirmentsList>
              <RequirmentsList>Appointment Time</RequirmentsList>
            </ListContainer>
            <TextHeading>The Following Info is optional</TextHeading>
            <ListContainer>
              <RequirmentsList>Customer ID (Optional)</RequirmentsList>
              <RequirmentsList>Appointment Type (Optional)</RequirmentsList>
              <RequirmentsList>
                Secondary Phone Number (Optional)
              </RequirmentsList>
              <RequirmentsList>Email Address (Optional)</RequirmentsList>
              <RequirmentsList>
                Outreach Preference (Call, Text, Email)
              </RequirmentsList>
              <Text>
                Once you have extracted the appropriate information, you will
                need to upload this information to us. You can either upload it
                manually through import files, utilize our API, or allow us to
                do with with our Integration Service.
              </Text>
            </ListContainer>
            <TextHeading>
              If you would like to utilize our integration service, please
              contact us. We will need to know the following info to get started
            </TextHeading>
            <ListContainer>
              <RequirmentsList>
                What type of scheduling software do you use?
              </RequirmentsList>
              <RequirmentsList>
                Where is the data located (Onsite or Offsite)
              </RequirmentsList>
              <RequirmentsList>Who manages the data?</RequirmentsList>
              <RequirmentsList>
                Who is the main account contact?
              </RequirmentsList>
              <RequirmentsList>
                Do you have an IT Group Internal or External that manages your
                software?
              </RequirmentsList>
              <RequirmentsList>
                Who is the main technical contact?
              </RequirmentsList>
            </ListContainer>
            <FeelingContainer>
              <Feelingtext>How You Are Feeling??</Feelingtext>
              <IconContainer>
                <Icon>
                  <FaFaceGrinHearts />
                </Icon>
                <Icon>
                  <FaFaceSmile />
                </Icon>
                <Icon>
                  <FaFaceTired />
                </Icon>
              </IconContainer>
            </FeelingContainer>
            <ShareContainer>
              Share This Article :
              <SocialImage src={Facebook} alt="Facebok" target="blank" />
              <SocialImage src={Twitter} alt="Twitter" target="blank" />
              <SocialImage src={Instagram} alt="Instagram" target="blank" />
              <SocialImage src={Linkedin} alt="Linked" target="blank" />
            </ShareContainer>
          </TextContainer>
        </ContextContainer>
      </MainContainer>
      <Footer />
    </>
  );
};

export default DataExtract;
