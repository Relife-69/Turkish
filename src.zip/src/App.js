import React from "react";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home/Home";
import Signup from "./Pages/Sign_up/Signup";
import Signin from "./Pages/Sign_in/Signin";
import Subscription from "./Pages/Subscription/Subscription";
import Contuctus from "./Pages/Contuctus/Contuctus";
import Pricing from "./Pages/Pricing/Pricing";
import Aboutus from "./Pages/Aboutus/Aboutus";
import FAQ from "./Pages/FAQs/FAQ";
import Calender from "./Dashboard/Calender/Calender";
import CompanyPRules from "./Pages/CompanyRules/CompanyPRules";
import BasicIntegration from "./Pages/BasicIntegration/BasicIntegration";
import AdvancedIntegration from "./Pages/AdvancedIntegration/AdvancedIntegration";
import MedicalPatient from "./Pages/MedicalPatient/MedicalPatient";
import SingleBlog from "./Pages/SingleBlog/SingleBlog";
import EmailReminder from "./Pages/EmailReminder/EmailReminder";
import DiscountAccounts from "./Pages/DiscountAccounts/DiscountAccounts";
import BusinessReminder from "./Pages/BusinessReminder/BusinessReminder";
import CallReminder from "./Pages/CallReminder/CallReminder";
import CompanyInformationPage from "./Components/Company Information Page/CompanyInformationPage";
import MessageReminder from "./Pages/MessageReminder/MessageReminder";
import DashHome from "./Dashboard/DashBoardHome/DashHome";
import AddPatient from "./Dashboard/AddPatient/AddPatient";
import PatientReminder from "./Dashboard/PatientReminder/PatientReminder";
import DistributionLists from "./Dashboard/DistributionLists/DistributionLists";
import RecordVoice from "./Dashboard/RecordVoice/RecordVoice";
import Voice from "./Dashboard/Voice/Voice";
import Reminder from "./Dashboard/Reminder/Reminder";
import CallerID from "./Dashboard/CallerID/CallerID";
import Email from "./Dashboard/LookOfEmail/EmailLook";
import AddReminderType from "./Dashboard/AddReminderType/AddReminderType";
import Text from "./Dashboard/Text/Text";
import Terms from "./Pages/Terms/Terms";
import ReminderTextSetting from "./Dashboard/ReminderTextSetting/ReminderTextSetting";
import ImportFile from "./Dashboard/ImportFiles/ImportFile";
import DistributionListReminder from "./Dashboard/DistributionListReminder/DistributionListReminder";
import SmsText from "./Dashboard/SmsText/SmsText";
import NoReminderList from "./Dashboard/NoReminderList/NoReminderList";
import EmailReports from "./Dashboard/Email/Email";
import Trigger from "./Dashboard/Rules/Trigger";
import HelpHome from "./HelpPages/HelpHome/HelpHome";
import AddUser from "./HelpPages/AddUser/AddUser";
import ReminderSechdule from "./Dashboard/ReminderShedule/ReminderSechdule";
import TextBlock from "./Dashboard/TextBlock/TextBlock";
import ReminderContent from "./Dashboard/ReminderContent/ReminderContent";
import Accountcancel from "./HelpPages/AccountCancel/Accountcancel";
import Payment from "./HelpPages/Payment/Payment";
import ReminderShadule from "./HelpPages/ReminderShedule/ReminderShadule";
import TestMode from "./HelpPages/TestMode/TestMode";
import AppointmentReminder from "./HelpPages/AppointmentReminder/AppointmentReminder";
import ReminderWebsite from "./HelpPages/ReminderWebsite/ReminderWebsite";
import LinkedCalender from "./HelpPages/LinkCalender/LinkedCalender";
import Integrating from "./HelpPages/Integrating/Integrating";
import DataExtract from "./HelpPages/DataExtract/DataExtract";
import EventView from "./HelpPages/EventView/EventView";
import AddingCustomers from "./HelpPages/AddingCustomers/AddingCustomers";
import EmailCustomization from "./HelpPages/EmailCustomization/EmailCustomization";
import MultipleReminders from "./HelpPages/MultipleReminders/MultipleReminders";
import HelpNoReminderList from "./HelpPages/NoReminder/HelpNoReminderList";
import HelpReminderType from "./HelpPages/HelpReminderType/HelpReminderType";
import HelpCallReminder from "./HelpPages/HelpCallReminder/HelpCallReminder";
import CustomFeilds from "./HelpPages/CustomFeilds/CustomFeilds";
import TextFail from "./HelpPages/TextFail/TextFail";
import TextBlockHelp from "./HelpPages/TextBlockHelp/TextBlockHelp";
import FirstReminderHelp from "./HelpPages/FirstReminderHelp/FirstReminderHelp";
import CreateListHelp from "./HelpPages/CreateListHelp/CreateListHelp";
import StructureAndContent from "./HelpPages/StructureAndContent/StructureAndContent";
import WebsiteOverview from "./HelpPages/WebsiteOverview/WebsiteOverview";
import WebPortal from "./HelpPages/WebPortal/WebPortal";
import DistributionListsHelp from "./HelpPages/DistributionListsHelp/DistributionListsHelp";
import Caller from "./HelpPages/CallerID/CallerID";
import CreatingandEditingVF from "./HelpPages/CreatingandEditingVF/CreatingandEditingVF";
import PreRecordedLibrary from "./HelpPages/Prerecorded/PreRecordedLibrary";
import TriggerTime from "./HelpPages/TriggerTime/TriggerTime";
import CreateandEdit from "./HelpPages/TriggerCreatandEdit/CreateandEdit";
import Spanish from "./HelpPages/Spanish/Spanish";
import StructureContent from "./HelpPages/ReportsStructureContent/StructureContent";
import NightlyEmail from "./HelpPages/NightlyEmail/NightlyEmail";
import DownloadProgramatically from "./HelpPages/DownloadProgramatically/DownloadProgramatically";
import RealTimeReport from "./HelpPages/RealTimeReport/RealTimeReport";
import TextMsgNot from "./HelpPages/TextMsgNot/TextMsgNot";
import TextToCP from "./HelpPages/TextToCandP/TextToCP";
import ExportContact from "./HelpPages/ExportContact/ExportContact";
import TextDistribution from "./Components/TextDistribution/TextDistribution";
import ReminderSech from "./Dashboard/ReminderShedule/ReminderSech";
import LinkedGoogle from "./Dashboard/LinkedGoogle/LinkedGoogle";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/medicalpatient" element={<MedicalPatient />} />
        <Route path="/businessreminder" element={<BusinessReminder />} />
        <Route path="/disaccounts" element={<DiscountAccounts />} />
        <Route path="/callreminder" element={<CallReminder />} />
        <Route path="/msgreminder" element={<MessageReminder />} />
        <Route path="/emailreminder" element={<EmailReminder />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/faqs" element={<FAQ />} />
        <Route path="/reminder_sechdule" element={<ReminderSech />} />
        <Route path="/rules" element={<CompanyPRules />} />
        <Route path="/basic" element={<BasicIntegration />} />
        <Route path="/advance" element={<AdvancedIntegration />} />
        <Route path="/aboutus" element={<Aboutus />} />
        <Route path="/contactus" element={<Contuctus />} />
        <Route path="/singleblog" element={<SingleBlog />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/buypage" element={<CompanyInformationPage />} />
        <Route path="/dashhome" element={<DashHome />} />
        <Route path="/addpatient" element={<AddPatient />} />
        <Route path="/patientreminder/:id" element={<PatientReminder />} />
        <Route path="/adddis" element={<DistributionLists />} />
        <Route path="/calender" element={<Calender />} />
        <Route path="/voicerecording" element={<RecordVoice />} />
        <Route path="/voices" element={<Voice />} />
        <Route path="/callerid" element={<CallerID />} />
        <Route path="/reminder" element={<Reminder />} />
        <Route path="/emaillook" element={<Email />} />
        <Route path="/text" element={<Text />} />
        <Route path="/agreements" element={<Terms />} />
        <Route path="/addRemindertype" element={<AddReminderType />} />
        <Route path="/remindersetting/:id" element={<ReminderTextSetting />} />
        <Route path="/fileimport" element={<ImportFile />} />
        <Route path="/textsms/:id" element={<SmsText />} />
        <Route path="/no_reminder_list" element={<NoReminderList />} />
        <Route path="/emai_reports" element={<EmailReports />} />
        <Route path="/trigger_rules" element={<Trigger />} />
        <Route path="/help_home" element={<HelpHome />} />
        <Route path="/help_add_user" element={<AddUser />} />
        <Route path="/reminder_sechduler" element={<ReminderSechdule />} />
        <Route path="/text_block" element={<TextBlock />} />
        <Route path="/reminder_content/:id" element={<ReminderContent />} />
        <Route path="/account_cancel_help" element={<Accountcancel />} />
        <Route path="/payments_help" element={<Payment />} />
        <Route path="/test_mode_help" element={<TestMode />} />
        <Route path="/reminder_type_help" element={<HelpReminderType />} />
        <Route path="/reminder_shedule_help" element={<ReminderShadule />} />
        <Route path="/reminder_website_help" element={<ReminderWebsite />} />
        <Route path="/linked_calender_help" element={<LinkedCalender />} />
        <Route path="/linked_google_calender" element={<LinkedGoogle />} />
        <Route path="/integration_help" element={<Integrating />} />
        <Route path="/data_extract_help" element={<DataExtract />} />
        <Route path="/calender_event_view_help" element={<EventView />} />
        <Route path="/no_reminder_list_help" element={<HelpNoReminderList />} />
        <Route path="/call_reminder_help" element={<HelpCallReminder />} />
        <Route path="/custom_feilds_help" element={<CustomFeilds />} />
        <Route path="/text_fail_help" element={<TextFail />} />
        <Route path="/text_block_help" element={<TextBlockHelp />} />
        <Route path="/first_reminder_help" element={<FirstReminderHelp />} />
        <Route path="/website_overview_help" element={<WebsiteOverview />} />
        <Route path="/web_portal_help" element={<WebPortal />} />
        <Route path="/caller_help" element={<Caller />} />
        <Route path="/trigger_time_help" element={<TriggerTime />} />
        <Route path="/spanish_help" element={<Spanish />} />
        <Route path="/text_message_don't_help" element={<TextMsgNot />} />
        <Route path="/text_distribution" element={<TextDistribution />} />
        <Route path="/text_to_c&p_help" element={<TextToCP />} />
        <Route path="/export_contact_help" element={<ExportContact />} />
        <Route
          path="/report_structure_content_help"
          element={<StructureContent />}
        />
        <Route path="/report_nightly_email_help" element={<NightlyEmail />} />
        <Route path="/report_real_time_help" element={<RealTimeReport />} />
        <Route
          path="/report_download_programatically_help"
          element={<DownloadProgramatically />}
        />
        <Route
          path="/trigger_create_and_edit_help"
          element={<CreateandEdit />}
        />
        <Route
          path="/pre_recorded_library_help"
          element={<PreRecordedLibrary />}
        />
        <Route
          path="/creating_and_editing_vf_help"
          element={<CreatingandEditingVF />}
        />
        <Route
          path="/distribution_list_help"
          element={<DistributionListsHelp />}
        />
        <Route
          path="/import_files_structure_and_content_help"
          element={<StructureAndContent />}
        />
        <Route
          path="/create_and_upload_list_help"
          element={<CreateListHelp />}
        />
        <Route
          path="/multiple_reminders_help"
          element={<MultipleReminders />}
        />
        <Route
          path="/email_customization_help"
          element={<EmailCustomization />}
        />
        <Route
          path="/shedule_adding_customer_help"
          element={<AddingCustomers />}
        />
        <Route
          path="/appointment_reminder_help"
          element={<AppointmentReminder />}
        />
        <Route
          path="/adddislistreminder/:id"
          element={<DistributionListReminder />}
        />
      </Routes>
    </Router>
  );
}

export default App;
