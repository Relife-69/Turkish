import styled from 'styled-components';

export const MainContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  margin: 30px 0px;
`;

export const Heading = styled.h1`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
`;

export const ChartContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
`;

export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
`;

export const PageContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  font-weight: 400;
  a {
    color: black;
    display: flex;
    text-decoration: none;
    align-items: center;
    justify-content: center;
  }
  span {
    color: #1376f8;
  }
`;

export const IconContainer = styled.div`
  color: #1376f8;
  margin: 0%;
  font-size: 24px;
  font-weight: 600;
  margin-right: 8px;
`;

export const HelpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const Help = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  border: none;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;

export const ChartHeadingContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 7px;
`;

export const ChartHeading = styled.h1`
  font-size: 28px;
  font-weight: 500;
  margin: 0%;
`;

export const ChartText = styled.p`
  font-size: 21px;
  font-weight: 400;
  margin: 0%;
`;
export const LineContainer = styled.div`
  display: flex;
  width: 80%;
  align-items: start;
  justify-content: start;
  flex-direction: column;
 
`;
export const ChartContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
  margin: 2%;
`;
export const InputFieldContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 150px;
  width: 80%;

`;
export const InputField1 = styled.div`
 display: flex;
    flex-direction: column;
    gap: 8px;
    justify-content: center;
    align-items: start;
`;
export const Label = styled.h6`
  display: flex;
  align-items: start;
  justify-content: start;
  font-size:20px;
  font-weight: 400;
  margin: 0%;
`;
export const Input1 = styled.input`
  display: flex;
  align-items: start;
  justify-content: start;
  color:2px soid #888888;
 
`;

export const SelectionField1 = styled.select`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 260px;
  height:30px;
  background-color:White;
border: 2px solid #CED4DA;
border-radius: 2px;
font-size: large;
padding: 3px 3px;
`;
export const Option = styled.option`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  width: 260px;
  height:30px;
  background-color: #CED4DA;
border: 2px solid #CED4DA;
border-radius: 6px;

`;

export const InputField = styled.div`
 display: flex;
    gap: 8px;
    justify-content: center;
    align-items: start;
`;

export const InputContainer = styled.div`
 display: flex;
    width:100%;
    justify-content: center;
    align-items: start;
`;

export const ChartText1 = styled.p`
  font-size: 18px;
  font-weight: 400;

`;
export const LastContainer = styled.div`
    display: flex;
    flex-direction:column;    
    width:80%;
    justify-content: Start;
    align-items: start;
    
`;
export const InputField2 = styled.div`
 display: flex;

    gap: 15px;
    justify-content: center;
    align-items: center;
`;

export const ButtonContainer = styled.div`
  display: flex;
  width: 140px;
  justify-content: start;
  align-items: start;
  
`;
export const ButtonContainer1 = styled.div`
  display: flex;
  width: 80%;
  justify-content: start;
  align-items: start;
  margin: 40px;

  
`;
export const Submit = styled.button`
  display: flex;
  width: 115px;
    align-items: center;
    justify-content: center;
    background-color:#1376f8;
    color: white;
    gap: 5px;
    padding: 5px 15px 5px 15px;
    font-size: 18px;
    font-weight: 400;
    border-radius: 5px;
    border: none;
  
`;
export const Clear = styled.button`
  display: flex;
  width: 115px;
    align-items: center;
    justify-content: center;
    background-color: #d9d9d9;
    color: black;
    gap: 5px;
    padding: 5px 12px 5px 12px;
    font-size: 18px;
    font-weight: 400;
    border-radius: 5px;
    border: none;
  
`;

export const InputFieldContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 15px;
  width: 80%;

`;