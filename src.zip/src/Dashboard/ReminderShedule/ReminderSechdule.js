import React from "react";
import Switch from "react-switch";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import {
  MainContainer,
  Heading,
  ChartContainer,
  HeadingContainer,
  PageContainer,
  IconContainer,
  HelpContainer,
  Help,
  ChartHeadingContainer,
  ChartHeading,
  ChartText,
  LineContainer,
  ChartContainer1,
  InputFieldContainer,
  InputField1,
  Label,
  Input1,
  SelectionField1,
  Option,
  InputField,
  InputContainer,
  ChartText1,
  LastContainer,
  InputField2,
  ButtonContainer1,
  ButtonContainer,
  Submit,
  Clear,
  InputFieldContainer1,
} from "./StyleReminderSechdule";
const ReminderSechdule = () => {
  return (
    <>
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <IconContainer>
                <FaHome />
              </IconContainer>
              Home
              <FaChevronRight />
              <span>Reminder Schedule</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Reminder Schedule</ChartHeading>
            <ChartText>
              This page allows you to select the days and times that your
              reminders will be sent
            </ChartText>
          </ChartHeadingContainer>
        </ChartContainer>
        <LineContainer>
          <div
            style={{
              padding: "2px",
              width: "740px",
              background: "#1376F8",
              margin: "1%",
            }}
          ></div>
        </LineContainer>

        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Monday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 28px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Tuesday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 28px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Wednesday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Thursday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 28px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Friday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 60px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Satuarday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 32px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>
        <ChartContainer1>
          <ChartHeadingContainer>
            <InputFieldContainer>
              <InputContainer>
                <InputField1>
                  <Label>Sunday:</Label>
                  <Input1 type="CheckBox"></Input1>
                </InputField1>
              </InputContainer>
              <InputField>
                <InputField1 style={{ padding: "0px 0px 0px 59px" }}>
                  <Label>Start Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
                <InputField1>
                  <Label>End Time:</Label>
                  <SelectionField1>
                    <Option>9:00 Am</Option>
                    <Option>10:00 Am</Option>
                    <Option>11:00 Am</Option>
                    <Option>12:00 Pm</Option>
                    <Option>1:00 Pm</Option>
                  </SelectionField1>
                </InputField1>
              </InputField>
            </InputFieldContainer>
          </ChartHeadingContainer>
        </ChartContainer1>

        <LastContainer>
          <ChartText>
            {" "}
            if reminder is scheduled to go out on a disabled day.....
          </ChartText>
          <InputFieldContainer1>
            <InputField2>
              <Label>Send On First Previous Enabled Day</Label>
              <Input1 type="radio"></Input1>
            </InputField2>

            <InputField2>
              <Label>Use Days Before Appt Settings From Reminder Type</Label>
              <Input1 type="radio"></Input1>
            </InputField2>
          </InputFieldContainer1>
        </LastContainer>

        <ButtonContainer1>
          <ButtonContainer>
            <Submit>Submit</Submit>
          </ButtonContainer>
          <ButtonContainer>
            <Clear>Clear</Clear>
          </ButtonContainer>
        </ButtonContainer1>
        <ButtonContainer1>
          <ButtonContainer>
            <Clear>Back</Clear>
          </ButtonContainer>
        </ButtonContainer1>
      </MainContainer>
    </>
  );
};

export default ReminderSechdule;
