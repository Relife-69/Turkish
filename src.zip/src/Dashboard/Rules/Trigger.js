import React, { useState } from "react";

import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaSearch } from "react-icons/fa";
import { FaEye } from "react-icons/fa";

import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  View,
  ButtonContainer1,
  ButtonContainer,
  Clear,
} from "./StyleTrigger";
import DashboardNavbar from "../Navbar/DashboardNavbar";

const Trigger = () => {
  const [showTable, setShowTable] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [priNumber, setPriNumber] = useState("");
  const [secNumber, setSecNumber] = useState("");
  const [email, setEmail] = useState("");
  const [cusID, setCusID] = useState("");
  const [spanish, setSpanish] = useState(false);

  const toggleTable = () => {
    setShowTable(!showTable);
  };
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Triggers/Rules</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Triggers/Rules</ChartHeading>
            <ChartText>
              Triggers allow you to create multiple reminders for an appointment
              or send text or email alerts when certain conditions are met.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <ExcelHolder>
              <AddingButton>
                <IoAddSharp />
                Add New Triggers/Rules
              </AddingButton>
              <AddingButton>
                <FaEye />
                View Triggers/Rules Alerts
              </AddingButton>
            </ExcelHolder>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Trigger Name</StyledTableHeader>
                <StyledTableHeader>Reminder Type Seed</StyledTableHeader>
                <StyledTableHeader>Result To Trigger</StyledTableHeader>
                <StyledTableHeader>Triggered Action</StyledTableHeader>
                <StyledTableHeader>Triggered Reminder Type</StyledTableHeader>
                <StyledTableHeader>Email Address</StyledTableHeader>
                <StyledTableHeader>Phone To Text</StyledTableHeader>
                <StyledTableHeader></StyledTableHeader>
                <StyledTableHeader></StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {/* <StyledTableRow>
                  <StyledTableCell>janie@gmail.com</StyledTableCell>
                  <StyledTableCell>Linked</StyledTableCell>
                  <StyledTableCell>
                    <input type="checkbox" />
                  </StyledTableCell>
                  <StyledTableCell>
                    <View> View Calendar</View>
                  </StyledTableCell>
                </StyledTableRow> */}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default Trigger;
