import React from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  View,
} from "./StyledDistributionListReminder";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { useNavigate } from "react-router-dom";
const DistributionListReminder = () => {
  const navigate = useNavigate();
  const company_name = localStorage.getItem("company_name");
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Distribution Lists Reminders</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Distribution Lists Reminders</ChartHeading>
            <ChartText>
              Schedule a reminder to your entire distribution list here:
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton>
              <IoAddSharp />
              Add New Reminder{" "}
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Reminder Type Name</StyledTableHeader>
                <StyledTableHeader>Appt Date & Time</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Upload/Edit</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>Reminder Type Name</StyledTableCell>
                <StyledTableCell>Appt Date & Time</StyledTableCell>
                <StyledTableCell>
                  <View>Delete</View>
                </StyledTableCell>
                <StyledTableCell>
                  <View>Modify</View>
                </StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default DistributionListReminder;
