import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  margin: 30px 0px;
`;
export const Heading = styled.h1`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
`;
export const ChartContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
`;

export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
`;
export const PageContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  font-weight: 400;
  a {
    color: black;
    display: flex;
    text-decoration: none;
    align-items: center;
    justify-content: center;
  }
  span {
    color: #1376f8;
  }
`;
export const IconContainer = styled.h1`
  color: #1376f8;
  margin: 0%;
  font-size: 24px;
  font-weight: 600;
  margin-right: 8px;
`;

export const HelpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const Help = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  border: none;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;
export const ChartHeadingContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 7px;
`;
export const ChartHeading = styled.h1`
  font-size: 28px;
  font-weight: 500;
  margin: 0%;
`;
export const ChartText = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;

export const AddingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`;
export const AddingButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 10px;
  padding: 10px;
  border: none;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;
export const ExcelHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;
export const SearchContainer = styled.input`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
  width: 180px;
`;
export const ExcelButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
`;
export const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 18px;
`;

export const StyledTableHead = styled.thead`
  background-color: #1376f8;
  color: white;
  font-size: 14px;
  font-weight: 500;
`;

export const StyledTableRow = styled.tr`
  border-bottom: 1px solid #dddddd;
`;

export const StyledTableHeader = styled.th`
  padding: 12px;
  border-left: 2px solid white;
`;

export const StyledTableCell = styled.td`
  padding: 12px;
`;

export const StyledTableBody = styled.tbody`
  & ${StyledTableRow}:nth-child(even) {
    background-color: #f9f9f9;
  }
`;

export const View = styled.button`
  background-color: #d9d9d9;
  color: black;
  padding: 8px 12px;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-size: 16px;
  font-weight: 400;
  border-radius: 5px;
  &:hover {
    background-color: #b3b3b3;
  }
`;
