import React from "react";
import DashboardNavbar from '../Navbar/DashboardNavbar'
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
} from "./StyledVoice";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaMicrophone } from "react-icons/fa6";
import { PiArrowArcLeftBold } from "react-icons/pi";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiEdit } from "react-icons/ci";


const Voice = () => {

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Voice Files</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Voice Files</ChartHeading>
            <ChartText>
            This Area will allow you to record your own voice file over the phone for use in your Reminder Types. In addition, our library of voice file is
available to you when you create or edit  a Reminder Type
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton>
              <IoAddSharp />
              Create A New Voice File
            </AddingButton>
            <ExcelHolder>
            

              <SearchContainer type="search"  placeholder="Search..." />
              
               
            </ExcelHolder>
          </AddingContainer>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader style={{width:'15%'}}  >Voice File Name</StyledTableHeader>
               
                <StyledTableHeader style={{width:'15%'}}>Voice File Content</StyledTableHeader>
                <StyledTableHeader style={{width:'30%'}}  >Listen</StyledTableHeader>
                <StyledTableHeader  >(Re) Record</StyledTableHeader>
                 <StyledTableHeader >Link Status</StyledTableHeader>
                <StyledTableHeader >Active</StyledTableHeader>
              
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>Linked</StyledTableCell>
                <StyledTableCell> 
                <audio id="voicePlayer" controls></audio> </StyledTableCell>
                <StyledTableCell ><button type="submit"     ><FaMicrophone />
               <span > (Re) Record</span>
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><RiDeleteBinLine />Delete
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><CiEdit />Edit
                </button></StyledTableCell>
        
              </StyledTableRow>
            </StyledTableBody>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>Linked</StyledTableCell>
                <StyledTableCell><audio id="voicePlayer" controls></audio></StyledTableCell>
                <StyledTableCell ><button type="submit"     ><FaMicrophone />
               <span > (Re) Record</span>
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><RiDeleteBinLine />Delete
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><CiEdit />Edit
                </button></StyledTableCell>
           
              </StyledTableRow>
            </StyledTableBody>
            
            <StyledTableBody>
            <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>Linked</StyledTableCell>
                <StyledTableCell><audio id="voicePlayer" controls></audio></StyledTableCell>
                <StyledTableCell ><button type="submit"     ><FaMicrophone />
               <span > (Re) Record</span>
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><RiDeleteBinLine />Delete
                </button></StyledTableCell>
                <StyledTableCell><button type="submit"     ><CiEdit />Edit
                </button></StyledTableCell>

              </StyledTableRow>
            </StyledTableBody>
        
            

          </StyledTable>
          <div className='container mt-4'>
        <button type="submit"     ><PiArrowArcLeftBold />Back
        </button></div>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default Voice;
