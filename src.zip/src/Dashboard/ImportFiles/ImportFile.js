import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import axios from "axios";
import * as XLSX from "xlsx";
import emailjs from "emailjs-com";

import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  View,
  View1,
  Input,
} from "./StyledImportFiles";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEye } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const ImportFile = () => {
  const [file, setFile] = useState(null);
  const [data, setData] = useState("");
  const [showinput, setShowInput] = useState(false);
  const navigate = useNavigate();
  const UserHelp = () => {
    navigate("/import_files_structure_and_content_help");
  };

  const ToggleInput = () => {
    setShowInput(!showinput);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  const fileUrl = "https://appointmentreminder.bot/TestFile.xlsx";
  const fileName = "TestFile.xlsx";

  const handleSendEmail = () => {
    const serviceID = "your_service_id";
    const templateID = "your_template_id";
    const userID = "your_user_id";

    const templateParams = {
      to_email: "hanzalamcreatives@gmail.com", // Replace with the recipient's email
      message: "This is a test email sent from React using EmailJS!", // Replace with your message
    };

    emailjs
      .send(serviceID, templateID, templateParams, userID)
      .then((response) => {
        console.log("Email sent successfully:", response.status, response.text);
        alert("Email sent successfully!");
      })
      .catch((error) => {
        console.error("There was an error sending the email:", error);
        alert("Failed to send email.");
      });
  };
  const token = localStorage.getItem("access-token");
  const company_name = localStorage.getItem("company_name");
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const data = event.target.result;
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(sheet);

        // Convert each row in the Excel file to a dictionary format
        const formattedData = json.map((item) => ({
          file_name: item["File Name"],
          first_name: item["First Name"],
          last_name: item["Last Name"],
          pri_phone: item["Pri Phone"],
          sec_phone: item["Sec Phone"],
          email_address: item["Email Address"],
          customer_id: item["Customer ID"],
          appt_date: item["Appt Date"],
          appt_time: item["Appt Time"],
          appt_end_time: item["Appt End Time"],
          reminder_type_id: item["Reminder Type ID"],
          custom_field_1: item["Custom Field 1"],
          custom_field_2: item["Custom Field 2"],
          custom_field_3: item["Custom Field 3"],
          new_contact_added: item["New Contact Added"] === "Yes",
          new_reminder_added: item["New Reminder Added"] === "Yes",
        }));

        try {
          for (const entry of formattedData) {
            const response = await axios.post(
              "https://api.appointmentreminder.bot/api/importfiles-content/",
              entry, // Post each entry separately
              {
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${token}`,
                },
              }
            );
            console.log("Data sent successfully:", response.data);

            // Optional: Store the response in the second API if needed
            const dataToStore = {
              user_name: "example_user", // Replace with actual user name or ID
              import_file: response.data.import_file, // Assuming this is returned from the first API
              file_name: file.name, // Replace with actual file name
              status: "imported", // Set the status as needed
              date: new Date().toISOString(), // Current date-time
              appts_found: json.length.toString(),
              appts_added: formattedData
                .filter((item) => item.new_reminder_added)
                .length.toString(),
              contacts_added: formattedData
                .filter((item) => item.new_contact_added)
                .length.toString(),
              appts_deleted: formattedData
                .filter((item) => item.appt_end_time)
                .length.toString(),
            };

            await axios.post(
              "https://api.appointmentreminder.bot/api/importfiles/",
              dataToStore,
              {
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${token}`,
                },
              }
            );

            console.log("Data stored successfully in the second API");
          }
        } catch (error) {
          console.error("Error sending data:", error);
        }
      };
      reader.readAsArrayBuffer(file); // Use readAsArrayBuffer for binary files
    }
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://api.appointmentreminder.bot/api/importfiles/",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("API Response:", response);
      const fetchedData = Array.isArray(response.data) ? response.data : [];
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Import Files</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help onClick={handleSendEmail}>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Import Files</ChartHeading>
            <ChartText>
              You can upload . csv or excel files with customer information,
              Appointment Information, or both.
            </ChartText>
            <ChartText>
              This page shows your previously imported files and allows you to
              manually upload files.
            </ChartText>
            <ChartText>
              <a href={fileUrl} download={fileName}>
                ClickHere! to Download Sample File
              </a>
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={ToggleInput}>
              <IoAddSharp />
              Select Files
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <Input
            showinput={showinput}
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileChange}
          />
          <View1 showinput={showinput} onClick={handleSubmit}>
            Upload
          </View1>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>File Name</StyledTableHeader>
                <StyledTableHeader>Status</StyledTableHeader>
                <StyledTableHeader>Date Imported</StyledTableHeader>
                <StyledTableHeader>Appts Found</StyledTableHeader>
                <StyledTableHeader>Appts Added</StyledTableHeader>
                <StyledTableHeader>Contacts Added</StyledTableHeader>
                <StyledTableHeader>Contacts Deleted</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>View Detail</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {Array.isArray(data) &&
                data.map((importfiles) => (
                  <StyledTableRow key={importfiles.id}>
                    <StyledTableCell>{importfiles.file_name}</StyledTableCell>
                    <StyledTableCell>{importfiles.status}</StyledTableCell>
                    <StyledTableCell>{importfiles.date}</StyledTableCell>
                    <StyledTableCell>{importfiles.appts_found}</StyledTableCell>
                    <StyledTableCell>{importfiles.appts_added}</StyledTableCell>
                    <StyledTableCell>
                      {importfiles.contacts_added}
                    </StyledTableCell>
                    <StyledTableCell>
                      {importfiles.appts_deleted}
                    </StyledTableCell>
                    <StyledTableCell>
                      <View>
                        <RiDeleteBin6Line />
                        Delete
                      </View>
                    </StyledTableCell>
                    <StyledTableCell>
                      <View>
                        <FaEye />
                        View Detail
                      </View>
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default ImportFile;
