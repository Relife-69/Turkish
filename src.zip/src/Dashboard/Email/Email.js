import React, { useState } from "react";

import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { IoEye } from "react-icons/io5";
import { AiFillEdit } from "react-icons/ai";
import { VscDebugStepBack } from "react-icons/vsc";
import { IoMdMail } from "react-icons/io";

import {
  MainContainer,
  Heading,
  ChartContainer,
  HeadingContainer,
  PageContainer,
  IconContainer,
  HelpContainer,
  Help,
  ChartHeadingContainer,
  ChartHeading,
  ChartText,
  AddingContainer,
  AddingButton,
  ExcelHolder,
  SearchContainer,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  AddingTable,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableBody,
  AddStyledTableCell,
  InputField,
  PostButton,
  ViewReminder,
  Text,
  ButtonContainer1,
  ButtonContainer,
  Clear,
  Container,
  SectectionContainer,
  Option,
} from "./StyleEmail";
import DashboardNavbar from "../Navbar/DashboardNavbar";

const EmailReports = () => {
  const [showTable, setShowTable] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [priNumber, setPriNumber] = useState("");
  const [secNumber, setSecNumber] = useState("");
  const [email, setEmail] = useState("");
  const [cusID, setCusID] = useState("");
  const [spanish, setSpanish] = useState(false);

  const toggleTable = () => {
    setShowTable(!showTable);
  };
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <IconContainer>
                <FaHome />
              </IconContainer>
              Home
              <IconContainer>
                <FaChevronRight />
              </IconContainer>
              <span>E-mail Reports</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>E-mail Reports</ChartHeading>
            <ChartText>
              Set up reports here that can be emailed daily,weekly, or monthly
              with your reminder results.
            </ChartText>
            <ChartText>
              *HINT - You can always view real-time online reports on the
              ‘Reminders’ screen
            </ChartText>
          </ChartHeadingContainer>

          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Report
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>Report Type</AddStyledTableHeader>
                  <AddStyledTableHeader>Report Name</AddStyledTableHeader>
                  <AddStyledTableHeader>To E-mails</AddStyledTableHeader>
                  <AddStyledTableHeader>Frequency</AddStyledTableHeader>
                  <AddStyledTableHeader>Active</AddStyledTableHeader>
                  <AddStyledTableHeader>HIPPA Compliant</AddStyledTableHeader>
                  <AddStyledTableHeader>Last Run Date</AddStyledTableHeader>
                  <AddStyledTableHeader></AddStyledTableHeader>
                  <AddStyledTableHeader></AddStyledTableHeader>
                  <AddStyledTableHeader></AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>

              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <SectectionContainer>
                      <Option>Select..</Option>
                      <Option>Reminder Results</Option>
                      <Option>Reminder Summary</Option>
                      <Option>Daily Failed Reminders</Option>
                    </SectectionContainer>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField type="text" />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField type="text" />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <SectectionContainer>
                      <Option>Select..</Option>
                      <Option>Daily</Option>
                      <Option>Weekly</Option>
                      <Option>Monthly</Option>
                    </SectectionContainer>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField type="checkbox" />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField type="checkbox" />
                  </AddStyledTableCell>
                  <AddStyledTableCell> Date</AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder>
                      <RiDeleteBin5Line /> Delete
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder>
                      <AiFillEdit /> Edit
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder>
                      <IoMdMail /> SendNow
                    </ViewReminder>
                  </AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Report Type</StyledTableHeader>
                <StyledTableHeader>Report Name</StyledTableHeader>
                <StyledTableHeader>To E-mails</StyledTableHeader>
                <StyledTableHeader>Frequency</StyledTableHeader>
                <StyledTableHeader>Active</StyledTableHeader>
                <StyledTableHeader>HIPPA Compliant</StyledTableHeader>
                <StyledTableHeader>Last Run Date</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Edit</StyledTableHeader>
                <StyledTableHeader>SendNow</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <Text></Text>
                </StyledTableCell>
                <StyledTableCell>
                  <ViewReminder>
                    <RiDeleteBin5Line /> Delete
                  </ViewReminder>
                </StyledTableCell>
                <StyledTableCell>
                  <ViewReminder>
                    <AiFillEdit /> Edit
                  </ViewReminder>
                </StyledTableCell>
                <StyledTableCell>
                  <ViewReminder>
                    <IoMdMail /> SendNow
                  </ViewReminder>
                </StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default EmailReports;
