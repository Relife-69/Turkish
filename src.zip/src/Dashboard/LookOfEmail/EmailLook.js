import React from "react";
import DashboardNavbar from '../Navbar/DashboardNavbar'
import "./Email.css"
import {
    AddingButton,
    AddingContainer,
    ChartContainer,
    ChartHeadingContainer,
    ChartText,
    ExcelButton,
    ExcelHolder,
    Heading,
    HeadingContainer,
    IconContainer,
    MainContainer,
    PageContainer,
    SearchContainer,
    ChartHeading,
    HelpContainer,
    Help,
    StyledTable,
    StyledTableHead,
    StyledTableRow,
    StyledTableHeader,
    StyledTableCell,
    StyledTableBody,
} from "./StyledEmail"
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaMicrophone } from "react-icons/fa6";
import { PiArrowArcLeftBold } from "react-icons/pi";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiEdit } from "react-icons/ci";

const Email = () => {
    return (
        <>
            <DashboardNavbar />
            <MainContainer>
                <Heading>Company Name</Heading>
                <ChartContainer>
                    <HeadingContainer>
                        <PageContainer>
                            <Link to="/dashhome">
                                <IconContainer>
                                    <FaHome />
                                </IconContainer>
                                Home
                            </Link>
                            <FaChevronRight />
                            <span>Customize the Look of your E-Mail Reminders</span>
                        </PageContainer>
                        <HelpContainer>
                            <Help>
                                <IoHelpCircle />
                                Help with this Page
                            </Help>
                            <Help>
                                <PiWarningCircleLight />
                                E-mail Support
                            </Help>
                        </HelpContainer>
                    </HeadingContainer>
                    <ChartHeadingContainer>
                        <ChartHeading>Customize the Look of your E-Mail Reminders</ChartHeading>
                        <ChartText>
                        Choose your Company Logo File - GIF,JPG or PNG (will be resized to 150px high) 
                        </ChartText>
                    </ChartHeadingContainer>

                    <div className="w-100">
                        <input type="file" className="w-100" style={{borderRadius:'5px', height:'20%'}}/>
                    </div>
                    <p>Include Logo in E-Mails?</p>
                    <div>
                        <input type="radio" className="radio"/>
                        <input type="radio" className="mx-2 radio"/>
                    </div>
                    <p style={{color:'#1376f8'}}>Company URL:</p>
                    <div>
                        <input type="color"/>
                    </div>



                    <div className='container mt-4'>
                        <button type="submit" className='btn2'     ><PiArrowArcLeftBold />Back
                        </button></div>
                </ChartContainer>
            </MainContainer>
        </>
    )
}

export default Email
