import React, { useState } from "react";
import axios from "axios";

const LinkedGoogle = () => {
  const [calendarName, setCalendarName] = useState("");
  const [calendarID, setCalendarID] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [readTags, setReadTags] = useState(false);
  const [matchName, setMatchName] = useState(false);
  const [defaultReminderType, setDefaultReminderType] = useState("");
  const [writeResponseToEvent, setWriteResponseToEvent] = useState(false);
  const [changeEventColor, setChangeEventColor] = useState(false);
  const [firstResponseColor, setFirstResponseColor] = useState("");
  const [secondResponseColor, setSecondResponseColor] = useState("");
  const [thirdResponseColor, setThirdResponseColor] = useState("");

  const handleSave = async () => {
    const payload = {
      calendar_name: calendarName,
      calendar_id: calendarID,
      active: isActive,
      read_settings: {
        read_tags: readTags,
        match_name: matchName,
        default_reminder_type: defaultReminderType,
      },
      write_settings: {
        write_response_to_event: writeResponseToEvent,
        change_event_color: changeEventColor,
        first_response_color: firstResponseColor,
        second_response_color: secondResponseColor,
        third_response_color: thirdResponseColor,
      },
    };

    try {
      const response = await axios.post("/api/link-google-calendar", payload);
      if (response.status === 200) {
        alert("Calendar linked successfully");
      } else {
        alert("Failed to link calendar");
      }
    } catch (error) {
      console.error("Error linking calendar:", error);
      alert("An error occurred while linking the calendar");
    }
  };

  return (
    <div>
      <h2>Link Your Google Calendar</h2>
      <p>
        By linking a Google Calendar to our site, it will allow you to send out
        reminders either by reading the first and last name of your customer
        from the appointment title, or adding a simple tag such as{" "}
        {"<Text Joe Smith 3035551212>"} in the event description.
      </p>
      <div>
        <label>
          Calendar Name:
          <input
            type="text"
            value={calendarName}
            onChange={(e) => setCalendarName(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Calendar ID:
          <input
            type="text"
            value={calendarID}
            onChange={(e) => setCalendarID(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Active:
          <input
            type="checkbox"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
          />
        </label>
      </div>
      <h3>Google Calendar Read Settings</h3>
      <div>
        <label>
          Read TAGs:
          <input
            type="checkbox"
            checked={readTags}
            onChange={(e) => setReadTags(e.target.checked)}
          />
        </label>
      </div>
      <div>
        <label>
          Match Name:
          <input
            type="checkbox"
            checked={matchName}
            onChange={(e) => setMatchName(e.target.checked)}
          />
        </label>
      </div>
      <div>
        <label>
          Default Reminder Type:
          <input
            type="text"
            value={defaultReminderType}
            onChange={(e) => setDefaultReminderType(e.target.value)}
          />
        </label>
      </div>
      <h3>Google Calendar Write Settings</h3>
      <div>
        <label>
          Write Customers Responses to Event Description:
          <input
            type="checkbox"
            checked={writeResponseToEvent}
            onChange={(e) => setWriteResponseToEvent(e.target.checked)}
          />
        </label>
      </div>
      <div>
        <label>
          Change Event Color:
          <input
            type="checkbox"
            checked={changeEventColor}
            onChange={(e) => setChangeEventColor(e.target.checked)}
          />
        </label>
      </div>
      {changeEventColor && (
        <>
          <div>
            <label>
              First Expected Response Color:
              <input
                type="text"
                value={firstResponseColor}
                onChange={(e) => setFirstResponseColor(e.target.value)}
              />
            </label>
          </div>
          <div>
            <label>
              Second Expected Response Color:
              <input
                type="text"
                value={secondResponseColor}
                onChange={(e) => setSecondResponseColor(e.target.value)}
              />
            </label>
          </div>
          <div>
            <label>
              Third Expected Response Color:
              <input
                type="text"
                value={thirdResponseColor}
                onChange={(e) => setThirdResponseColor(e.target.value)}
              />
            </label>
          </div>
        </>
      )}
      <button onClick={handleSave}>Save and Link Calendar</button>
    </div>
  );
};

export default LinkedGoogle;
