import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import {
  MainContainer,
  Heading,
  ChartContainer,
  HeadingContainer,
  PageContainer,
  IconContainer,
  HelpContainer,
  Help,
  ChartHeadingContainer,
  ChartHeading,
  ChartText,
} from "../LookOfEmail/StyledEmail";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import {
  FaHome,
  FaChevronRight,
  FaRegFileExcel,
  FaLongArrowAltUp,
  FaLongArrowAltDown,
} from "react-icons/fa";
import { IoHelpCircle } from "react-icons/io5";
import { IoIosAddCircleOutline } from "react-icons/io";
import { PiWarningCircleLight } from "react-icons/pi";
import { MdDelete } from "react-icons/md";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Remindercontent.css";

const ReminderContent = () => {
  const [rows, setRows] = useState([
    { id: 1, item: "Item 1", description: "Description 1" },
    { id: 2, item: "Item 2", description: "Description 2" },
    { id: 3, item: "Item 3", description: "Description 3" },
  ]);
  const token = localStorage.getItem("access-token");

  const moveRow = (index, direction) => {
    const newRows = [...rows];
    const targetIndex = index + direction;

    if (targetIndex >= 0 && targetIndex < newRows.length) {
      const temp = newRows[index];
      newRows[index] = newRows[targetIndex];
      newRows[targetIndex] = temp;
      setRows(newRows);
    }
  };

  const addRow = () => {
    const newRow = {
      id: rows.length + 1,
      item: `Item ${rows.length + 1}`,
      description: `Description ${rows.length + 1}`,
    };
    setRows([...rows, newRow]);
  };

  const { id } = useParams();
  const deleteRow = (index) => {
    const newRows = rows.filter((_, i) => i !== index);
    setRows(newRows);
  };
  useEffect(() => {
    const fetchData = async (id) => {
      try {
        const response = await axios.get(
          `https://api.appointmentreminder.bot/api/reminder-content-page/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const data = response.data;
        console.log(data);
        // setDescription(data.description);
        // setMsgtext(data.outreach_type);
        // setLanguage(data.language);
        // setIsBeforeAppt(data.before_appt_date);
        // setIsOnAppt(data.on_appt_date);
        // setIsAfterAppt(data.after_appt_date);
        // setFromDaysPrior(data.from_days_prior);
        // setToDaysPrior(data.to_days_prior);
        // setExpectResponse(data.expect_response);
        // setResponse1(data.response_1);
        // setResponse2(data.response_2);
        // setResponse3(data.response_3);
        // setCallerID(data.default_caller_id);
        // setSpecificCallerID(data.caller_id);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [token]);

  return (
    <div>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Reminder Types (Templates)</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Reminder Types (Templates)</ChartHeading>
            <ChartText>Edit the Content of Your Reminder Type Here</ChartText>
            <ChartText>
              You are editing <b>Techionik Reminder Email</b>. This Reminder
              Type is in English
            </ChartText>
          </ChartHeadingContainer>
          <table className="table table-bordered">
            <thead>
              <tr>
                <th className="bg-primary text-white">Actions</th>
                <th className="bg-primary text-white">Message Area</th>
                <th className="bg-primary text-white">Message Type</th>
                <th className="bg-primary text-white" style={{ width: "40%" }}>
                  File Selected
                </th>
                <th className="bg-primary text-white">File/Text Content</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={row.id}>
                  <td>
                    <div className="d-flex flex-row">
                      <button className="btnn-1 btn-sm mx-1" onClick={addRow}>
                        <IoIosAddCircleOutline />
                      </button>
                      <button
                        className="btnn-1 btn-sm"
                        onClick={() => deleteRow(index)}
                      >
                        <MdDelete />
                      </button>
                      <button
                        className="btnn-1 btn-sm mx-1"
                        onClick={() => moveRow(index, -1)}
                        disabled={index === 0}
                      >
                        <FaLongArrowAltUp />
                      </button>
                      <button
                        className="btnn-1 btn-sm"
                        onClick={() => moveRow(index, 1)}
                        disabled={index === rows.length - 1}
                      >
                        <FaLongArrowAltDown />
                      </button>
                    </div>
                  </td>
                  <td>
                    <select className="w-100">
                      <option>Message Content</option>
                      <option>Response to 1</option>
                      <option>Response to 2</option>
                      <option>Response to 3</option>
                    </select>
                  </td>
                  <td>
                    <select className="w-100">
                      <option hidden>---Select One---</option>
                      <option>Dynamic Field</option>
                      <option>Text Block</option>
                    </select>
                  </td>
                  <td>
                    <select className="w-100">
                      <option>Message Content</option>
                      <option>Response to 1</option>
                      <option>Response to 2</option>
                      <option>Response to 3</option>
                    </select>
                  </td>
                  <td>
                    <select className="w-100">
                      <option>Message Content</option>
                      <option>Response to 1</option>
                      <option>Response to 2</option>
                      <option>Response to 3</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </ChartContainer>
      </MainContainer>
    </div>
  );
};

export default ReminderContent;
