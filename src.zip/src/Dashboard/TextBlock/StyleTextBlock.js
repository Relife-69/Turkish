import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  margin: 30px 0px;
`;

export const Heading = styled.h1`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
`;

export const ChartContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
`;

export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
`;

export const PageContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  font-weight: 400;
  a {
    color: black;
    display: flex;
    text-decoration: none;
    align-items: center;
    justify-content: center;
  }
  span {
    color: #1376f8;
  }
`;

export const IconContainer = styled.div`
  color: #1376f8;
  margin: 0%;
  font-size: 24px;
  font-weight: 600;
  margin-right: 8px;
`;

export const HelpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const Help = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  border: none;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;

export const ChartHeadingContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 7px;
`;

export const ChartHeading = styled.h1`
  font-size: 28px;
  font-weight: 500;
  margin: 0%;
`;

export const ChartText = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;

export const AddingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 80%;
  flex-wrap: wrap;
`;

export const AddingButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 10px;
  padding: 10px;
  border: none;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  cursor: pointer;
`;

export const ExcelHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
`;

export const SearchContainer = styled.input`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
  width: 280px;
`;

export const AddStyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 18px;
`;

export const AddStyledTableHead = styled.thead`
  background-color: #1376f8;
  color: white;
  font-size: 14px;
  font-weight: 500;
`;

export const AddStyledTableRow = styled.tr`
  border-bottom: 2px solid #dddddd;
`;

export const AddStyledTableHeader = styled.th`
  padding: 12px;
  border-left: 2px sloid #dddddd;
  @media (max-width: 990px) {
    padding: 0%;
  }
`;

export const AddStyledTableCell = styled.td`
  padding: 12px;
  border: 2px solid #ececec;
`;

export const AddStyledTableBody = styled.tbody`
  & ${AddStyledTableRow}:nth-child(even) {
    background-color: #f9f9f9;
  }
`;
export const InputField = styled.input`
  width: 100%;
  padding: 8px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-bottom: 10px;
`;

export const PostButton = styled.button`
  width: 100%;
  background-color: #1376f8;
  color: white;
  padding: 12px 0px;
  border: none;
  cursor: pointer;
  font-size: 18px;
  font-weight: 500;
  border-radius: 5px;
  &:hover {
    background-color: #0d5cb6;
  }
`;

export const ViewReminder = styled.button`
  background-color: #d9d9d9;
  color: black;
  padding: 8px 12px;
  border: none;
  cursor: pointer;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-size: 16px;
  font-weight: 400;
  border-radius: 5px;
  display: flex;
  &:hover {
    background-color: #b3b3b3;
  }
`;

export const Text = styled.p`
  margin: 0%;
  width: 100%;
  font-size: 14px;
`;

export const AddingTable = styled.div`
  display: ${({ showTable }) => (showTable ? "flex" : "none")};
  width: 100%;
`;
export const ButtonContainer = styled.div`
  display: flex;
  width: 140px;
  justify-content: start;
  align-items: start;
`;
export const ButtonContainer1 = styled.div`
  display: flex;
  width: 80%;
  justify-content: start;
  align-items: start;
  margin: 40px;
`;

export const Clear = styled.button`
  display: flex;
  width: 115px;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 5px 12px 5px 12px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
`;
