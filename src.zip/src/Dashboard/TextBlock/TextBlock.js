import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { VscDebugStepBack } from "react-icons/vsc";
import { AiFillEdit } from "react-icons/ai";

import {
  MainContainer,
  Heading,
  ChartContainer,
  HeadingContainer,
  PageContainer,
  IconContainer,
  span,
  HelpContainer,
  Help,
  ChartHeadingContainer,
  ChartHeading,
  ChartText,
  AddingContainer,
  AddingButton,
  ExcelHolder,
  SearchContainer,
  AddingTable,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableBody,
  AddStyledTableCell,
  InputField,
  PostButton,
  ViewReminder,
  Text,
  ButtonContainer1,
  ButtonContainer,
  Clear,
} from "../TextBlock/StyleTextBlock";
import DashboardNavbar from "../Navbar/DashboardNavbar";

const TextBlock = () => {
  const [showTable, setShowTable] = useState(false);
  const [textBlocks, setTextBlocks] = useState([]);
  const [textBlockName, setTextBlockName] = useState("");
  const [textBlockContent, setTextBlockContent] = useState("");
  const [editingId, setEditingId] = useState(null); // State for storing the ID of the text block being edited
  const token = localStorage.getItem("access-token");
  const company_name = localStorage.getItem("company_name");

  useEffect(() => {
    fetchTextBlocks();
  }, []);

  const fetchTextBlocks = async () => {
    try {
      const response = await axios.get(
        "https://api.appointmentreminder.bot/api/textblocks/",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setTextBlocks(response.data);
    } catch (error) {
      console.error("Error fetching text blocks:", error);
    }
  };

  const handleAddTextBlock = async () => {
    try {
      const newTextBlock = {
        text_block_name: textBlockName,
        text_block_content: textBlockContent,
      };
      await axios.post(
        "https://api.appointmentreminder.bot/api/textblocks/",
        newTextBlock,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      fetchTextBlocks();
      setTextBlockName("");
      setTextBlockContent("");
      setShowTable(false);
    } catch (error) {
      console.error("Error adding text block:", error);
    }
  };

  const handleDeleteTextBlock = async (id) => {
    try {
      await axios.delete(
        `https://api.appointmentreminder.bot/api/textblocks/${id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      fetchTextBlocks();
    } catch (error) {
      console.error("Error deleting text block:", error);
    }
  };

  const handleUpdateTextBlock = async (id) => {
    try {
      const updatedTextBlock = {
        text_block_name: textBlockName,
        text_block_content: textBlockContent,
      };
      await axios.put(
        `https://api.appointmentreminder.bot/api/textblocks/${id}`,
        updatedTextBlock,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      fetchTextBlocks();
      setTextBlockName("");
      setTextBlockContent("");
      setEditingId(null); // Reset the editing state
    } catch (error) {
      console.error("Error updating text block:", error);
    }
  };

  const toggleTable = () => {
    setShowTable(!showTable);
  };

  const startEditing = (id, name, content) => {
    setEditingId(id);
    setTextBlockName(name);
    setTextBlockContent(content);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setTextBlockName("");
    setTextBlockContent("");
  };

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <IconContainer>
                <FaHome />
              </IconContainer>
              Home
              <FaChevronRight />
              <span>Text Blocks</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Text Blocks</ChartHeading>
            <ChartText>
              This area will allow you to create custom Text Blocks for use in
              Call, Text, or E-Mail Reminders. In addition, our library of text
              blocks is available to you when you create or edit a Reminder
              Type.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add a New Record
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>Text Block Name</AddStyledTableHeader>
                  <AddStyledTableHeader>
                    Text Block Content
                  </AddStyledTableHeader>
                  <AddStyledTableHeader></AddStyledTableHeader>
                  <AddStyledTableHeader></AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>
              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      value={textBlockName}
                      onChange={(e) => setTextBlockName(e.target.value)}
                      placeholder="Enter text block name"
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      value={textBlockContent}
                      onChange={(e) => setTextBlockContent(e.target.value)}
                      placeholder="Enter text block content"
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleAddTextBlock}>
                      <IoAddSharp /> Add
                    </PostButton>
                  </AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <AddStyledTable>
            <AddStyledTableHead>
              <AddStyledTableRow>
                <AddStyledTableHeader>Text Block Name</AddStyledTableHeader>
                <AddStyledTableHeader>Text Block Content</AddStyledTableHeader>
                <AddStyledTableHeader></AddStyledTableHeader>
                <AddStyledTableHeader></AddStyledTableHeader>
              </AddStyledTableRow>
            </AddStyledTableHead>
            <AddStyledTableBody>
              {textBlocks.map((textBlock) => (
                <AddStyledTableRow key={textBlock.id}>
                  <AddStyledTableCell>
                    {editingId === textBlock.id ? (
                      <InputField
                        type="text"
                        value={textBlockName}
                        onChange={(e) => setTextBlockName(e.target.value)}
                      />
                    ) : (
                      <Text>{textBlock.text_block_name}</Text>
                    )}
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    {editingId === textBlock.id ? (
                      <InputField
                        type="text"
                        value={textBlockContent}
                        onChange={(e) => setTextBlockContent(e.target.value)}
                      />
                    ) : (
                      <Text>{textBlock.text_block_content}</Text>
                    )}
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    {editingId === textBlock.id ? (
                      <>
                        <PostButton
                          onClick={() => handleUpdateTextBlock(textBlock.id)}
                        >
                          Save
                        </PostButton>
                        <PostButton onClick={cancelEditing}>Cancel</PostButton>
                      </>
                    ) : (
                      <ViewReminder
                        onClick={() =>
                          startEditing(
                            textBlock.id,
                            textBlock.text_block_name,
                            textBlock.text_block_content
                          )
                        }
                      >
                        <AiFillEdit /> Edit
                      </ViewReminder>
                    )}
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    {editingId !== textBlock.id && (
                      <ViewReminder
                        onClick={() => handleDeleteTextBlock(textBlock.id)}
                      >
                        <RiDeleteBin5Line /> Delete
                      </ViewReminder>
                    )}
                  </AddStyledTableCell>
                </AddStyledTableRow>
              ))}
            </AddStyledTableBody>
          </AddStyledTable>
        </ChartContainer>
        <ButtonContainer1>
          <ButtonContainer>
            <Clear>
              <VscDebugStepBack />
              Back
            </Clear>
          </ButtonContainer>
        </ButtonContainer1>
      </MainContainer>
    </>
  );
};

export default TextBlock;
