import React from 'react'
import DashboardNavbar from "../Navbar/DashboardNavbar";
import { IoIosHome } from "react-icons/io";
import { IoIosArrowForward } from "react-icons/io";
import './RecordVoice.css';
import { IoCall } from "react-icons/io5";
import { PiArrowArcLeftBold } from "react-icons/pi";



const RecordVoice = () => {
  return (
    <>
      <DashboardNavbar />
      <h1 className="text-center mt-4">Company Name</h1>
      <div className="container ">
        <IoIosHome color="blue" size={30} /><span>Home <IoIosArrowForward /> <span className='text-primary'>Voice Files<IoIosArrowForward color='black' /> Record a Voice File</span>
        </span>
      </div>
      <div className="container ">
        <h2 className='mt-4'>Record a Voice File</h2>
        <p>This page will trigger a call to you so you can record your voicefile. To edit the actual text of the voicefile, use the ‘Voicefiles’ page.</p>

      </div>
      <form className='container '>
        <label className='text-primary mb-2'>
          Voice File Name:</label> <br />
        <input type="text" name="name" className='input1 mb-3' required />
        <br />
        <label className='text-primary mb-2'>
          Description:   </label> <br />
        <textarea type="text" name="description" className='input1 p-3 mb-3' required ></textarea>
        <br />
        <label className='text-primary mb-2'>
          Description: </label> <br />
        <input type="text" name="description" className='input1 mb-3' required />
        <br />
        <button type="submit" className='btn1'><IoCall />Call Me
        </button>

      </form>
      <div className='container mt-4'>
        <button type="submit" className='btn2'><PiArrowArcLeftBold />Back
        </button></div>
    </>
  )
}

export default RecordVoice
