import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import axios from "axios";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  InputField,
  PostButton,
  AddingTable,
  ViewReminder,
  Text,
} from "./StyledNoReminderList";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { useNavigate } from "react-router-dom";
const NoReminderList = () => {
  const navigate = useNavigate();
  const [showTable, setShowTable] = useState(false);
  const [phone_number, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [noCall, setNoCall] = useState(false);
  const [noText, setNoText] = useState(false);
  const [noEmail, setNoEmail] = useState(false);
  const [data, setData] = useState([]);
  const UserHelp = () => {
    navigate("/no_reminder_list_help");
  };

  const toggleTable = () => {
    setShowTable(!showTable);
  };

  const Add = () => {
    navigate("/patientreminder${id}");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = {
      phone_number: phone_number,
      no_text: noText,
      email,
      no_call: noCall,
      no_email: noEmail,
    };

    try {
      const result = await axios.post(
        "https://8841-156-146-51-80.ngrok-free.app/customers/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("User signed up successfully:", result.data);
      setShowTable(false);
      alert("Custumer upload SuccessFully");
    } catch (error) {
      console.error("Error signing up:", error);
    }
  };

  // Fetch data from the API
  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://8841-156-146-51-80.ngrok-free.app/customers/"
      );
      console.log("Api Response:", response);
      const fetchedData = Array.isArray(response.data) ? response.data : [];
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const company_name = localStorage.getItem("company_name");

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>No Reminder List</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>No Reminder List</ChartHeading>
            <ChartText>
              Add/Remove/View People on the 'NO REMINDER' list.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Record
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
              <ExcelButton>
                <FaRegFileExcel />
                Export to Excel
              </ExcelButton>
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>Phone Number</AddStyledTableHeader>
                  <AddStyledTableHeader>Email</AddStyledTableHeader>
                  <AddStyledTableHeader>Do Not Call</AddStyledTableHeader>
                  <AddStyledTableHeader>Do Not Text</AddStyledTableHeader>
                  <AddStyledTableHeader>Do Not Email</AddStyledTableHeader>
                  <AddStyledTableHeader>Delete</AddStyledTableHeader>
                  <AddStyledTableHeader>Edit/Post</AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>
              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <InputField
                      type="Tel"
                      placeholder="Enter"
                      name="Phone_Number"
                      value={phone_number}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="email"
                      placeholder="Enter"
                      name="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="Checkbox"
                      placeholder="Enter"
                      checked={noCall}
                      name="nocall"
                      value={noCall}
                      onChange={(e) => setNoCall(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="checkbox"
                      placeholder="Enter"
                      name="notext"
                      value={noText}
                      onChange={(e) => setNoText(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="checkbox"
                      placeholder="Enter"
                      name="noemail"
                      checked={noEmail}
                      onChange={(e) => setNoEmail(e.target.checked)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton>Clear</PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>Upload</PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell></AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Phone Number</StyledTableHeader>
                <StyledTableHeader>Email</StyledTableHeader>
                <StyledTableHeader>Do Not Call</StyledTableHeader>
                <StyledTableHeader>Do Not Text</StyledTableHeader>
                <StyledTableHeader>Do Not Email</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Edit/Post</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {data.map((customer) => (
                <StyledTableRow key={customer.id}>
                  <StyledTableCell>
                    <Text>{customer.phone_number}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.email}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.no_call}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.no_text}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.no_email}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder>Delete</ViewReminder>
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder>Edit</ViewReminder>
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default NoReminderList;
