import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { RiDeleteBin5Line } from "react-icons/ri";
import { CiSettings } from "react-icons/ci";
import { FaRegMessage, FaClone } from "react-icons/fa6";
import { PiTestTubeFill } from "react-icons/pi";
import { Link, useNavigate } from "react-router-dom";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  InputField1,
  ViewReminder,
} from "./StyledReminders";

const Reminder = () => {
  const [reminders, setReminders] = useState([]);
  const token = localStorage.getItem("access-token");
  const company_name = localStorage.getItem("company_name");

  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      console.error("No token found!");
      return;
    }

    axios
      .get("https://api.appointmentreminder.bot/api/reminder-type-templates/", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setReminders(Array.isArray(response.data) ? response.data : []);
      })
      .catch((error) => {
        console.error("There was an error fetching the reminders!", error);
      });
  }, [token]);

  const handleClone = (id) => {
    if (!token) {
      console.error("No token found!");
      return;
    }

    axios
      .post(
        `https://api.appointmentreminder.bot/api/reminder-type-templates/${id}/clone/`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      .then((response) => {
        // Handle the response after cloning, e.g., refresh the list of reminders
        setReminders((prevReminders) => [...prevReminders, response.data]);
      })
      .catch((error) => {
        console.error("There was an error cloning the reminder!", error);
      });
  };

  const AddReminderType = () => {
    navigate("/addRemindertype");
  };

  const HelpPage = () => {
    navigate("/");
  };

  const OurSupport = () => {
    navigate("/");
  };

  const Setting = (id) => {
    navigate(`/remindersetting/${id}`);
  };
  const Contant = (id) => {
    navigate(`/reminder_content/${id}`);
  };

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Reminder Types (Templates)</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Reminder Types (Templates)</ChartHeading>
            <ChartText>
              Set up and configure your reminder types. You can set up multiple
              call, text, or email reminder types.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={AddReminderType}>
              <IoAddSharp />
              Create a New Reminder Type
            </AddingButton>
            <SearchContainer type="search" placeholder="Search..." />
          </AddingContainer>
          <AddStyledTable>
            <AddStyledTableHead>
              <AddStyledTableRow>
                <AddStyledTableHeader>Reminder Type ID</AddStyledTableHeader>
                <AddStyledTableHeader>Description</AddStyledTableHeader>
                <AddStyledTableHeader>Default</AddStyledTableHeader>
                <AddStyledTableHeader>Text</AddStyledTableHeader>
                <AddStyledTableHeader>E-mail</AddStyledTableHeader>
                <AddStyledTableHeader>Call</AddStyledTableHeader>
                <AddStyledTableHeader>Spanish</AddStyledTableHeader>
                <AddStyledTableHeader>Delete</AddStyledTableHeader>
                <AddStyledTableHeader>Setting</AddStyledTableHeader>
                <AddStyledTableHeader>Content</AddStyledTableHeader>
                <AddStyledTableHeader>Clone</AddStyledTableHeader>
                <AddStyledTableHeader>Test</AddStyledTableHeader>
              </AddStyledTableRow>
            </AddStyledTableHead>
            <AddStyledTableBody>
              {reminders.map((reminder) => (
                <AddStyledTableRow key={reminder.id}>
                  <AddStyledTableCell>{reminder.id}</AddStyledTableCell>
                  <AddStyledTableCell>
                    {reminder.description}
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField1
                      type="checkbox"
                      readOnly
                      checked={reminder.default}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField1
                      type="checkbox"
                      readOnly
                      checked={reminder.text}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField1
                      type="checkbox"
                      readOnly
                      checked={reminder.email}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField1
                      type="checkbox"
                      readOnly
                      checked={reminder.call}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField1
                      type="checkbox"
                      readOnly
                      checked={reminder.spanish}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder>
                      <RiDeleteBin5Line /> Delete
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder
                      onClick={() =>
                        Setting(
                          reminder.reminder_create_page.reminder_settings_page
                            .id
                        )
                      }
                    >
                      <CiSettings /> Setting
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder
                      onClick={() =>
                        Contant(
                          reminder.reminder_create_page.reminder_content_page.id
                        )
                      }
                    >
                      <FaRegMessage /> Content
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder onClick={() => handleClone(reminder.id)}>
                      <FaClone /> Clone
                    </ViewReminder>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder>
                      <PiTestTubeFill /> Test
                    </ViewReminder>
                  </AddStyledTableCell>
                </AddStyledTableRow>
              ))}
            </AddStyledTableBody>
          </AddStyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default Reminder;
