import React, { useState, useEffect, useRef } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  DatetimeContainer,
  ToggleButton,
  SectionContainer,
  OptionContainer,
  Inputfield,
  Button,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  AddingTable,
  Text,
} from "./StyledPatientReminder";
import { Link, useParams, useNavigate } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import Datetime from "react-datetime";
import "react-datetime/css/react-datetime.css";
import axios from "axios";

const PatientReminder = () => {
  const Add = (id) => {
    navigate(`/patientreminder/${id}`);
  };

  const navigate = useNavigate();
  const { id } = useParams(); // Get customerId from URL params
  const [selectedDateTime, setSelectedDateTime] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedEndDateTime, setSelectedEndDateTime] = useState(null);
  const [remindertype, setRemindertype] = useState("");
  const [customfield1, setCustomfield1] = useState("");
  const [customfield2, setCustomfield2] = useState("");
  const [customfield3, setCustomfield3] = useState("");
  const [data, setData] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [sent, setsent] = useState(true);
  const [isEndOpen, setIsEndOpen] = useState(false);
  const pickerRef = useRef();
  const endPickerRef = useRef();
  const toggleTable = () => {
    setShowTable(!showTable);
  };
  const handleOpen = () => {
    setIsOpen(!isOpen);
  };

  const handleEndOpen = () => {
    setIsEndOpen(!isEndOpen);
  };

  const token = localStorage.getItem("access-token");

  const sendDateTimeToApi = async () => {
    const user = {
      customer: id,
      reminder_type: remindertype,
      appt_date_time: selectedDateTime,
      appt_end_date_time: selectedEndDateTime,
      custom_field_1: customfield1,
      custom_field_2: customfield2,
      custom_field_3: customfield3,
      sent,
    };
    try {
      const response = await axios.post(
        "https://api.appointmentreminder.bot/api/reminders/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("Datetime stored successfully:", response.data);
      const remindtype = response.data.reminder_type;
      const starttime = response.data.appt_date_time;
      const endtime = response.data.appt_end_date_time;
      const customfield1 = response.data.custom_field_1;
      const customfield2 = response.data.custom_field_2;
      const customfield3 = response.data.custom_field_3;
      if (
        starttime &&
        endtime &&
        customfield1 &&
        customfield2 &&
        customfield3
      ) {
        localStorage.setItem("remindtype", remindtype);
        localStorage.setItem("starttime", starttime);
        localStorage.setItem("endtime", endtime);
        localStorage.setItem("customfield1", customfield1);
        localStorage.setItem("customfield2", customfield2);
        localStorage.setItem("customfield3", customfield3);
      }
    } catch (error) {
      console.error("Error storing datetime:", error);
    }
  };

  const handleChange = (datetime) => {
    setSelectedDateTime(datetime);
  };

  const handleEndChange = (datetime) => {
    setSelectedEndDateTime(datetime);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
      if (
        endPickerRef.current &&
        !endPickerRef.current.contains(event.target)
      ) {
        setIsEndOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleClearValue = () => {
    setRemindertype("");
    setSelectedDateTime(null);
    setSelectedEndDateTime(null);
    setCustomfield1("");
    setCustomfield2("");
    setCustomfield3("");
  };

  const UserHelp = () => {
    navigate("/reminder_website_help");
  };

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://api.appointmentreminder.bot/api/reminders/"
      );
      console.log("API Response:", response);
      const starttime = response.data.appt_date_time;
      const endtime = response.data.appt_end_date_time;
      const customfield1 = response.data.custom_field_1;
      const customfield2 = response.data.custom_field_2;
      const customfield3 = response.data.custom_field_3;
      if (
        starttime &&
        endtime &&
        customfield1 &&
        customfield2 &&
        customfield3
      ) {
        localStorage.setItem("starttime", starttime);
        localStorage.setItem("endtime", endtime);
        localStorage.setItem("customfield1", customfield1);
        localStorage.setItem("customfield2", customfield2);
        localStorage.setItem("customfield3", customfield3);
      }
      const fetchedData = Array.isArray(response.data) ? response.data : [];
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Customers/Reminders</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Customers/Reminders</ChartHeading>
            <ChartText>
              Note: Reminders can be added several ways. Click on ‘Help with the
              Page’ to get detailed information on how to add reminders.
            </ChartText>
            <ChartText>
              They can be manually added through this interface. 2. They can be
              uploaded to our site through import files. 3. They can be added
              on-the-fly through calendars.
            </ChartText>
            <ChartText>
              For the status of SENT reminders, go to the ‘Reminders’ screen.
            </ChartText>
            <ChartText>Reminder for </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Reminder
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>
                    Reminder Type Name
                  </AddStyledTableHeader>
                  <AddStyledTableHeader>Appt Date/Time</AddStyledTableHeader>
                  <AddStyledTableHeader>
                    Appt End Date/Time
                  </AddStyledTableHeader>
                  <AddStyledTableHeader>Custom Field 1</AddStyledTableHeader>
                  <AddStyledTableHeader>Custom Field 2</AddStyledTableHeader>
                  <AddStyledTableHeader>Custom Field 3</AddStyledTableHeader>
                  <AddStyledTableHeader>Delete</AddStyledTableHeader>
                  <AddStyledTableHeader>Edit/Post</AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>
              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <SectionContainer
                      value={remindertype}
                      onChange={(e) => setRemindertype(e.target.value)}
                    >
                      <OptionContainer value="">
                        Select an option
                      </OptionContainer>
                      <OptionContainer value="reminder text">
                        Reminder Text
                      </OptionContainer>
                      <OptionContainer value="reminder call">
                        Reminder Call
                      </OptionContainer>
                      <OptionContainer value="reminder email">
                        Reminder Email
                      </OptionContainer>
                    </SectionContainer>
                  </AddStyledTableCell>
                  <AddStyledTableCell
                    style={{ position: "relative", display: "inline-block" }}
                  >
                    <ToggleButton onClick={handleOpen}>
                      {selectedDateTime
                        ? selectedDateTime.format("YYYY-MM-DD HH:mm")
                        : "Select Date & Time"}
                    </ToggleButton>
                    {isOpen && (
                      <DatetimeContainer ref={pickerRef}>
                        <Datetime
                          onChange={handleChange}
                          value={selectedDateTime}
                          dateFormat="YYYY-MM-DD"
                          timeFormat="HH:mm"
                        />
                      </DatetimeContainer>
                    )}
                  </AddStyledTableCell>
                  <AddStyledTableCell style={{ position: "relative" }}>
                    <ToggleButton onClick={handleEndOpen}>
                      {selectedEndDateTime
                        ? selectedEndDateTime.format("YYYY-MM-DD HH:mm")
                        : "Select Date & Time"}
                    </ToggleButton>
                    {isEndOpen && (
                      <DatetimeContainer ref={endPickerRef}>
                        <Datetime
                          onChange={handleEndChange}
                          value={selectedEndDateTime}
                          dateFormat="YYYY-MM-DD"
                          timeFormat="HH:mm"
                        />
                      </DatetimeContainer>
                    )}
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <Inputfield
                      type="text"
                      placeholder="Field 1"
                      value={customfield1}
                      onChange={(e) => setCustomfield1(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <Inputfield
                      type="text"
                      placeholder="Field 2"
                      value={customfield2}
                      onChange={(e) => setCustomfield2(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <Inputfield
                      type="text"
                      placeholder="Field 3"
                      value={customfield3}
                      onChange={(e) => setCustomfield3(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <Button onClick={handleClearValue}>Cancel</Button>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <Button onClick={sendDateTimeToApi}>Update</Button>
                  </AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader> Reminder Type Name</StyledTableHeader>
                <StyledTableHeader>Appt Date/Time</StyledTableHeader>
                <StyledTableHeader> Appt End Date/Time</StyledTableHeader>
                <StyledTableHeader>Custom Field 1</StyledTableHeader>
                <StyledTableHeader>Custom Field 2</StyledTableHeader>
                <StyledTableHeader>Custom Field 3</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Edit/Post</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {data.map((reminder) => (
                <StyledTableRow key={reminder.id}>
                  <StyledTableCell>
                    <Text>{reminder.reminder_type}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{reminder.appt_date_time}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{reminder.appt_end_date_time}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{reminder.custom_field_1}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{reminder.custom_field_2}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{reminder.custom_field_3}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Button onClick={() => Add(reminder.id)}>Delete</Button>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Button onClick={() => Add(reminder.id)}>Edit</Button>
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default PatientReminder;
