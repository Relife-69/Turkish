import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  margin: 30px 0px;
`;
export const Heading = styled.h1`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
`;
export const ChartContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
`;

export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
`;
export const PageContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  font-weight: 400;
  a {
    color: black;
    display: flex;
    text-decoration: none;
    align-items: center;
    justify-content: center;
  }
  span {
    color: #1376f8;
  }
`;
export const IconContainer = styled.h1`
  color: #1376f8;
  margin: 0%;
  font-size: 24px;
  font-weight: 600;
  margin-right: 8px;
`;

export const HelpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const Help = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  border: none;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;
export const ChartHeadingContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 7px;
`;
export const ChartHeading = styled.h1`
  font-size: 28px;
  font-weight: 500;
  margin: 0%;
`;
export const ChartText = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;

export const AddingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`;
export const AddingButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 10px;
  padding: 10px;
  border: none;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;
export const ExcelHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;
export const SearchContainer = styled.input`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
  width: 180px;
`;
export const ExcelButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
  border: none;
`;
export const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 18px;
`;

export const StyledTableHead = styled.thead`
  background-color: #1376f8;
  color: white;
  font-size: 14px;
  font-weight: 500;
`;

export const StyledTableRow = styled.tr`
  border-bottom: 1px solid #dddddd;
`;

export const StyledTableHeader = styled.th`
  padding: 12px;
  border-left: 2px solid white;
`;

export const StyledTableCell = styled.td`
  padding: 12px;
`;

export const StyledTableBody = styled.tbody`
  & ${StyledTableRow}:nth-child(even) {
    background-color: #f9f9f9;
  }
`;
export const DatetimeContainer = styled.div`
  position: absolute;
  z-index: 1;
  top: 100%;
  left: 0;
`;

export const ToggleButton = styled.button`
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;

  &:hover {
    background-color: #0056b3;
  }
`;

export const SectionContainer = styled.select`
  width: 100%;
  align-items: center;
  padding: 8px;
  justify-content: center;
`;
export const OptionContainer = styled.option`
  width: 100%;
  padding: 8px;
  align-items: center;
  justify-content: center;
`;

export const Inputfield = styled.input`
  width: 90%;
  padding: 10px 0px 10px 10px;
`;

export const Button = styled.button`
  width: 100%;
  background-color: #d9d9d9;
  padding: 7px 0px;
  border: none;
`;
export const AddingTable = styled.div`
  display: ${({ showTable }) => (showTable ? "flex" : "none")};
`;
export const AddStyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 18px;
`;

export const AddStyledTableHead = styled.thead`
  background-color: #1376f8;
  color: white;
  font-size: 14px;
  font-weight: 500;
`;

export const AddStyledTableRow = styled.tr`
  border-bottom: 1px solid #dddddd;
`;

export const AddStyledTableHeader = styled.th`
  padding: 12px;
  border-left: 2px solid white;
  @media (max-width: 990px) {
    padding: 0%;
  }
`;

export const AddStyledTableCell = styled.td`
  padding: 12px;
`;

export const AddStyledTableBody = styled.tbody`
  & ${StyledTableRow}:nth-child(even) {
    background-color: #f9f9f9;
  }
`;

export const Text = styled.p`
  margin: 0%;
  width: 100%;
  font-size: 14px;
`;
