import React, { useState, useEffect } from "react";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { Link, useParams, useNavigate } from "react-router-dom";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import Switch from "react-switch";
import axios from "axios";

import {
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  ChartHeading,
  HelpContainer,
  Help,
  InputContainerHolder,
  InputContainer,
  InputField,
  InputField1,
  Label,
  RadioHolder,
  RadioContainer,
  Label1,
  SwitchContainer,
  SelectField,
  SectionHolder,
  SelectContainer,
  Option,
  QuestionContiner,
  InputContainer1,
  ButtonContainer,
  Button,
  Button1,
  TextContainer,
  Text1Container,
  Text2Container,
  Text,
} from "./StyledReminderSetting";

const ReminderTextSetting = () => {
  const [msgtext, setMsgtext] = useState("");
  const [language, setLanguage] = useState("");
  const [description, setDescription] = useState("");

  const [callerID, setCallerID] = useState(true);
  const [specificCallerID, setSpecificCallerID] = useState("");
  const [isBeforeAppt, setIsBeforeAppt] = useState(true);
  const [isOnAppt, setIsOnAppt] = useState(false);
  const [isAfterAppt, setIsAfterAppt] = useState(false);
  const [fromDaysPrior, setFromDaysPrior] = useState(null);
  const [toDaysPrior, setToDaysPrior] = useState(null);
  const [expectResponse, setExpectResponse] = useState(false);
  const [response1, setResponse1] = useState("");
  const [response2, setResponse2] = useState("");
  const [response3, setResponse3] = useState("");
  const token = localStorage.getItem("access-token");

  const { id } = useParams();
  console.log(id);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `https://api.appointmentreminder.bot/api/reminder-template-settings/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const data = response.data;
        setDescription(data.description);
        setMsgtext(data.outreach_type);
        setLanguage(data.language);
        setIsBeforeAppt(data.before_appt_date);
        setIsOnAppt(data.on_appt_date);
        setIsAfterAppt(data.after_appt_date);
        setFromDaysPrior(data.from_days_prior);
        setToDaysPrior(data.to_days_prior);
        setExpectResponse(data.expect_response);
        setResponse1(data.response_1);
        setResponse2(data.response_2);
        setResponse3(data.response_3);
        setCallerID(data.default_caller_id);
        setSpecificCallerID(data.caller_id);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [id, token]);

  const handleRadioChange = (e) => {
    setMsgtext(e.target.value);
  };

  const handleRadioChange1 = (e) => {
    setLanguage(e.target.value);
  };

  const handleBeforeApptSwitchChange = (checked) => {
    setIsBeforeAppt(checked);
  };

  const handleOnApptSwitchChange = (checked) => {
    setIsOnAppt(checked);
  };

  const handleAfterApptSwitchChange = (checked) => {
    setIsAfterAppt(checked);
  };

  const handleCallerIDChange = () => {
    setCallerID(!callerID);
  };

  const handleSave = async () => {
    const data = {
      description,
      outreach_type: msgtext,
      language: language,
      before_appt_date: isBeforeAppt,
      on_appt_date: isOnAppt,
      after_appt_date: isAfterAppt,
      from_days_prior: fromDaysPrior,
      to_days_prior: toDaysPrior,
      expect_response: expectResponse,
      response_1: response1,
      response_2: response2,
      response_3: response3,
      default_caller_id: callerID,
      caller_id: specificCallerID,
    };

    try {
      await axios.put(
        `https://api.appointmentreminder.bot/api/reminder-template-settings/${id}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert("Data updated successfully");
      navigate("/");
    } catch (error) {
      console.error("Error saving data:", error);
    }
  };

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Create Reminder Types (Templates)</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Create Reminder Types (Templates)</ChartHeading>
            <ChartText>
              Create a new reminder type based on the settings you choose below.
            </ChartText>
          </ChartHeadingContainer>
          <InputContainerHolder>
            <InputContainer>
              <Label>Description/Name:</Label>
              <InputField
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </InputContainer>
            {msgtext === "Email" && (
              <InputContainer>
                <Label>Email Subject Line:</Label>
                <InputField type="text" />
              </InputContainer>
            )}
            <InputContainer>
              <Label>
                Outreach Type: Is this a Call, Email, or Text Message Reminder?
              </Label>
              <RadioHolder>
                <RadioContainer>
                  <Label1>Call:</Label1>
                  <InputField1
                    type="radio"
                    value="Call"
                    checked={msgtext === "Call"}
                    onChange={handleRadioChange}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Text:</Label1>
                  <InputField1
                    type="radio"
                    value="Text"
                    checked={msgtext === "Text"}
                    onChange={handleRadioChange}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Email:</Label1>
                  <InputField1
                    type="radio"
                    value="Email"
                    checked={msgtext === "Email"}
                    onChange={handleRadioChange}
                  />
                </RadioContainer>
              </RadioHolder>
            </InputContainer>
            <InputContainer>
              <Label>Language: What Language is This Reminder?</Label>
              <RadioHolder>
                <RadioContainer>
                  <Label1>English:</Label1>
                  <InputField1
                    type="radio"
                    value="English"
                    checked={language === "English"}
                    onChange={handleRadioChange1}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Spanish:</Label1>
                  <InputField1
                    type="radio"
                    value="Spanish"
                    checked={language === "Spanish"}
                    onChange={handleRadioChange1}
                  />
                </RadioContainer>
              </RadioHolder>
            </InputContainer>
            <InputContainer>
              <Label>Set as Default Reminder:</Label>
              <InputField1 type="checkbox" />
            </InputContainer>
            <InputContainer>
              <Label>
                TIME FRAME OPTIONS: ACCEPTABLE WINDOW TO SEND REMINDER (ONLY 1
                REMINDER WILL BE SENT - FOR MULTIPLE REMINDERS, USE
                TRIGGERS/RULES)
              </Label>
              <RadioHolder>
                <SwitchContainer>
                  <Label1>Before Appt Date:</Label1>
                  <Switch
                    onChange={handleBeforeApptSwitchChange}
                    checked={isBeforeAppt}
                  />
                </SwitchContainer>
                <SwitchContainer>
                  <Label1>On Appt Date:</Label1>
                  <Switch
                    onChange={handleOnApptSwitchChange}
                    checked={isOnAppt}
                  />
                </SwitchContainer>
                <SwitchContainer>
                  <Label1>After Appt Date:</Label1>
                  <Switch
                    onChange={handleAfterApptSwitchChange}
                    checked={isAfterAppt}
                  />
                </SwitchContainer>
              </RadioHolder>
            </InputContainer>
            <SectionHolder>
              <InputContainer>
                <Label>
                  From How Many Days Prior to Appt Date Should the Reminder be
                  Sent?
                </Label>
                <SelectField
                  value={fromDaysPrior}
                  onChange={(e) => setFromDaysPrior(e.target.value)}
                >
                  <Option value="">Select Days</Option>
                  <Option value="1">1 Day</Option>
                  <Option value="2">2 Days</Option>
                  <Option value="3">3 Days</Option>
                  <Option value="4">4 Days</Option>
                  <Option value="5">5 Days</Option>
                  <Option value="6">6 Days</Option>
                  <Option value="7">7 Days</Option>
                </SelectField>
              </InputContainer>
              <InputContainer>
                <Label>
                  To How Many Days Prior to Appt Date Should the Reminder be
                  Sent?
                </Label>
                <SelectField
                  value={toDaysPrior}
                  onChange={(e) => setToDaysPrior(e.target.value)}
                >
                  <Option value="">Select Days</Option>
                  <Option value="1">1 Day</Option>
                  <Option value="2">2 Days</Option>
                  <Option value="3">3 Days</Option>
                  <Option value="4">4 Days</Option>
                  <Option value="5">5 Days</Option>
                  <Option value="6">6 Days</Option>
                  <Option value="7">7 Days</Option>
                </SelectField>
              </InputContainer>
            </SectionHolder>
            <InputContainer>
              <Label>Send From Specific Caller ID:</Label>
              <Switch onChange={handleCallerIDChange} checked={callerID} />
              {callerID && (
                <InputContainer1>
                  <Label>Enter Specific Caller ID</Label>
                  <InputField
                    type="text"
                    value={specificCallerID}
                    onChange={(e) => setSpecificCallerID(e.target.value)}
                  />
                </InputContainer1>
              )}
            </InputContainer>
            <InputContainer>
              <Label>Do You Expect a Response to this Message?</Label>
              <Switch
                onChange={(checked) => setExpectResponse(checked)}
                checked={expectResponse}
              />
            </InputContainer>
            {expectResponse && (
              <>
                <QuestionContiner>
                  <TextContainer>
                    <Label>Question to include in your message:</Label>
                    <SelectContainer>
                      <SelectField>
                        <Option value="">Select Question</Option>
                      </SelectField>
                    </SelectContainer>
                  </TextContainer>
                  <Text1Container>
                    <Label>Response 1:</Label>
                    <InputField
                      type="text"
                      value={response1}
                      onChange={(e) => setResponse1(e.target.value)}
                    />
                  </Text1Container>
                  <Text2Container>
                    <Label>Response 2:</Label>
                    <InputField
                      type="text"
                      value={response2}
                      onChange={(e) => setResponse2(e.target.value)}
                    />
                  </Text2Container>
                  <Text2Container>
                    <Label>Response 3:</Label>
                    <InputField
                      type="text"
                      value={response3}
                      onChange={(e) => setResponse3(e.target.value)}
                    />
                  </Text2Container>
                </QuestionContiner>
              </>
            )}
          </InputContainerHolder>
          <ButtonContainer>
            <Button onClick={() => navigate("/")}>Cancel</Button>
            <Button1 onClick={handleSave}>Save</Button1>
          </ButtonContainer>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default ReminderTextSetting;
