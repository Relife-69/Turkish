import React from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import {
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  ChartHeading,
  HelpContainer,
  Help,
  SelectionContainer,
  Option,
  TextField,
  Label,
  ButtonContainer,
  View,
  Clear,
} from "./StyledSmsText";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEye } from "react-icons/fa";

const SmsText = () => {
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Text Messages - To Distribution List</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Text Messages - To Distribution List</ChartHeading>
            <ChartText>
              This page will allow you to send a text message to everone in the
              chosen distribution list.
            </ChartText>
            <ChartText>
              To send a text message to a specific customer, go to the Customers
              Page and click on the 'SMS' button for that customer.
            </ChartText>
            <ChartText>
              It will create a Reminder Type with the name 'QuickText + Todays
              Date and Time' so you can view results in the Reminders Tab
            </ChartText>
            <SelectionContainer>
              <Option>Select an Option</Option>
              <Option>User</Option>
              <Option>All Context</Option>
              <Option>Dynamic</Option>
            </SelectionContainer>
            <Label>Sent A Message to ...</Label>
            <TextField placeholder="Enter Your Revious Text....."></TextField>
            <Label>Start With Previous Text?</Label>
            <SelectionContainer>
              <Option>Select an Option</Option>
              <Option>User</Option>
              <Option>All Context</Option>
              <Option>Dynamic</Option>
            </SelectionContainer>
            <ButtonContainer>
              <View>Submit</View>
              <Clear>Clear</Clear>
            </ButtonContainer>
          </ChartHeadingContainer>
          <View>Back</View>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default SmsText;
