import React, { useState } from "react";
import {
  AccountContainer,
  LogoContainer,
  MainContainer,
  NavbarContainer,
  NavbarMenuContainer,
  IconContainer,
  NavMenuList,
  NavbarMenu,
  List1Menu,
  Menu1Lists,
  List2Menu,
  Menu2Lists,
  List3Menu,
  Menu3Lists,
  List4Menu,
  Menu4Lists,
  List5Menu,
  Menu5Lists,
  List6Menu,
  Menu6Lists,
  List7Menu,
  Menu7Lists,
  List8Menu,
  Menu8Lists,
  AccountMenu,
} from "./StyledDashboardNavbar";
import { GiHamburgerMenu } from "react-icons/gi";
import { CgProfile } from "react-icons/cg";
import { IoMdArrowDropright } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import { RiLogoutBoxFill } from "react-icons/ri";
import Logo from "../../Components/Images/Name.png";

const DashboardNavbar = () => {
  const user_name = localStorage.getItem("user_name");
  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  const [showMenu, setShowMenu] = useState(false);
  const [showMenu1, setShowMenu1] = useState(false);
  const [showList, setShowList] = useState(false);
  const [showList1, setShowList1] = useState(false);
  const [showList2, setShowList2] = useState(false);
  const [showList3, setShowList3] = useState(false);
  const [showList4, setShowList4] = useState(false);
  const [showList5, setShowList5] = useState(false);
  const [showList6, setShowList6] = useState(false);
  const [showList7, setShowList7] = useState(false);
  const navigate = useNavigate();

  const Home = () => {
    navigate("/dashhome");
  };
  const toggleMenu = () => {
    setShowMenu(!showMenu);
    setShowMenu1(false);
    setShowList(false);
    setShowList1(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleMenu1 = () => {
    setShowMenu1(!showMenu1);
    setShowMenu(false);
    setShowList(false);
    setShowList1(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList = () => {
    setShowList(!showList);
    setShowList1(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList1 = () => {
    setShowList1(!showList1);
    setShowList(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList2 = () => {
    setShowList2(!showList2);
    setShowList(false);
    setShowList1(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList3 = () => {
    setShowList3(!showList3);
    setShowList(false);
    setShowList2(false);
    setShowList1(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList4 = () => {
    setShowList4(!showList4);
    setShowList(false);
    setShowList2(false);
    setShowList3(false);
    setShowList1(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList5 = () => {
    setShowList5(!showList5);
    setShowList(false);
    setShowList1(false);
    setShowList2(false);
    setShowList3(false);
    setShowList6(false);
    setShowList7(false);
  };
  const toggleList6 = () => {
    setShowList6(!showList6);
    setShowList5(false);
    setShowList7(false);
  };
  const toggleList7 = () => {
    setShowList7(!showList7);
    setShowList5(false);
    setShowList6(false);
  };

  const hideMenu = () => {
    setShowMenu(false);
    setShowList1(false);
    setShowList(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  const Homemenu = () => {
    setShowList1(false);
    setShowList(false);
    setShowList2(false);
    setShowList3(false);
    setShowList4(false);
    setShowList5(false);
    setShowList6(false);
    setShowList7(false);
  };
  return (
    <>
      <MainContainer>
        <NavbarContainer>
          <NavbarMenuContainer>
            <span>
              <GiHamburgerMenu onClick={toggleMenu} />
            </span>
            Navigation Menu
          </NavbarMenuContainer>
          <NavbarMenu showMenu={showMenu}>
            <NavMenuList onClick={Home} onMouseEnter={Homemenu}>
              Home
            </NavMenuList>
            <NavMenuList onMouseEnter={toggleList}>
              My Data Sources <IoMdArrowDropright />
            </NavMenuList>
            <NavMenuList onMouseEnter={toggleList1}>
              My Customers <IoMdArrowDropright />
            </NavMenuList>
            <NavMenuList onMouseEnter={toggleList2}>
              Text Messages <IoMdArrowDropright />
            </NavMenuList>
            <NavMenuList onMouseEnter={toggleList3}>
              Reporting <IoMdArrowDropright />
            </NavMenuList>
            <NavMenuList onMouseEnter={toggleList4}>
              Reminder Settings <IoMdArrowDropright />
            </NavMenuList>
          </NavbarMenu>
          <List1Menu showList={showList}>
            <Menu1Lists>
              <Link to="/calender" onClick={hideMenu}>
                Google Calendars
              </Link>
            </Menu1Lists>
            <Menu1Lists>
              <Link to="/fileimport" onClick={hideMenu}>
                Import Files
              </Link>
            </Menu1Lists>
            <Menu1Lists>
              <Link to="/addpatient" onClick={hideMenu}>
                Schedule Through Website
              </Link>
            </Menu1Lists>
          </List1Menu>
          <List2Menu showList1={showList1}>
            <Menu2Lists>
              <Link to="/addpatient" onClick={hideMenu}>
                Customers/Patients
              </Link>
            </Menu2Lists>
            <Menu2Lists>
              <Link to="/adddis" onClick={hideMenu}>
                Distribution Lists
              </Link>
            </Menu2Lists>
            <Menu2Lists>
              <Link to="/no_reminder_list" onClick={hideMenu}>
                No Reminder List
              </Link>
            </Menu2Lists>
          </List2Menu>
          <List3Menu showList2={showList2}>
            <Menu3Lists>
              <Link to="/text_distribution" onClick={hideMenu}>
                To Dist List
              </Link>
            </Menu3Lists>
            <Menu3Lists>
              <Link to="/text" onClick={hideMenu}>
                To Customer/Patient
              </Link>
            </Menu3Lists>
          </List3Menu>
          <List4Menu showList3={showList3}>
            <Menu4Lists>
              <Link to="/" onClick={hideMenu}>
                Reminders Page
              </Link>
            </Menu4Lists>
            <Menu4Lists>
              <Link to="/emai_reports" onClick={hideMenu}>
                E-Mailed Reports
              </Link>
            </Menu4Lists>
          </List4Menu>
          <List5Menu showList4={showList4}>
            <Menu5Lists onMouseEnter={toggleList5}>
              General Reminder Settings <IoMdArrowDropright />
            </Menu5Lists>
            <Menu5Lists onMouseEnter={toggleList6}>
              Calls Reminder Settings <IoMdArrowDropright />
            </Menu5Lists>
            <Menu5Lists onMouseEnter={toggleList7}>
              E-mail Reminder Settings <IoMdArrowDropright />
            </Menu5Lists>
          </List5Menu>
          <List6Menu showList5={showList5}>
            <Menu6Lists>
              <Link to="/reminder" onClick={hideMenu}>
                Reminder Types (Templates)
              </Link>
            </Menu6Lists>
            <Menu6Lists>
              <Link to="/reminder_sechdule" onClick={hideMenu}>
                Reminder Schedule
              </Link>
            </Menu6Lists>
            <Menu6Lists>
              <Link to="/text_block" onClick={hideMenu}>
                Text Blocks
              </Link>
            </Menu6Lists>
            <Menu6Lists>
              <Link to="/trigger_rules" onClick={hideMenu}>
                Triggers/Rules
              </Link>
            </Menu6Lists>
            <Menu6Lists>
              <Link to="" onClick={hideMenu}>
                Spanish Mapping
              </Link>
            </Menu6Lists>
          </List6Menu>
          <List7Menu showList6={showList6}>
            <Menu7Lists>
              <Link to="/voices" onClick={hideMenu}>
                Voice Files
              </Link>
            </Menu7Lists>
            <Menu7Lists>
              <Link to="/callerid" onClick={hideMenu}>
                Caller ID’s
              </Link>
            </Menu7Lists>
          </List7Menu>
          <List8Menu showList7={showList7}>
            <Menu8Lists>
              <Link to="/emaillook" onClick={hideMenu}>
                Customize your E-Mail Look
              </Link>
            </Menu8Lists>
          </List8Menu>
          <LogoContainer src={Logo} />
          <AccountContainer onClick={toggleMenu1}>
            <span>
              <CgProfile />
            </span>
            {user_name}
          </AccountContainer>
          <AccountMenu showMenu1={showMenu1}>
            <NavMenuList>Edit My Company</NavMenuList>
            <NavMenuList>Change Account Type</NavMenuList>
            <NavMenuList>Enable/Disable Test Mode</NavMenuList>
            <NavMenuList>Billing Info</NavMenuList>
            <NavMenuList>Billing Statements</NavMenuList>
            <NavMenuList>Payment History</NavMenuList>
            <NavMenuList>Users</NavMenuList>
            <NavMenuList onClick={handleLogout}>
              <RiLogoutBoxFill /> Log out
            </NavMenuList>
          </AccountMenu>
        </NavbarContainer>
      </MainContainer>
    </>
  );
};

export default DashboardNavbar;
