import styled from "styled-components";

export const MainContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: white;
`;
export const NavbarContainer = styled.nav`
  width: 90%;
  background-color: #e6f6fe;
  color: black;
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-top: 50px;
  padding: 10px 0px;
  border-radius: 15px;
  box-shadow: 0px 4px 0px 2px rgba(0, 0, 0, 0.25);
`;

export const NavbarMenuContainer = styled.div`
  display: flex;
  align-items: end;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  span {
    color: #1376f8;
    font-size: 24px;
  }
`;

export const LogoContainer = styled.img`
  width: 120px;
  height: 70px;
`;
export const AccountContainer = styled.div`
  display: flex;
  align-items: end;
  justify-content: center;
  font-size: 18px;
  gap: 10px;
  span {
    color: #1376f8;
    font-size: 24px;
  }
`;

export const IconContainer = styled.h1`
  color: #1376f8;
  font-size: 24px;
  font-weight: 600;
  margin: 0%;
`;

export const NavbarMenu = styled.ul`
  flex-direction: column;
  display: ${({ showMenu }) => (showMenu ? "flex" : "none")};
  position: absolute;
  align-items: center;
  justify-content: start;
  background: #1376f8;
  color: white;
  width: 200px;
  top: 115px;
  border-radius: 10px;
  border: none;
  left: 16%;
  z-index: 9999;
  gap: 15px;
  padding: 20px 0px;
`;
export const AccountMenu = styled.ul`
  flex-direction: column;
  display: ${({ showMenu1 }) => (showMenu1 ? "flex" : "none")};
  position: absolute;
  align-items: center;
  justify-content: start;
  background: #1376f8;
  color: white;
  width: 200px;
  cursor: pointer;
  top: 120px;
  border-radius: 10px;
  border: none;
  right: 16%;
  z-index: 9999;
  padding: 20px 0px;
  gap: 15px;
`;
export const NavMenuList = styled.li`
  list-style: none;
  padding: 0px 20px;
  cursor: pointer;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  &:hover {
    background-color: white;
    color: #1376f8;
    border-left: 2px solid #1376f8;
  }
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
    &:hover {
      background-color: white;
      color: #1376f8;
      border: 1px solid #1376f8;
    }
  }
`;
export const List1Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList }) => (showList ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 170px;
  left: 27%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu1Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List2Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList1 }) => (showList1 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  border-radius: 10px;
  border: none;
  padding: 20px;
  padding: 20px;
  top: 200px;
  left: 27%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu2Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List3Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList2 }) => (showList2 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 230px;
  left: 27%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu3Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List4Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList3 }) => (showList3 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 270px;
  left: 27%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu4Lists = styled.li`
  list-style: none;
  cursor: pointer;

  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List5Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList4 }) => (showList4 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 300px;
  left: 27%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu5Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List6Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList5 }) => (showList5 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 310px;
  left: 40.5%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu6Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List7Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList6 }) => (showList6 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 370px;
  left: 40.5%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu7Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
export const List8Menu = styled.ul`
  flex-direction: column;
  display: ${({ showList7 }) => (showList7 ? "flex" : "none")};
  position: absolute;
  align-items: start;
  justify-content: start;
  background: #1376f8;
  color: white;
  padding: 20px;
  border-radius: 10px;
  border: none;
  padding: 20px;
  top: 400px;
  left: 40.5%;
  z-index: 9999;
  gap: 15px;
`;
export const Menu8Lists = styled.li`
  list-style: none;
  cursor: pointer;
  a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: 600;
  }
`;
