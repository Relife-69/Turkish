import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import axios from "axios";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  InputField,
  PostButton,
  AddingTable,
  ViewReminder,
  Text,
  View,
  EditInputField,
} from "./StyledDistributionLists";
import Datetime from "react-datetime";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { useNavigate } from "react-router-dom";

const AddPatient = () => {
  const navigate = useNavigate();
  const [showTable, setShowTable] = useState(false);
  const [distListName, setDistListName] = useState("");
  const [editId, setEditId] = useState(null); // State for currently editing
  const [editName, setEditName] = useState("");
  const [data, setData] = useState([]);
  const UserHelp = () => {
    navigate("/reminder_website_help");
  };
  const AddReminder = (id) => {
    navigate(`/adddislistreminder/${id}`);
  };
  const sendmsg = (id) => {
    navigate(`/textsms/${id}`);
  };

  const toggleTable = () => {
    setShowTable(!showTable);
  };
  const Add = (id) => {
    navigate(`/patientreminder/${id}`);
  };
  const token = localStorage.getItem("access-token");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = {
      dist_list_name: distListName,
    };

    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/distribution-lists/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("User signed up successfully:", result.data);
      setShowTable(false);
      alert("Distribution list successfully");
      fetchData(); // Refresh the data after submitting a new customer
    } catch (error) {
      console.error("Error signing up:", error);
    }
  };

  // Fetch data from the API
  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://api.appointmentreminder.bot/api/distribution-lists/",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("API Response:", response);
      const fetchedData = Array.isArray(response.data) ? response.data : [];
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // Handle delete operation
  const handleDelete = async (id) => {
    try {
      await axios.delete(
        `https://api.appointmentreminder.bot/api/distribution-lists/${id}/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert("Distribution list deleted successfully");
      fetchData(); // Refresh the data after deleting a distribution list
    } catch (error) {
      console.error("Error deleting distribution list:", error);
    }
  };

  // Handle edit operation
  const handleEdit = async (id) => {
    try {
      await axios.put(
        `https://api.appointmentreminder.bot/api/distribution-lists/${id}/`,
        { dist_list_name: editName },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert("Distribution list updated successfully");
      setEditId(null); // Exit editing mode
      fetchData(); // Refresh the data after updating
    } catch (error) {
      console.error("Error updating distribution list:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const company_name = localStorage.getItem("company_name");

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Distribution Lists</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Distribution Lists</ChartHeading>
            <ChartText>
              You can create and manage distribution lists here. Then you can
              schedule a reminder to the entire list.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Distribution Lists
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
              <ExcelButton>
                <FaRegFileExcel />
                Export to Excel
              </ExcelButton>
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>Dist List Name</AddStyledTableHeader>
                  <AddStyledTableHeader>Delete</AddStyledTableHeader>
                  <AddStyledTableHeader>Edit Name</AddStyledTableHeader>
                  <AddStyledTableHeader>Modify List</AddStyledTableHeader>
                  <AddStyledTableHeader>View/Add Reminder</AddStyledTableHeader>
                  <AddStyledTableHeader>Send Sms</AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>
              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      placeholder="Enter"
                      name="distListName"
                      value={distListName}
                      onChange={(e) => setDistListName(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>Delete</PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <ViewReminder onClick={handleSubmit}>Add</ViewReminder>
                    <View onClick={toggleTable}>Cancel</View>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>Modify List</PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>
                      View/Add Reminder
                    </PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>Send Sms</PostButton>
                  </AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>Dist List Name</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Edit Name</StyledTableHeader>
                <StyledTableHeader>Modify List</StyledTableHeader>
                <StyledTableHeader>View/Add Reminder</StyledTableHeader>
                <StyledTableHeader>Send Sms</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {data.map((list) => (
                <StyledTableRow key={list.id}>
                  <StyledTableCell>
                    {editId === list.id ? (
                      <EditInputField
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                      />
                    ) : (
                      <Text>{list.dist_list_name}</Text>
                    )}
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder onClick={() => handleDelete(list.id)}>
                      Delete
                    </ViewReminder>
                  </StyledTableCell>
                  <StyledTableCell>
                    {editId === list.id ? (
                      <>
                        <PostButton onClick={() => handleEdit(list.id)}>
                          Save
                        </PostButton>
                        <View onClick={() => setEditId(null)}>Cancel</View>
                      </>
                    ) : (
                      <ViewReminder
                        onClick={() => {
                          setEditId(list.id);
                          setEditName(list.dist_list_name);
                        }}
                      >
                        Edit Name
                      </ViewReminder>
                    )}
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder onClick={() => Add(list.id)}>
                      Modify List
                    </ViewReminder>
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder onClick={() => AddReminder(list.id)}>
                      View/Add Reminder
                    </ViewReminder>
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder onClick={() => sendmsg(list.id)}>
                      Send Sms
                    </ViewReminder>
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default AddPatient;
