import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import axios from "axios";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  InputField,
  PostButton,
  AddingTable,
  ViewReminder,
  Text,
} from "./StyledAddPatient";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { useNavigate } from "react-router-dom";

const LinkedClenderContext = () => {
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Customers/Patients</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Customers/Patients</ChartHeading>
            <ChartText>
              Note: Customers can be added several ways. Click on ‘Help with the
              Page’ to get detailed information on how to add customers.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Customer/Patient
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
              <ExcelButton>
                <FaRegFileExcel />
                Export to Excel
              </ExcelButton>
            </ExcelHolder>
          </AddingContainer>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default LinkedClenderContext;
