import React, { useState } from "react";
import { FaHome, FaChevronRight } from "react-icons/fa";
import { IoHelpCircle } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { Link } from "react-router-dom";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import Switch from "react-switch";
import axios from "axios";

import {
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  ChartHeading,
  HelpContainer,
  Help,
  InputContainerHolder,
  InputContainer,
  InputField,
  InputField1,
  Label,
  RadioHolder,
  RadioContainer,
  Label1,
  SwitchContainer,
  SelectField,
  SectionHolder,
  SelectContainer,
  Option,
  QuestionContiner,
  InputContainer1,
  ButtonContainer,
  Button,
  Button1,
  TextContainer,
  Text1Container,
  Text2Container,
  Text,
} from "./StyledAddType";
import { useNavigate } from "react-router-dom";

const AddReminderType = () => {
  const [msgtext, setMsgtext] = useState("");
  const [language, setLanguage] = useState("");
  const [includeFirstName, setIncludeFirstName] = useState(false);
  const [includeLastName, setIncludeLastName] = useState(false);
  const [includeAppointmentDate, setIncludeAppointmentDate] = useState(false);
  const [includeAppointmentTime, setIncludeAppointmentTime] = useState(false);
  const [isAppointmentTimeWindow, setIsAppointmentTimeWindow] = useState(false);
  const [isAppointmentAtHome, setIsAppointmentAtHome] = useState(false);
  const [allowConfirm, setAllowConfirm] = useState(false);
  const [allowReschedule, setAllowReschedule] = useState(false);
  const [allowCancel, setAllowCancel] = useState(false);
  const [includeCompanyPhone, setIncludeCompanyPhone] = useState(false);
  const [includeCompanyAddress, setIncludeCompanyAddress] = useState(false);
  const [arriveMinutesPrior, setArriveMinutesPrior] = useState();
  const [description, setDescription] = useState("");
  const [to_days_prior, setToDaysPrior] = useState();
  const [from_days_prior, setFromDaysPrior] = useState();
  const [callerID, setCallerID] = useState("");
  const [default_caller_id, setDefaultCallerId] = useState(false);
  const [isBeforeAppt, setIsBeforeAppt] = useState(false);
  const [isOnAppt, setIsOnAppt] = useState(false);
  const [isAfterAppt, setIsAfterAppt] = useState(false);
  const token = localStorage.getItem("access-token");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = {
      description,
      default: false,
      text: false,
      email: false,
      call: false,
      spanish: false,
      language,
      reminder_create_page: {
        language,
        description,
        before_app_date: isBeforeAppt,
        outreach_type: msgtext,
        on_app_date: isOnAppt,
        after_app_date: isAfterAppt,
        from_days_prior,
        to_days_prior,
        default_caller_id,
        caller_id: callerID,
        include_first_name: includeFirstName,
        include_last_name: includeLastName,
        include_appointment_date: includeAppointmentDate,
        include_appointment_time: includeAppointmentTime,
        is_appointment_time_window: isAppointmentTimeWindow,
        arrive_minutes_prior: arriveMinutesPrior,
        is_appointment_at_home: isAppointmentAtHome,
        include_company_address: includeCompanyAddress,
        include_company_phone: includeCompanyPhone,
        allow_confirm: allowConfirm,
        allow_cancel: allowCancel,
        allow_reschedule: allowReschedule,
      },
    };

    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/reminder-type-templates/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Handle the result here, e.g., show a success message or redirect
      console.log(result.data);
    } catch (error) {
      // Handle the error here, e.g., show an error message
      console.error(error);
    }
  };
  const handleBeforeApptSwitchChange = (checked) => {
    setIsBeforeAppt(checked);
  };
  const handleCallerIDChange = () => {
    if (default_caller_id === false) {
      setDefaultCallerId(true);
    } else if (default_caller_id === true) {
      setDefaultCallerId(false);
    }
  };

  const handleOnApptSwitchChange = (checked) => {
    setIsOnAppt(checked);
  };

  const handleAfterApptSwitchChange = (checked) => {
    setIsAfterAppt(checked);
  };
  const handleIncludeFirstNameChange = (e) => {
    setIncludeFirstName(e.target.value === "true");
  };

  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Create Reminder Types (Templates)</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Create Reminder Types (Templates)</ChartHeading>
            <ChartText>
              Create a new reminder type based on the settings you choose below.
            </ChartText>
          </ChartHeadingContainer>
          <InputContainerHolder>
            <InputContainer>
              <Label>Description/Name:</Label>
              <InputField
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </InputContainer>
            {msgtext === "Email" && (
              <InputContainer>
                <Label>Email Subject Line:</Label>
                <InputField type="text" />
              </InputContainer>
            )}
            <InputContainer>
              <Label>
                Outreach Type: Is this a Call, Email, or Text Message Reminder?
              </Label>
              <RadioHolder>
                <RadioContainer>
                  <Label1>Call:</Label1>
                  <InputField1
                    type="radio"
                    value="call"
                    checked={msgtext === "call"}
                    onChange={(e) => setMsgtext(e.target.value)}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Text:</Label1>
                  <InputField1
                    type="radio"
                    value="text"
                    checked={msgtext === "text"}
                    onChange={(e) => setMsgtext(e.target.value)}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Email:</Label1>
                  <InputField1
                    type="radio"
                    value="email"
                    checked={msgtext === "email"}
                    onChange={(e) => setMsgtext(e.target.value)}
                  />
                </RadioContainer>
              </RadioHolder>
            </InputContainer>
            <InputContainer>
              <Label>Language: What Language is This Reminder? </Label>
              <RadioHolder>
                <RadioContainer>
                  <Label1>English:</Label1>
                  <InputField1
                    type="radio"
                    value="english"
                    checked={language === "english"}
                    onChange={(e) => setLanguage(e.target.value)}
                  />
                </RadioContainer>
                <RadioContainer>
                  <Label1>Spanish:</Label1>
                  <InputField1
                    type="radio"
                    value="spanish"
                    checked={language === "spanish"}
                    onChange={(e) => setLanguage(e.target.value)}
                  />
                </RadioContainer>
              </RadioHolder>
            </InputContainer>
            <InputContainer>
              <Label>Set as Default Reminder:</Label>
              <InputField1
                type="checkbox"
                value="true"
                checked={default_caller_id === "true"}
                onChange={(e) => setDefaultCallerId(e.target.value)}
              />
            </InputContainer>
            <InputContainer>
              <Label>
                TIME FRAME OPTIONS: ACCEPTABLE WINDOW TO SEND REMINDER (ONLY 1
                REMINDER WILL BE SENT - FOR MULTIPLE REMINDERS, USE
                TRIGGERS/RULES)
              </Label>
              <RadioHolder>
                <SwitchContainer>
                  <Label1>Before Appt Date:</Label1>
                  <Switch
                    onChange={handleBeforeApptSwitchChange}
                    checked={isBeforeAppt}
                  />
                </SwitchContainer>

                <SwitchContainer>
                  <Label1>On Appt Date:</Label1>
                  <Switch
                    onChange={handleOnApptSwitchChange}
                    checked={isOnAppt}
                  />
                </SwitchContainer>

                <SwitchContainer>
                  <Label1>After Appt Date:</Label1>
                  <Switch
                    onChange={handleAfterApptSwitchChange}
                    checked={isAfterAppt}
                  />
                </SwitchContainer>
              </RadioHolder>
            </InputContainer>
            {isBeforeAppt && (
              <SectionHolder>
                <SelectField>
                  <Label1>From __ Days Prior</Label1>
                  <SelectContainer
                    value={from_days_prior}
                    onChange={(e) => setFromDaysPrior(e.target.value)}
                  >
                    <Option>Select....</Option>
                    <Option value="1">1 Days</Option>
                    <Option value="2">2 Days</Option>
                    <Option value="3">3 Days</Option>
                    <Option value="4">4 Days</Option>
                    <Option value="5">5 Days</Option>
                    <Option value="6">6 Days</Option>
                    <Option value="7_days">7 Days</Option>
                    <Option value="8_days">8 Days</Option>
                    <Option value="9_days">9 Days</Option>
                    <Option value="10_days">10 Days</Option>
                    <Option value="11_days">11 Days</Option>
                    <Option value="12_days">12 Days</Option>
                    <Option value="13_days">13 Days</Option>
                    <Option value="14_days">14 Days</Option>
                    <Option value="15_days">15 Days</Option>
                    <Option value="16_days">16 Days</Option>
                    <Option value="17_days">17 Days</Option>
                    <Option value="18_days">18 Days</Option>
                    <Option value="19_days">19 Days</Option>
                    <Option value="20_days">20 Days</Option>
                    <Option value="21_days">21 Days</Option>
                    <Option value="22_days">22 Days</Option>
                    <Option value="23_days">23 Days</Option>
                    <Option value="24_days">24 Days</Option>
                    <Option value="25_days">25 Days</Option>
                    <Option value="26_days">26 Days</Option>
                    <Option value="27_days">27 Days</Option>
                    <Option value="28_days">28 Days</Option>
                    <Option value="29_days">29 Days</Option>
                    <Option value="30_days">30 Days</Option>
                    <Option value="5_week">5 Weeks</Option>
                    <Option value="6_week">6 Weeks</Option>
                    <Option value="7_week">7 Weeks</Option>
                    <Option value="8_week">8 Weeks</Option>
                  </SelectContainer>
                </SelectField>
                <SelectField>
                  <Label1>To __ Days Prior</Label1>
                  <SelectContainer
                    value={to_days_prior}
                    onChange={(e) => setToDaysPrior(e.target.value)}
                  >
                    <Option>Select....</Option>
                    <Option value="1">1 Days</Option>
                    <Option value="2">2 Days</Option>
                    <Option value="3">3 Days</Option>
                    <Option value="4">4 Days</Option>
                    <Option value="5">5 Days</Option>
                    <Option value="6">6 Days</Option>
                    <Option value="7_days">7 Days</Option>
                    <Option value="8_days">8 Days</Option>
                    <Option value="9_days">9 Days</Option>
                    <Option value="10_days">10 Days</Option>
                    <Option value="11_days">11 Days</Option>
                    <Option value="12_days">12 Days</Option>
                    <Option value="13_days">13 Days</Option>
                    <Option value="14_days">14 Days</Option>
                    <Option value="15_days">15 Days</Option>
                    <Option value="16_days">16 Days</Option>
                    <Option value="17_days">17 Days</Option>
                    <Option value="18_days">18 Days</Option>
                    <Option value="19_days">19 Days</Option>
                    <Option value="20_days">20 Days</Option>
                    <Option value="21_days">21 Days</Option>
                    <Option value="22_days">22 Days</Option>
                    <Option value="23_days">23 Days</Option>
                    <Option value="24_days">24 Days</Option>
                    <Option value="25_days">25 Days</Option>
                    <Option value="26_days">26 Days</Option>
                    <Option value="27_days">27 Days</Option>
                    <Option value="28_days">28 Days</Option>
                    <Option value="29_days">29 Days</Option>
                    <Option value="30_days">30 Days</Option>
                    <Option value="5_week">5 Weeks</Option>
                    <Option value="6_week">6 Weeks</Option>
                    <Option value="7_week">7 Weeks</Option>
                    <Option value="8_week">8 Weeks</Option>
                  </SelectContainer>
                </SelectField>
              </SectionHolder>
            )}
            {isOnAppt && (
              <SectionHolder>
                <SelectField>
                  <Label1>Hours Before Appt Time:</Label1>
                  <SelectContainer>
                    <Option>Select....</Option>
                    <Option value="1">1 Hour</Option>
                    <Option value="2">2 Hours</Option>
                    <Option value="3">3 Hours</Option>
                    <Option value="4">4 Hours</Option>
                    <Option value="5">5 Hours</Option>
                    <Option value="6_Hours">6 Hours</Option>
                    <Option value="7_Hours">7 Hours</Option>
                    <Option value="8_Hours">8 Hours</Option>
                    <Option value="9_Hours">9 Hours</Option>
                    <Option value="10_Hours">10 Hours</Option>
                    <Option value="11_Hours">11 Hours</Option>
                    <Option value="12_Hours">12 Days</Option>
                  </SelectContainer>
                </SelectField>
              </SectionHolder>
            )}
            {isAfterAppt && (
              <SectionHolder>
                <SelectField>
                  <Label1>From __ Days After</Label1>
                  <SelectContainer>
                    <Option>Select....</Option>
                    <Option value="1">1 Days</Option>
                    <Option value="2">2 Days</Option>
                    <Option value="3">3 Days</Option>
                    <Option value="4">4 Days</Option>
                    <Option value="5">5 Days</Option>
                    <Option value="6">6 Days</Option>
                    <Option value="7">7 Days</Option>
                    <Option value="8">8 Days</Option>
                    <Option value="9_days">9 Days</Option>
                    <Option value="10_days">10 Days</Option>
                    <Option value="11_days">11 Days</Option>
                    <Option value="12_days">12 Days</Option>
                    <Option value="13_days">13 Days</Option>
                    <Option value="14_days">14 Days</Option>
                    <Option value="15_days">15 Days</Option>
                    <Option value="16_days">16 Days</Option>
                    <Option value="17_days">17 Days</Option>
                    <Option value="18_days">18 Days</Option>
                    <Option value="19_days">19 Days</Option>
                    <Option value="20_days">20 Days</Option>
                    <Option value="21_days">21 Days</Option>
                    <Option value="22_days">22 Days</Option>
                    <Option value="23_days">23 Days</Option>
                    <Option value="24_days">24 Days</Option>
                    <Option value="25_days">25 Days</Option>
                    <Option value="26_days">26 Days</Option>
                    <Option value="27_days">27 Days</Option>
                    <Option value="28_days">28 Days</Option>
                    <Option value="29_days">29 Days</Option>
                    <Option value="30_days">30 Days</Option>
                    <Option value="5_week">5 Weeks</Option>
                    <Option value="6_week">6 Weeks</Option>
                    <Option value="7_week">7 Weeks</Option>
                    <Option value="8_week">8 Weeks</Option>
                  </SelectContainer>
                </SelectField>
                <SelectField>
                  <Label1>To __ Days After:</Label1>
                  <SelectContainer>
                    <Option>Select....</Option>
                    <Option value="1">1 Days</Option>
                    <Option value="2">2 Days</Option>
                    <Option value="3">3 Days</Option>
                    <Option value="4">4 Days</Option>
                    <Option value="5">5 Days</Option>
                    <Option value="6">6 Days</Option>
                    <Option value="7_days">7 Days</Option>
                    <Option value="8_days">8 Days</Option>
                    <Option value="9_days">9 Days</Option>
                    <Option value="10_days">10 Days</Option>
                    <Option value="11_days">11 Days</Option>
                    <Option value="12_days">12 Days</Option>
                    <Option value="13_days">13 Days</Option>
                    <Option value="14_days">14 Days</Option>
                    <Option value="15_days">15 Days</Option>
                    <Option value="16_days">16 Days</Option>
                    <Option value="17_days">17 Days</Option>
                    <Option value="18_days">18 Days</Option>
                    <Option value="19_days">19 Days</Option>
                    <Option value="20_days">20 Days</Option>
                    <Option value="21_days">21 Days</Option>
                    <Option value="22_days">22 Days</Option>
                    <Option value="23_days">23 Days</Option>
                    <Option value="24_days">24 Days</Option>
                    <Option value="25_days">25 Days</Option>
                    <Option value="26_days">26 Days</Option>
                    <Option value="27_days">27 Days</Option>
                    <Option value="28_days">28 Days</Option>
                    <Option value="29_days">29 Days</Option>
                    <Option value="30_days">30 Days</Option>
                    <Option value="5_week">5 Weeks</Option>
                    <Option value="6_week">6 Weeks</Option>
                    <Option value="7_week">7 Weeks</Option>
                    <Option value="8_week">8 Weeks</Option>
                  </SelectContainer>
                </SelectField>
              </SectionHolder>
            )}
            <InputContainer>
              <Label>CALLER ID:</Label>
            </InputContainer>
            <InputContainer>
              <Label>Use Default Caller ID</Label>
              <InputField1
                type="checkbox"
                onChange={handleCallerIDChange}
                checked={default_caller_id}
              />
            </InputContainer>
            {!default_caller_id && (
              <SectionHolder>
                <SelectField>
                  <Label1>Hours Before Appt Time:</Label1>
                  <SelectContainer>
                    <Option>Select....</Option>
                  </SelectContainer>
                </SelectField>
              </SectionHolder>
            )}
            <Label>CONTENT SETTINGS:</Label>
            <InputContainer1>
              <QuestionContiner>
                <Label1>
                  Do you want to include the person's First Name in the
                  reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_first_name"
                      value="true"
                      checked={includeFirstName === true}
                      onChange={handleIncludeFirstNameChange}
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_first_name"
                      value={false}
                      checked={includeFirstName === false}
                      onChange={handleIncludeFirstNameChange}
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
              <QuestionContiner>
                <Label1>
                  Do you want to include the person's Last Name in the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_last_name"
                      value="true"
                      checked={includeLastName === true}
                      onChange={(e) =>
                        setIncludeLastName(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_last_name"
                      value="false"
                      checked={includeLastName === false}
                      onChange={(e) =>
                        setIncludeLastName(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <InputContainer1>
              <QuestionContiner>
                <Label1>
                  Do you want to include the Appointment Date in the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_appointment_date"
                      value="true"
                      checked={includeAppointmentDate === true}
                      onChange={(e) =>
                        setIncludeAppointmentDate(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_appointment_date"
                      value="false"
                      checked={includeAppointmentDate === false}
                      onChange={(e) =>
                        setIncludeAppointmentDate(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
              <QuestionContiner>
                <Label1>
                  Do you want to include the Appointment Time in the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_appointment_time"
                      value="true"
                      checked={includeAppointmentTime === true}
                      onChange={(e) =>
                        setIncludeAppointmentTime(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_appointment_time"
                      value="false"
                      checked={includeAppointmentTime === false}
                      onChange={(e) =>
                        setIncludeAppointmentTime(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <InputContainer1>
              <QuestionContiner>
                <Label1>
                  Is the Appt Time a Window? Example: We will arrive between
                  10am and 12pm
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="is_appointment_time_window"
                      value="true"
                      checked={isAppointmentTimeWindow === true}
                      onChange={(e) =>
                        setIsAppointmentTimeWindow(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="is_appointment_time_window"
                      value="false"
                      checked={isAppointmentTimeWindow === false}
                      onChange={(e) =>
                        setIsAppointmentTimeWindow(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
              <QuestionContiner>
                <Label1>
                  Should the person arrive a certain amount of minutes prior to
                  the appt?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="arrive_minutes_prior"
                      value="0"
                      checked={arriveMinutesPrior === "0"}
                      onChange={(e) => setArriveMinutesPrior(e.target.value)}
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>15 Min</Label1>
                    <InputField1
                      type="radio"
                      name="arrive_minutes_prior"
                      value="15"
                      checked={arriveMinutesPrior === "15"}
                      onChange={(e) => setArriveMinutesPrior(e.target.value)}
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>30 Min</Label1>
                    <InputField1
                      type="radio"
                      name="arrive_minutes_prior"
                      value="30"
                      checked={arriveMinutesPrior === "30"}
                      onChange={(e) => setArriveMinutesPrior(e.target.value)}
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <InputContainer1>
              <QuestionContiner>
                <Label1>Is the Appt at the person's home?</Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="is_appointment_at_home"
                      value="true"
                      checked={isAppointmentAtHome === true}
                      onChange={(e) =>
                        setIsAppointmentAtHome(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="is_appointment_at_home"
                      value="false"
                      checked={isAppointmentAtHome === false}
                      onChange={(e) =>
                        setIsAppointmentAtHome(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
              <QuestionContiner>
                <Label1>
                  Do you want to include your Company Address in the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_company_address"
                      value="true"
                      checked={includeCompanyAddress === true}
                      onChange={(e) =>
                        setIncludeCompanyAddress(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_company_address"
                      value="false"
                      checked={includeCompanyAddress === false}
                      onChange={(e) =>
                        setIncludeCompanyAddress(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <InputContainer1>
              <QuestionContiner>
                <Label1>
                  Do you want to include your Company Phone Number in the
                  reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="include_company_phone"
                      value="true"
                      checked={includeCompanyPhone === true}
                      onChange={(e) =>
                        setIncludeCompanyPhone(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="include_company_phone"
                      value="false"
                      checked={includeCompanyPhone === false}
                      onChange={(e) =>
                        setIncludeCompanyPhone(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>

              <QuestionContiner>
                <Label1>
                  Do you want to allow the person to confirm the appt by
                  replying to the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="allow_confirm"
                      value="true"
                      checked={allowConfirm === true}
                      onChange={(e) =>
                        setAllowConfirm(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="allow_confirm"
                      value="false"
                      checked={allowConfirm === false}
                      onChange={(e) =>
                        setAllowConfirm(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <InputContainer1>
              <QuestionContiner>
                <Label1>
                  Do you want to allow the person to cancel the appt by replying
                  to the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="allow_cancel"
                      value="true"
                      checked={allowCancel === true}
                      onChange={(e) =>
                        setAllowCancel(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="allow_cancel"
                      value="false"
                      checked={allowCancel === false}
                      onChange={(e) =>
                        setAllowCancel(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
              <QuestionContiner>
                <Label1>
                  Do you want to allow the person to request a reschedule by
                  replying to the reminder?
                </Label1>
                <RadioHolder>
                  <RadioContainer>
                    <Label1>Yes</Label1>
                    <InputField1
                      type="radio"
                      name="allow_reschedule"
                      value="true"
                      checked={allowReschedule === true}
                      onChange={(e) =>
                        setAllowReschedule(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                  <RadioContainer>
                    <Label1>No</Label1>
                    <InputField1
                      type="radio"
                      name="allow_reschedule"
                      value="false"
                      checked={allowReschedule === false}
                      onChange={(e) =>
                        setAllowReschedule(e.target.value === "true")
                      }
                    />
                  </RadioContainer>
                </RadioHolder>
              </QuestionContiner>
            </InputContainer1>
            <ButtonContainer>
              <Button onClick={handleSubmit}>Submit</Button>
              <Button1>Clear</Button1>
            </ButtonContainer>
            <TextContainer>
              <Text1Container>
                <Text>
                  This is a Preview of your Reminder Type. You can COMPELETELY
                  CUSTOMIZE IT by clicking on 'Edit Settings' in the 'Reminder
                  Types(Templates)' screen after creation. Note: Items inside
                  brackets like (FirstName) will be pulled from your Data Source
                  (Calendar, Import File, etc...) or your Company Settings (My
                  Account/Edit My Company)
                </Text>
              </Text1Container>
              <Text2Container>
                <Text>
                  Hi This is {"<CompanyName>"}
                  {includeFirstName && "with a reminder for <FirstName>"}
                  {includeLastName && "<Last Name>"}
                  {includeAppointmentDate &&
                    "You have an appointment on <Appointment Date>"}
                  {includeAppointmentTime && "at <Appointment Time>"}
                  {isAppointmentTimeWindow &&
                    "between <Appointment Time> and <Appointment End Time>"}
                  {arriveMinutesPrior &&
                    `Please arrive ${arriveMinutesPrior} minutes prior to your appointment.`}
                  {isAppointmentAtHome &&
                    "We will arrive at your location between these times."}
                  {includeCompanyAddress && "Our address is <Company Address>."}
                  {includeCompanyPhone &&
                    "Questions about this appointment? Please call us at <Company Phone Number>."}
                  {allowConfirm &&
                    "To confirm this appointment, please text 1."}
                  {allowCancel && "To cancel, text 2."}
                  {allowReschedule && "To reschedule, text 3."}
                </Text>
              </Text2Container>
            </TextContainer>
          </InputContainerHolder>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default AddReminderType;
