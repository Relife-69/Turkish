import styled from "styled-components";
export const MainContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  margin: 30px 0px;
`;

export const Heading = styled.h1`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  margin: 0%;
`;

export const ChartContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 23px;
  flex-direction: column;
  width: 80%;
  padding: 15px;
  border: 1px solid silver;
  border-radius: 8px;
`;

export const HeadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
`;

export const PageContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  font-size: 18px;
  font-weight: 400;
  a {
    color: black;
    display: flex;
    text-decoration: none;
    align-items: center;
    justify-content: center;
  }
  span {
    color: #1376f8;
  }
`;

export const IconContainer = styled.div`
  color: #1376f8;
  margin: 0%;
  font-size: 24px;
  font-weight: 600;
  margin-right: 8px;
`;

export const HelpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
`;

export const Help = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #d9d9d9;
  color: black;
  border: none;
  gap: 5px;
  padding: 10px;
  font-size: 18px;
  font-weight: 400;
  border-radius: 5px;
`;

export const ChartHeadingContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 7px;
`;

export const ChartHeading = styled.h1`
  font-size: 28px;
  font-weight: 500;
  margin: 0%;
`;

export const ChartText = styled.p`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;

export const InputContainerHolder = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: start;
  gap: 20px;
  width: 100%;
`;
export const InputContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: start;
  gap: 10px;
  width: 90%;
`;
export const InputContainer1 = styled.div`
  display: flex;
  align-items: start;
  justify-content: space-between;
  gap: 100px;
  flex-wrap: wrap;
  width: 95%;
  padding: 30px;
`;
export const Label = styled.label`
  font-size: 18px;
  font-weight: 400;
  margin: 0%;
`;
export const InputField = styled.input`
  width: 100%;
  padding: 10px 5px;
  border: 1px solid silver;
  background-color: white;
  &:active {
    outline: none;
  }
  &:focus {
    outline: none;
  }
`;
export const InputField1 = styled.input``;
export const RadioHolder = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
`;
export const RadioContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
`;
export const Label1 = styled.label`
  font-size: 16px;
  font-weight: 400;
  margin: 0%;
`;
export const SwitchContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  flex-direction: column;
`;
export const SelectField = styled.div`
  display: flex;
  align-items: start;
  flex-direction: column;
  gap: 8px;
`;
export const SectionHolder = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 30px;
`;

export const SelectContainer = styled.select`
  width: 180px;
  height: 35px;
  padding-left: 10px;
`;
export const Option = styled.option`
  width: 180px;
  height: 35px;
  padding-left: 10px;
`;

export const QuestionContiner = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-direction: column;
  gap: 10px;
`;

export const Button = styled.button`
  padding: 10px;
  display: flex;
  align-items: center;
  border-radius: 8px;
  border: none;
  background-color: #1376f8;
  color: white;
  cursor: pointer;
  &:hover {
    background-color: white;
    border: 1px solid #1376f8;
    color: #1376f8;
  }
`;
export const Button1 = styled.button`
  padding: 10px;
  display: flex;
  align-items: center;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  background-color: silver;
  &:hover {
    background-color: white;
    border: 1px solid silver;
  }
`;

export const ButtonContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  gap: 15px;
`;

export const TextContainer = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  flex-wrap: wrap;
  width: 100%;
  gap: 15px;
`;

export const Text1Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 15px;
  max-width: 350px;
  border: 1px solid silver;
  min-height: 200px;
`;
export const Text2Container = styled.div`
  display: flex;
  align-items: start;
  justify-content: start;
  padding: 15px;
  min-height: 200px;
  width: 700px;
  border: 1px solid silver;
`;

export const Text = styled.p`
  font-size: 17px;
  font-weight: 400;
  margin: 0%;
`;
