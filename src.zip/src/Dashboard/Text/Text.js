import React from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import "./Text.css";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
} from "./TextStyled";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaMicrophone } from "react-icons/fa6";
import { PiArrowArcLeftBold } from "react-icons/pi";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiEdit } from "react-icons/ci";

const Text = () => {
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Company Name</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Text Messages - To Customer/Patient</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Text Messages - To Customer/Patient</ChartHeading>
            <ChartText>
              This Page will allow you to send a text message to a specific
              customer/patient. <br />
              It will create a Reminder Type with the name ‘Quick Test + Todays
              Date and Time so you can view results in the Reminders Tab
            </ChartText>
          </ChartHeadingContainer>

          <select className="w-100 drop-1">
            <option value="1" hidden>
              City
            </option>
            <option value="2">Two</option>
            <option value="3">Three</option>
            <option value="4">Four</option>
            <option value="5">Five</option>
            <option value="6">Six</option>
            <option value="7">Seven</option>
            <option value="8">Eight</option>
          </select>

          <div>
            <label>Send a text message to City </label>
          </div>
          <textarea name="message" className="w-100 text"></textarea>
          <label>Start with a previous text? </label>
          <select className="w-100 drop-2">
            <option value="1" hidden>
              Previous Text Messages............
            </option>
            <option value="2">Two</option>
            <option value="3">Three</option>
            <option value="4">Four</option>
            <option value="5">Five</option>
            <option value="6">Six</option>
            <option value="7">Seven</option>
            <option value="8">Eight</option>
          </select>

          <div className="container mt-4">
            <div className="row">
              <div className="col-1">
                <button type="submit" className="submit">
                  Submit
                </button>
              </div>
              <div className="col-3">
                <button type="submit" className="clear">
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="container mt-4 ">
            <p>
              This area show all text messages that have gone out to
              customers/patients between dates selected
            </p>
            <div className="row " style={{ borderTop: "3px solid #1376f8" }}>
              <div className="col-6 mt-4">
                <p>Start Date</p>
                <input
                  type="date"
                  name="startDate"
                  id="startDate"
                  className="form-control"
                />
              </div>
              <div className="col-6 mt-4">
                <p>End Date</p>
                <input
                  type="date"
                  name="endDate"
                  id="endDate"
                  className="form-control"
                />
              </div>
            </div>
          </div>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader style={{ width: "10%" }}>
                  First Name
                </StyledTableHeader>
                <StyledTableHeader>Last Name</StyledTableHeader>
                <StyledTableHeader>Status</StyledTableHeader>
                <StyledTableHeader>Reason</StyledTableHeader>
                <StyledTableHeader style={{ width: "30%" }}>
                  Outbound Message
                </StyledTableHeader>
                <StyledTableHeader>Inbound Message</StyledTableHeader>
                <StyledTableHeader>Date & Time</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody style={{ fontSize: "small" }}>
              <StyledTableRow>
                <StyledTableCell>James</StyledTableCell>
                <StyledTableCell>Watt</StyledTableCell>
                <StyledTableCell>Sent</StyledTableCell>
                <StyledTableCell>sadcdcd</StyledTableCell>
                <StyledTableCell>
                  This is a friendly reminder for your upcoming appointment with
                  appointment reminder Demo on Thu 9/29 at 11:20 PM.
                </StyledTableCell>
                <StyledTableCell>sssss</StyledTableCell>
                <StyledTableCell>06/24/2024 12:38 PM Mountain</StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
          </StyledTable>

          <div className="container mt-4">
            <button type="submit" className="btn2">
              <PiArrowArcLeftBold />
              Back
            </button>
          </div>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default Text;
