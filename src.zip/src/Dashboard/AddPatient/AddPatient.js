import React, { useState, useEffect } from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import axios from "axios";
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
  AddStyledTable,
  AddStyledTableHead,
  AddStyledTableRow,
  AddStyledTableHeader,
  AddStyledTableCell,
  AddStyledTableBody,
  InputField,
  PostButton,
  AddingTable,
  ViewReminder,
  Text,
} from "./StyledAddPatient";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { useNavigate } from "react-router-dom";

const AddPatient = () => {
  const navigate = useNavigate();
  const [showTable, setShowTable] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [priNumber, setPriNumber] = useState("");
  const [secNumber, setSecNumber] = useState("");
  const [email, setEmail] = useState("");
  const [cusID, setCusID] = useState("");
  const [spanish, setSpanish] = useState(false);
  const [data, setData] = useState([]);
  const UserHelp = () => {
    navigate("/reminder_website_help");
  };

  const toggleTable = () => {
    setShowTable(!showTable);
  };
  const Add = (id) => {
    const selectedCustomer = data.find((customer) => customer.id === id);
    if (selectedCustomer) {
      localStorage.setItem("first_name", selectedCustomer.first_name);
      localStorage.setItem("last_name", selectedCustomer.last_name);
      navigate(`/patientreminder/${id}`);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = {
      first_name: firstName,
      last_name: lastName,
      email,
      pri_phone: priNumber,
      sec_phone: secNumber,
      customer_id: cusID,
      spanish,
    };

    try {
      const result = await axios.post(
        "https://api.appointmentreminder.bot/api/customers/",
        user,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("User signed up successfully:", result.data);
      setShowTable(false);
      alert("Customer uploaded successfully");
      fetchData(); // Refresh the data after submitting a new customer
    } catch (error) {
      console.error("Error signing up:", error);
    }
  };

  // Fetch data from the API
  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://api.appointmentreminder.bot/api/customers/"
      );
      console.log("API Response:", response);
      const fetchedData = Array.isArray(response.data) ? response.data : [];
      setData(fetchedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const company_name = localStorage.getItem("company_name");
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>Hi {company_name} !!</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Customers/Patients</span>
            </PageContainer>
            <HelpContainer>
              <Help onClick={UserHelp}>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Customers/Patients</ChartHeading>
            <ChartText>
              Note: Customers can be added several ways. Click on ‘Help with the
              Page’ to get detailed information on how to add customers.
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton onClick={toggleTable}>
              <IoAddSharp />
              Add New Customer/Patient
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
              <ExcelButton>
                <FaRegFileExcel />
                Export to Excel
              </ExcelButton>
            </ExcelHolder>
          </AddingContainer>
          <AddingTable showTable={showTable}>
            <AddStyledTable>
              <AddStyledTableHead>
                <AddStyledTableRow>
                  <AddStyledTableHeader>First Name</AddStyledTableHeader>
                  <AddStyledTableHeader>Last Name</AddStyledTableHeader>
                  <AddStyledTableHeader>Pri Phone</AddStyledTableHeader>
                  <AddStyledTableHeader>Sec Phone</AddStyledTableHeader>
                  <AddStyledTableHeader>E-mail Address</AddStyledTableHeader>
                  <AddStyledTableHeader>Customer ID</AddStyledTableHeader>
                  <AddStyledTableHeader>Spanish</AddStyledTableHeader>
                  <AddStyledTableHeader>Delete</AddStyledTableHeader>
                  <AddStyledTableHeader>Edit/Post</AddStyledTableHeader>
                  <AddStyledTableHeader>
                    View/Add Reminders
                  </AddStyledTableHeader>
                </AddStyledTableRow>
              </AddStyledTableHead>
              <AddStyledTableBody>
                <AddStyledTableRow>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      placeholder="Enter"
                      name="firstname"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      placeholder="Enter"
                      name="lastname"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="tel"
                      placeholder="Enter"
                      name="priNumber"
                      value={priNumber}
                      onChange={(e) => setPriNumber(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="tel"
                      placeholder="Enter"
                      name="secNumber"
                      value={secNumber}
                      onChange={(e) => setSecNumber(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="email"
                      placeholder="Enter"
                      name="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="text"
                      placeholder="Enter"
                      name="cusID"
                      value={cusID}
                      onChange={(e) => setCusID(e.target.value)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell>
                    <InputField
                      type="checkbox"
                      placeholder="Enter"
                      name="spanish"
                      checked={spanish}
                      onChange={(e) => setSpanish(e.target.checked)}
                    />
                  </AddStyledTableCell>
                  <AddStyledTableCell></AddStyledTableCell>
                  <AddStyledTableCell>
                    <PostButton onClick={handleSubmit}>Add</PostButton>
                  </AddStyledTableCell>
                  <AddStyledTableCell></AddStyledTableCell>
                </AddStyledTableRow>
              </AddStyledTableBody>
            </AddStyledTable>
          </AddingTable>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader>First Name</StyledTableHeader>
                <StyledTableHeader>Last Name</StyledTableHeader>
                <StyledTableHeader>Pri Phone</StyledTableHeader>
                <StyledTableHeader>Sec Phone</StyledTableHeader>
                <StyledTableHeader>E-mail Address</StyledTableHeader>
                <StyledTableHeader>Customer ID</StyledTableHeader>
                <StyledTableHeader>Spanish</StyledTableHeader>
                <StyledTableHeader>Delete</StyledTableHeader>
                <StyledTableHeader>Edit/Post</StyledTableHeader>
                <StyledTableHeader>View/Add Reminders</StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              {data.map((customer) => (
                <StyledTableRow key={customer.id}>
                  <StyledTableCell>
                    <Text>{customer.first_name}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.last_name}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.pri_phone}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.sec_phone}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.email}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.customer_id}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    <Text>{customer.spanish ? "Yes" : "No"}</Text>
                  </StyledTableCell>
                  <StyledTableCell>
                    {/* Add your delete functionality here */}
                  </StyledTableCell>
                  <StyledTableCell>
                    {/* Add your edit functionality here */}
                  </StyledTableCell>
                  <StyledTableCell>
                    <ViewReminder onClick={() => Add(customer.id)}>
                      View/Add Reminder
                    </ViewReminder>
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </StyledTableBody>
          </StyledTable>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default AddPatient;
