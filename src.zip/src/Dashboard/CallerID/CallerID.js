import React from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
// import "./CallerID.css"
import {
  AddingButton,
  AddingContainer,
  ChartContainer,
  ChartHeadingContainer,
  ChartText,
  ExcelButton,
  ExcelHolder,
  Heading,
  HeadingContainer,
  IconContainer,
  MainContainer,
  PageContainer,
  SearchContainer,
  ChartHeading,
  HelpContainer,
  Help,
  StyledTable,
  StyledTableHead,
  StyledTableRow,
  StyledTableHeader,
  StyledTableCell,
  StyledTableBody,
} from "./StyledCallerID";
import { Link } from "react-router-dom";
import { FaHome, FaChevronRight, FaRegFileExcel } from "react-icons/fa";
import { IoHelpCircle, IoAddSharp } from "react-icons/io5";
import { PiWarningCircleLight } from "react-icons/pi";
import { FaMicrophone } from "react-icons/fa6";
import { PiArrowArcLeftBold } from "react-icons/pi";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiEdit } from "react-icons/ci";

const CallerID = () => {
  const company_name = localStorage.getItem("company_name");
  return (
    <>
      <DashboardNavbar />
      <MainContainer>
        <Heading>{company_name}</Heading>
        <ChartContainer>
          <HeadingContainer>
            <PageContainer>
              <Link to="/dashhome">
                <IconContainer>
                  <FaHome />
                </IconContainer>
                Home
              </Link>
              <FaChevronRight />
              <span>Caller ID’s</span>
            </PageContainer>
            <HelpContainer>
              <Help>
                <IoHelpCircle />
                Help with this Page
              </Help>
              <Help>
                <PiWarningCircleLight />
                E-mail Support
              </Help>
            </HelpContainer>
          </HeadingContainer>
          <ChartHeadingContainer>
            <ChartHeading>Caller ID’s</ChartHeading>
            <ChartText>
              This Area will allow you add caller ID’s to associate with your
              call or email type reminders
            </ChartText>
          </ChartHeadingContainer>
          <AddingContainer>
            <AddingButton>
              <IoAddSharp />
              Add New Caller ID
            </AddingButton>
            <ExcelHolder>
              <SearchContainer type="search" placeholder="Search..." />
            </ExcelHolder>
          </AddingContainer>
          <StyledTable>
            <StyledTableHead>
              <StyledTableRow>
                <StyledTableHeader style={{ width: "15%" }}>
                  Caller ID
                </StyledTableHeader>

                <StyledTableHeader>Verified</StyledTableHeader>
                <StyledTableHeader>Verify Now</StyledTableHeader>
                <StyledTableHeader>Is Default</StyledTableHeader>
                <StyledTableHeader style={{ width: "5%" }}></StyledTableHeader>
                <StyledTableHeader style={{ width: "5%" }}></StyledTableHeader>
              </StyledTableRow>
            </StyledTableHead>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />{" "}
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <RiDeleteBinLine />
                    Delete
                  </button>
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <CiEdit />
                    Edit
                  </button>
                </StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <RiDeleteBinLine />
                    Delete
                  </button>
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <CiEdit />
                    Edit
                  </button>
                </StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>

            <StyledTableBody>
              <StyledTableRow>
                <StyledTableCell>janie</StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <input type="checkbox" />
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <RiDeleteBinLine />
                    Delete
                  </button>
                </StyledTableCell>
                <StyledTableCell>
                  <button type="submit" className="btn2">
                    <CiEdit />
                    Edit
                  </button>
                </StyledTableCell>
              </StyledTableRow>
            </StyledTableBody>
          </StyledTable>
          <div className="container mt-4">
            <button type="submit" className="btn2">
              <PiArrowArcLeftBold />
              Back
            </button>
          </div>
        </ChartContainer>
      </MainContainer>
    </>
  );
};

export default CallerID;
