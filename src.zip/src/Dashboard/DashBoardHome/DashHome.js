import React from "react";
import DashboardNavbar from "../Navbar/DashboardNavbar";
import { IoIosHome } from "react-icons/io";
import { IoIosArrowForward } from "react-icons/io";
import "./DashHome.css";
import { Link } from "react-router-dom";

const DashHome = () => {
  const company_name = localStorage.getItem("company_name");

  return (
    <>
      <DashboardNavbar />
      <h1 className="text-center mt-4">{company_name}</h1>
      <div className="mx-5 ">
        <div className="row">
          <div className="col-3 bg1">
            <Link to="/dashhome">
              <IoIosHome className="text-primary" size={26} />
            </Link>
            {company_name} Home
          </div>
        </div>
      </div>
      <div className="Container mt-5">
        <div className="row">
          <div className="col-1 "></div>
          <div className="col-3 mx-4 box-1 ">
            <h3 className="fs-6 mt-3">Account Review</h3>
            <hr className="hr" />
          </div>
          <div className="col-3 mx-4 box-1 ">
            <h3 className="fs-6 mt-3">Used Vs Allotted Monthly Reminders</h3>
            <hr className="hr" />
          </div>
          <div className="col-3 mx-4 box-1 ">
            <h3 className="fs-6 mt-3">Account Overview</h3>
            <hr className="hr" />
          </div>
        </div>
      </div>

      <div className="row mt-5">
        <div className="col-1 "></div>
        <div className="col-6 mx-4 box-1 ">
          <h3 className="fs-6 mt-3">Account Review</h3>
          <hr className="hr" />
        </div>
        <div className="col-1 box "></div>

        <div className="col-3 box-1">
          <h3 className="fs-6 mt-3">Account Overview</h3>
          <hr className="hr" />
        </div>
      </div>
      <div className="row mt-5 mb-5">
        <div className="col-1  mx-1 "></div>
        <div className="col-10 mx-2 box-1 ">
          <h3 className="fs-6 mt-3">Account Review</h3>
          <hr className="hr" />
        </div>
      </div>
    </>
  );
};

export default DashHome;
